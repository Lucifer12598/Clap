package com.cts.clap.services.zap.service;

import java.io.File;
import java.io.InputStream;
import java.util.UUID;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bson.Document;
import org.json.simple.JSONObject;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.ec2.model.CreateTagsRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.InstanceNetworkInterfaceSpecification;
import com.amazonaws.services.ec2.model.RunInstancesRequest;
import com.amazonaws.services.ec2.model.RunInstancesResult;
import com.amazonaws.services.ec2.model.Tag;
import com.amazonaws.services.ec2.model.TerminateInstancesRequest;
import com.amazonaws.services.ec2.model.TerminateInstancesResult;
import com.cts.clap.services.zap.dao.MongoDAO;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

public class AWSService {
	JSONObject prop = null;
	int count = 0;
	private final Logger logger = LogManager.getLogger(this.getClass());

	public AWSService(String configProjectName) throws Exception {
		try {
			MongoDAO mongo = MongoDAO.getInstance();
			prop = mongo.getConfigDetails("ClapConfig",configProjectName,"aws");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("[AWSService - AWSService()] - Excception -" + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
	}

	public Instance createEC2Instance() throws Exception {
		logger.debug("[AWSService - createEC2Instance()] - Start");
		Instance instanceDetails = null;
		int count = 0;
		String s3Region = (String) prop.get("awsRegion");
		Region region = Region.getRegion(Regions.valueOf(s3Region));
		try {
			BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(prop.get("awsAccVal").toString(),
					prop.get("awsSecVal").toString());
			AmazonEC2 ec2Client = AmazonEC2ClientBuilder.standard()
					.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials)).withRegion(region.getName())
					.build();
			// Launch an Amazon EC2 Instance
			RunInstancesRequest runInstancesRequest = new RunInstancesRequest()
					.withImageId(prop.get("securityAMI").toString()).withInstanceType("t2.small") // https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/instance-types.html
					.withMinCount(1).withMaxCount(1).withKeyName(prop.get("keyName").toString()).withNetworkInterfaces(
							new InstanceNetworkInterfaceSpecification().withAssociatePublicIpAddress(true)
									.withDeviceIndex(0).withSubnetId(prop.get("securitySubnet").toString())
									.withGroups(prop.get("securityGroup").toString()));

			RunInstancesResult runInstancesResult = ec2Client.runInstances(runInstancesRequest);

			instanceDetails = runInstancesResult.getReservation().getInstances().get(0);
			String instanceId = instanceDetails.getInstanceId();
			logger.debug("[AWSService - createEC2Instance()] - EC2 Instance Id start");
			// System.out.println("Instance details -- "+instance.toString());

			// Setting up the tags for the instance
			CreateTagsRequest createTagsRequest = new CreateTagsRequest().withResources(instanceDetails.getInstanceId())
					.withTags(new Tag("Name", UUID.randomUUID().toString()));
			ec2Client.createTags(createTagsRequest);

			while (count < 10) {

				if ((instanceDetails.getState().getName().equalsIgnoreCase("running")
						&& (instanceDetails.getPublicIpAddress() != null))) {
					logger.debug(
							"[AWSService - createEC2Instance()] - Instance in running state with public Ip");

					return instanceDetails;

				} else {

					count++;
					logger.debug("[AWSService - createEC2Instance()] - Instance in pending state---- ");
					instanceDetails = describeInstance(instanceId);
					Thread.sleep(20000);

				}
				if (count >= 10) {
					logger.debug("[AWSService - createEC2Instance()] - instance running state timeout ------------");
					break;

				}

			}
			return instanceDetails;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("[AWSService - createEC2Instance()] - Exception -" + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}

	}

	public Instance describeInstance(String instanceId) {
		logger.debug("[AWSService - describeInstance()] - Start");
		Instance instaceDetails = null;
		String s3Region = (String) prop.get("awsRegion");
		Region region = Region.getRegion(Regions.valueOf(s3Region));

		BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(prop.get("awsAccVal").toString(),
				prop.get("awsSecVal").toString());
		AmazonEC2 ec2Client = AmazonEC2ClientBuilder.standard()
				.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials)).withRegion(region.getName())
				.build();
		DescribeInstancesRequest request = new DescribeInstancesRequest();
		request.withInstanceIds(instanceId);
		DescribeInstancesResult response = ec2Client.describeInstances(request);
		logger.debug("[AWSService - describeInstance()] - End");
		return response.getReservations().get(0).getInstances().get(0);

	}

	public boolean connectEC2SSH(String hostName, String command) throws Exception {
		logger.debug("[AWSService - connectEC2SSH()] - start");
		String REMOTE_HOST = hostName;
		String USERNAME = prop.get("sshUserName").toString();
		String PASSWORD = "";
		int REMOTE_PORT = 22;
		int SESSION_TIMEOUT = 180000;
		int CHANNEL_TIMEOUT = 180000;
	

		Session session = null;
		Channel channel = null;
		boolean isSuccess = false;

		try {
			File file = new File("./linux-docker-privatekey.ppk").getCanonicalFile();
			String privateKey = file.getCanonicalPath();

			logger.debug("[AWSService - connectEC2SSH()] - privateKey - " + privateKey);

			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			JSch jsch = new JSch();
			session = jsch.getSession(USERNAME, REMOTE_HOST, 22);
			// session.setPassword(password);
			jsch.addIdentity(privateKey);
			logger.debug("[AWSService - connectEC2SSH()] - identity added ");
			session.setConfig(config);
			session.connect(SESSION_TIMEOUT);

			logger.debug("[AWSService - connectEC2SSH()] - Connected");

			channel = session.openChannel("exec");
			((ChannelExec) channel).setCommand(command);

			channel.setInputStream(null);
			((ChannelExec) channel).setErrStream(System.err);

			// read the result from remote server
			InputStream in = channel.getInputStream();

			channel.connect();
			byte[] tmp = new byte[1024];
			while (true) {

				while (in.available() > 0) {
					int i = in.read(tmp, 0, 1024);

					if (i < 0)
						break;
					if (new String(tmp, 0, i).contains("ZAP is now listening on 0.0.0.0:8090")) {
						isSuccess = true;
						break;
					}

				}

				if (channel.isClosed()) {
//					logger.debug("[AWSService - connectEC2SSH()] - exit-status: " + channel.getExitStatus());

					break;
				} else if (isSuccess) {
					break;
				}

				
			}

			if (isSuccess) {
				logger.debug("[AWSService - connectEC2SSH()] - End");
				return true;
			} else {
				logger.debug("[AWSService - connectEC2SSH()] - End");
				return false;
			}
		} catch (Exception e) {
			logger.error("[AWSService - connectEC2SSH()] - Exception - " + ExceptionUtils.getStackTrace(e));
			throw new Exception("Exception connecting ssh.... " + e.getMessage());
		}

	}

//	public boolean connectEC2SSHAndPullImage(String hostName, String command) throws Exception {
//		logger.debug("[AWSService - connectEC2SSHAndPullImage()] - Start");
//		String REMOTE_HOST = hostName;
//		String USERNAME = prop.get("sshUserName").toString();
//		String PASSWORD = "";
//		int REMOTE_PORT = 22;
//		int SESSION_TIMEOUT = 180000;
//		int CHANNEL_TIMEOUT = 180000;
//
//		Session session = null;
//		Channel channel = null;
//
//		try {
//			File file = new File("./linux-docker-privatekey.ppk").getCanonicalFile();
//			String privateKey = file.getCanonicalPath();
//
//
//			java.util.Properties config = new java.util.Properties();
//			config.put("StrictHostKeyChecking", "no");
//			JSch jsch = new JSch();
//			session = jsch.getSession(USERNAME, REMOTE_HOST, 22);
//
//			// session.setPassword(password);
//			jsch.addIdentity(privateKey);
//			logger.debug("[AWSService - connectEC2SSHAndPullImage()] - identity added ");
//			session.setConfig(config);
//			session.connect(SESSION_TIMEOUT);
//
//			logger.debug("[AWSService - connectEC2SSHAndPullImage()] - Connected");
//
//			channel = session.openChannel("exec");
//			((ChannelExec) channel).setCommand(command);
//			channel.setInputStream(null);
//			((ChannelExec) channel).setErrStream(System.err);
//
//			// read the result from remote server
//			InputStream in = channel.getInputStream();
//			channel.connect();
//			byte[] tmp = new byte[1024];
//			while (true) {
//				while (in.available() > 0) {
//					int i = in.read(tmp, 0, 1024);
//					if (i < 0)
//						break;
//					if (new String(tmp, 0, i).contains("Downloaded newer image for owasp")) {
//						channel.disconnect();
//						session.disconnect();
//						logger.debug("[AWSService - connectEC2SSHAndPullImage()] - End");
//						return true;
//					}
//				}
//				if (channel.isClosed()) {
//					logger.debug(
//							"[AWSService - connectEC2SSHAndPullImage()] - exit-status: " + channel.getExitStatus());
//
//					break;
//				}
//
//				Thread.sleep(1000);
//
//			}
//
//		} catch (Exception e) {
//			logger.debug("[AWSService - connectEC2SSHAndPullImage()] - Exception" + ExceptionUtils.getStackTrace(e));
//			throw new Exception(e.getMessage());
//		} finally {
//			channel.disconnect();
//			session.disconnect();
//
//		}
//		logger.debug("[AWSService - connectEC2SSHAndPullImage()] - End");
//		return false;
//	}

	public String terminateEC2Instance(String instanceId) throws Exception {
		logger.debug("[AWSService - terminateEC2Instance()] - Start");
		String s3Region = (String) prop.get("awsRegion");
		Region region = Region.getRegion(Regions.valueOf(s3Region));

		BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(prop.get("awsAccVal").toString(),
				prop.get("awsSecVal").toString());
		AmazonEC2 ec2Client = AmazonEC2ClientBuilder.standard()
				.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials)).withRegion(region.getName())
				.build();
		try {
			TerminateInstancesRequest ti = new TerminateInstancesRequest().withInstanceIds(instanceId);
			TerminateInstancesResult response = ec2Client.terminateInstances(ti);
			logger.debug("[AWSService - terminateEC2Instance()] - End");
			return response.getTerminatingInstances().get(0).getCurrentState().getName();
		} catch (Exception e) {
			logger.debug("[AWSService - terminateEC2Instance()] - Exception -" + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}

	}

}

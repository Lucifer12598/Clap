package com.cts.clap.services.zap.controller;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.amazonaws.services.ec2.model.Instance;
import com.cts.clap.services.zap.service.AWSService;

@Path("/api/aws/")
public class AWSController {

	@Path("/createinstance")
	@POST()
	@Produces(MediaType.APPLICATION_JSON)
	public Instance createInstance() throws Exception {
		AWSService service = new AWSService("");

		return service.createEC2Instance();
	}

	@Path("/describeinstance/{instanceId}")
	@POST()
	@Produces(MediaType.APPLICATION_JSON)
	public Instance describeInstance(@PathParam("instanceId") String instanceId) throws Exception {
		AWSService service = new AWSService("");

		return service.describeInstance(instanceId);
	}

}

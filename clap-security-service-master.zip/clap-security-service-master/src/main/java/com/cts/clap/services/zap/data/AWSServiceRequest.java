package com.cts.clap.services.zap.data;

import java.util.Date;

import com.amazonaws.regions.Regions;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class AWSServiceRequest {
	private String id;
	private String name;
	private String accessId;
	private String secretKey;
	private String cluster;
	private Regions zone;
	private int tasks;
	private String awsArnTaskDetails;
	private Date lastUpdatedOn;
	private String taskDefination;

}

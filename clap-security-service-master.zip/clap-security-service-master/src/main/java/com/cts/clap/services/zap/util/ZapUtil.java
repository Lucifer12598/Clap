package com.cts.clap.services.zap.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ZapUtil {
	private final Logger logger = LogManager.getLogger(this.getClass());
	Properties prop = null;

	public Properties getClapProperties() throws Exception {
		logger.debug("[ClapUtil - getClapProperties()] Start");
		if (prop == null) {

			prop = new Properties();

		}
		InputStream input = null;
		try {

			input = getClass().getResourceAsStream("/config.properties");

			prop.load(input);
			logger.debug("[ClapUtil - getClapProperties()] End");
			return prop;
		} catch (Exception ex) {
			logger.error("[ClapUtil - getClapProperties()] Exception - " + ExceptionUtils.getStackTrace(ex));
			throw new Exception(ex);
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

	}

}

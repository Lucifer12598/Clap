package com.cts.clap.services.zap.controller;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cts.clap.services.zap.data.ZapServiceRequest;
import com.cts.clap.services.zap.service.ZAPService;

@Path("/api")
public class ZapController {
	private final Logger logger = LogManager.getLogger(this.getClass());

	@Path("/scan")
	@POST()
	@Produces(MediaType.APPLICATION_JSON)
	public Response startScan(ZapServiceRequest zapServiceRequest) throws Exception {
		logger.debug("[ClapSeleniumController - startScan()] - Start - zapServiceRequest - " + zapServiceRequest);
		ZAPService zapService = new ZAPService();
		new java.util.Timer().schedule(new java.util.TimerTask() {
			@Override
			public void run() {

				try {
					zapService.scanAndGenerateReport(zapServiceRequest);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					logger.error("[ClapSeleniumController - startScan()] - Exception "
							+ ExceptionUtils.getStackTrace(e));
				}
			}
		}, 3000);

		logger.debug("[ClapSeleniumController - createProject()] - End");
		return Response.status(Response.Status.OK).entity("Request submitted for scan").build();

	}

}

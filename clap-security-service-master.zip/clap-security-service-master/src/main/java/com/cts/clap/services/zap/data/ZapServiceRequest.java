package com.cts.clap.services.zap.data;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ZapServiceRequest {
	private String zapUrl;
	private String username;
	private String password;
	private String projectId;
	private String scenarioID;
	private String scantype;
	private String loginUrl;
	private String userNameLabel;
	private String passwordLabel;
	private String loggedoutindicator;
	private String logoutUrl;
	private ZapExecutionRequest zapExecution;
	private String configProjectName;

}

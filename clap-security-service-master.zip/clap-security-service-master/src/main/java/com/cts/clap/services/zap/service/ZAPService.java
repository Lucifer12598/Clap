package com.cts.clap.services.zap.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.zaproxy.clientapi.core.ApiResponse;
import org.zaproxy.clientapi.core.ApiResponseElement;
import org.zaproxy.clientapi.core.ClientApi;
import org.zaproxy.clientapi.core.ClientApiException;

import com.amazonaws.services.ec2.model.Instance;
import com.cts.clap.services.zap.data.ZapServiceRequest;
import com.cts.clap.services.zap.util.ZapUtil;

public class ZAPService {
	private static String ZAP_ADDRESS;
	private static int ZAP_PORT;
	private static String ZAP_API_KEY;
	private static String contextId;
	private static String userId;
	private static String contextName;
	private static String siteLoginUrl;
	private static String logoutUrl;
	private static String loggedoutindicator;
	private static String siteUserName;
	private static String sitePassword;
	private static String target;
	private String scanType;
	final private static int _200 = 200;
	final private static int _201 = 201;
	Properties prop = null;
	private final Logger logger = LogManager.getLogger(this.getClass());

	public ZAPService() throws Exception {
		try {
			prop = new ZapUtil().getClapProperties();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("[ZAPService - ZAPService()] - Excception -" + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	public String scanAndGenerateReport(ZapServiceRequest zapRequest) throws Exception {
		logger.debug("[ZAPService - scanAndGenerateReport()] - Start");
		AWSService awsService = new AWSService(zapRequest.getConfigProjectName());
		String instanceId = null;
		boolean status = false;
		int count = 0;
		try {

			Instance instanceDetails = awsService.createEC2Instance();
			instanceId = instanceDetails.getInstanceId();
			logger.debug("[ZAPService - scanAndGenerateReport()] - Instance running --- ");
			String command1 = "docker run -p 8090:8090 -i owasp/zap2docker-stable zap.sh -daemon -port 8090 -host 0.0.0.0 -config api.disablekey=true -config api.addrs.addr.name=.* -config api.addrs.addr.regex=true";
			// String command = "docker pull owasp/zap2docker-stable";
			try {

				status = awsService.connectEC2SSH(instanceDetails.getPublicDnsName(), command1);
				while (!status && count < 5) {
					count++;
					Thread.sleep(10000);
					status = awsService.connectEC2SSH(instanceDetails.getPublicDnsName(), command1);

				}

			} catch (Exception e) {
				while (!status && count < 5) {
					count++;
					Thread.sleep(10000);

					status = awsService.connectEC2SSH(instanceDetails.getPublicDnsName(), command1);

				}
			}
			// logger.debug("[ZAPService - scanAndGenerateReport()] - Status -"
			// + status);
			if (status) {

				executeScriptsInContainer(zapRequest, instanceDetails.getPublicDnsName(), status);
				// executeScriptsInContainer(zapRequest, "localhost", status);
			}
		} catch (Exception e) {
			logger.error("[ZAPService - scanAndGenerateReport()] - Exception -" + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		} finally {
			if (null != instanceId) {
				awsService.terminateEC2Instance(instanceId);
			}
		}

		return null;
	}

	@SuppressWarnings("unchecked")
	private void executeScriptsInContainer(ZapServiceRequest zapRequest, String hostName, boolean status)
			throws Exception {
		logger.debug("[ZAPService - executeScriptsInContainer()] - Start");
		// logger.debug("[ZAPService - executeScriptsInContainer()] - hostName -
		// " + hostName);
		String result = null;
		ClientApi api = null;
		try {
			ZAP_PORT = 8090;
			// ZAP_PORT = 8102;
			ZAP_API_KEY = null;
			ZAP_ADDRESS = hostName;
			target = zapRequest.getZapUrl();
			loggedoutindicator = zapRequest.getLoggedoutindicator();
			siteLoginUrl = zapRequest.getLoginUrl();
			logoutUrl = zapRequest.getLogoutUrl();
			siteUserName = zapRequest.getUsername();
			sitePassword = zapRequest.getPassword();
			scanType = zapRequest.getScantype();
			api = new ClientApi(ZAP_ADDRESS, ZAP_PORT, ZAP_API_KEY);
			contextName = "1";
			// logger.debug("[ZAPService - executeScriptsInContainer()] - Spider
			// : " + target);
			if (zapRequest.getUsername() == null || zapRequest.getPassword() == null) {
				setIncludeAndExcludeInContext(api);
				result = zapRegularScan(api);
			} else {
				// createContext(contextName);
				setIncludeAndExcludeInContext(api);
				setFormBasedAuthenticationForBodgeit(api, zapRequest.getUserNameLabel(), zapRequest.getPasswordLabel());
				setLoggedInIndicator(api);
				String userId = setUserAuthConfigForBodgeit(api);
				scanAsUser(api, userId);
				logger.debug("[ZAPService - executeScriptsInContainer()] - End of execution");
			}

			updateResultInDB(zapRequest, api, "Passed");

		} catch (Exception e) {
			// TODO Auto-generated catch block
			updateResultInDB(zapRequest, api, "Failed - " + e.getMessage());
			logger.error("[ZAPService - executeScriptsInContainer()] - Exception" + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());

		}

	}

	@SuppressWarnings("unchecked")
	private void updateResultInDB(ZapServiceRequest zapRequest, ClientApi api, String status)
			throws ClientApiException, Exception {
		String url = prop.getProperty("cloudAPI") + "/cloudAPI/UpdateSecurityTestResult";
		JSONObject testResultObj = new JSONObject();
		JSONObject htmlReportObj = new JSONObject();
		JSONObject jsonReportObj = new JSONObject();
		JSONArray reportArray = new JSONArray();
		htmlReportObj.put("type", "html");
		htmlReportObj.put("result", new String(api.core.htmlreport(), StandardCharsets.UTF_8));
		jsonReportObj.put("type", "json");
		jsonReportObj.put("result", new String(api.core.jsonreport(), StandardCharsets.UTF_8));
		reportArray.add(htmlReportObj);
		reportArray.add(jsonReportObj);
		testResultObj.put("scenarioExecutionID", zapRequest.getZapExecution().getScenarioExecutionID());
		testResultObj.put("indexID", zapRequest.getZapExecution().getIndexID());
		testResultObj.put("testresult", reportArray);
		testResultObj.put("status", status);
		// StringBuffer response = openConnectionForPostRequest(url, "POST",
		// testResultObj);
		StringBuffer response = openConnectionForPostRequest(url, "POST", testResultObj, zapRequest);
		if (null != response)
			logger.debug("[ZAPService - executeScriptsInContainer()] - response of successful update in db - "
					+ response.toString());
	}

	private void setIncludeAndExcludeInContext(ClientApi clientApi) throws Exception {
		logger.debug("[ZAPService - setIncludeAndExcludeInContext()] - Start");
		String includeInContext = target + ".*";
		createContext(contextName);
		// ApiResponse resp=clientApi.context.newContext(contextName);
		// contextId=resp.getName();
		clientApi.context.includeInContext(contextName, includeInContext);
		logger.debug("[ZAPService - setIncludeAndExcludeInContext()] -  Context includeded");
		// String excludeFromSpider = logoutUrl;
		// clientApi.context.excludeFromContext(contextName,
		// java.util.regex.Pattern.quote(excludeFromSpider));
		logger.debug("[ZAPService - setIncludeAndExcludeInContext()] - Context excluded");
		logger.debug("[ZAPService - setIncludeAndExcludeInContext()] - End");

	}

	private void createContext(String contextName) throws Exception {
		logger.debug("[ZAPService - createContext()] - Start");
		URL obj = new URL("http://" + ZAP_ADDRESS + ":" + ZAP_PORT + "/JSON/context/action/newContext/?contextName="
				+ contextName);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("GET");
		int responseCode = con.getResponseCode();
		BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();
		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();
		logger.debug("[ZAPService - createContext()] - ContextId - ");
		JSONObject contextObj = (JSONObject) new JSONParser().parse(response.toString());
		contextId = contextObj.get("contextId").toString();
		logger.debug("[ZAPService - createContext()] - End");

	}

	private void setLoggedInIndicator(ClientApi clientApi) throws UnsupportedEncodingException, ClientApiException {
		// Prepare values to set, with the logged in indicator as a regex
		// matching the logout link
		logger.debug("[ZAPService - setLoggedInIndicator()] - Start");
		String loggedInIndicator = loggedoutindicator;

		// Actually set the logged in indicator
		clientApi.authentication.setLoggedOutIndicator(contextId, java.util.regex.Pattern.quote(loggedInIndicator));

		// Check out the logged in indicator that is set
		// logger.debug("[ZAPService - setLoggedInIndicator()] - Configured
		// logged in indicator regex: "
		// + ((ApiResponseElement)
		// clientApi.authentication.getLoggedOutIndicator(contextId)).getValue());
		logger.debug("[ZAPService - setLoggedInIndicator()] - End");
	}

	private void setFormBasedAuthenticationForBodgeit(ClientApi clientApi, String userNameLabel, String passwordLabel)
			throws ClientApiException, UnsupportedEncodingException {
		logger.debug("[ZAPService - setFormBasedAuthenticationForBodgeit()] - Start");
		// Setup the authentication method

		// String loginUrl = siteLoginUrl;
		// String loginRequestData = userNameLabel + "=" + siteUserName + "&" +
		// passwordLabel + "=" + sitePassword
		// + "&btnSubmit=Login";
		String loginRequestData = userNameLabel + "=" + siteUserName + "&" + passwordLabel + "=" + sitePassword
				+ "&type=native";
		// Prepare the configuration in a format similar to how URL parameters
		// are formed. This
		// means that any value we add for the configuration values has to be
		// URL encoded.
		StringBuilder formBasedConfig = new StringBuilder();
		formBasedConfig.append("loginUrl=").append(URLEncoder.encode(siteLoginUrl, "UTF-8"));
		formBasedConfig.append("&loginRequestData=").append(URLEncoder.encode(loginRequestData, "UTF-8"));

		// logger.debug(
		// "[ZAPService - setFormBasedAuthenticationForBodgeit()] - Setting form
		// based authentication configuration as: "
		// + formBasedConfig.toString());
		clientApi.authentication.setAuthenticationMethod(contextId, "formBasedAuthentication",
				formBasedConfig.toString());

		// Check if everything is set up ok
		// logger.debug("[ZAPService - setFormBasedAuthenticationForBodgeit()] -
		// Authentication config: "
		// +
		// clientApi.authentication.getAuthenticationMethod(contextId).toString(0));
		logger.debug("[ZAPService - setFormBasedAuthenticationForBodgeit()] - End");
	}

	private String setUserAuthConfigForBodgeit(ClientApi clientApi)
			throws ClientApiException, UnsupportedEncodingException {
		logger.debug("[ZAPService - setUserAuthConfigForBodgeit()] - Start");
		// Prepare info
		String user = "user-1";
		String username = siteUserName;
		String password = sitePassword;

		// Make sure we have at least one user
		String userId = extractUserId(clientApi.users.newUser(contextId, user));

		// Prepare the configuration in a format similar to how URL parameters
		// are formed. This
		// means that any value we add for the configuration values has to be
		// URL encoded.
		StringBuilder userAuthConfig = new StringBuilder();
		userAuthConfig.append("username=").append(URLEncoder.encode(username, "UTF-8"));
		userAuthConfig.append("&password=").append(URLEncoder.encode(password, "UTF-8"));

		// logger.debug("[ZAPService - setUserAuthConfigForBodgeit()] - Setting
		// user authentication configuration as: "
		// + userAuthConfig.toString());
		clientApi.users.setAuthenticationCredentials(contextId, userId, userAuthConfig.toString());
		clientApi.users.setUserEnabled(contextId, userId, "true");
		clientApi.forcedUser.setForcedUser(contextId, userId);
		clientApi.forcedUser.setForcedUserModeEnabled(true);

		// Check if everything is set up ok
		// logger.debug("[ZAPService - setUserAuthConfigForBodgeit()] -
		// Authentication config: "
		// + clientApi.users.getUserById(contextId, userId).toString(0));
		return userId;
	}

	private static String extractUserId(ApiResponse response) {
		return ((ApiResponseElement) response).getValue();
	}

	private void scanAsUser(ClientApi api, String userId) throws Exception {
		logger.debug("[ZAPService - scanAsUser()] - Start");
		try {
			// Start spidering the target
			// It's not necessary to pass the ZAP API key again, already set
			// when creating the
			// ClientApi.
			logger.debug("[ZAPService - scanAsUser()] - Starting spider scan");
			ApiResponse resp = api.spider.scanAsUser(contextId, userId, target, null, "true", null);
			String scanid;
			int progress;

			// The scan now returns a scan id to support concurrent scanning
			scanid = ((ApiResponseElement) resp).getValue();
			// logger.debug("[ZAPService - scanAsUser()] - Spider in scan - " +
			// scanid);
			// Poll the status until it completes
			while (true) {
				Thread.sleep(1000);
				progress = Integer.parseInt(((ApiResponseElement) api.spider.status(scanid)).getValue());
				// logger.debug("[ZAPService - scanAsUser()] - Spider progress :
				// " + progress + "%");
				if (progress >= 100) {
					break;
				}
			}
			logger.debug("[ZAPService - scanAsUser()] - Spider complete");

			// Poll the number of records the passive scanner still has to scan
			// until it completes
			while (true) {
				Thread.sleep(1000);
				progress = Integer.parseInt(((ApiResponseElement) api.pscan.recordsToScan()).getValue());
				// logger.debug("[ZAPService - scanAsUser()] - Passive Scan
				// progress : " + progress + " records left");
				if (progress < 1) {
					break;
				}
			}
			logger.debug("[ZAPService - scanAsUser()] - Passive Scan complete");

			if (scanType.equalsIgnoreCase("active")) {
				resp = api.ascan.scanAsUser(target, contextId, userId, "True", null, null, null);

				// The scan now returns a scan id to support concurrent scanning
				scanid = ((ApiResponseElement) resp).getValue();

				// Poll the status until it completes
				while (true) {
					Thread.sleep(5000);
					progress = Integer.parseInt(((ApiResponseElement) api.ascan.status(scanid)).getValue());
					// logger.debug("[ZAPService - scanAsUser()] - Active Scan
					// progress: " + progress + "%");
					if (progress >= 100) {
						break;
					}
				}
				logger.debug("[ZAPService - scanAsUser()] - Active Scan complete");
			}
			logger.debug("[ZAPService - scanAsUser()] - End");

		} catch (Exception e) {
			logger.error("[ZAPService - scanAsUser()] - Exception -" + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
	}

	private String zapRegularScan(ClientApi api) throws Exception {
		logger.debug("[ZAPService - zapRegularScan()] - Start");
		try {
			// Start spidering the target
			// logger.debug("[ZAPService - zapRegularScan()] - Spider : " +
			// target);
			// It's not necessary to pass the ZAP API key again, already set
			// when creating the
			// ClientApi.
			ApiResponse resp = api.spider.scan(target, null, null, contextId, null);
			String scanid;
			int progress;

			// The scan now returns a scan id to support concurrent scanning
			scanid = ((ApiResponseElement) resp).getValue();

			// Poll the status until it completes
			while (true) {
				Thread.sleep(1000);
				progress = Integer.parseInt(((ApiResponseElement) api.spider.status(scanid)).getValue());

				// logger.debug("[ZAPService - zapRegularScan()] - Spider
				// progress : " + progress + "%");
				if (progress >= 100) {
					break;
				}
			}
			ApiResponse res = api.spider.allUrls();
			logger.debug("[ZAPService - zapRegularScan()] - Spider complete");

			// Poll the number of records the passive scanner still has to scan
			// until it completes
			while (true) {
				Thread.sleep(1000);
				progress = Integer.parseInt(((ApiResponseElement) api.pscan.recordsToScan()).getValue());
				// logger.debug("[ZAPService - zapRegularScan()] - Passive Scan
				// progress : " + progress + " records left");
				if (progress < 1) {
					break;
				}
			}

			logger.debug("[ZAPService - zapRegularScan()] - Passive Scan complete");

			if (scanType.equalsIgnoreCase("active")) {
				// logger.debug("[ZAPService - zapRegularScan()] - Active scan :
				// " + target);

				resp = api.ascan.scan(target, "True", "False", null, null, null);

				// The scan now returns a scan id to support concurrent scanning
				scanid = ((ApiResponseElement) resp).getValue();

				// Poll the status until it completes
				while (true) {
					Thread.sleep(5000);
					progress = Integer.parseInt(((ApiResponseElement) api.ascan.status(scanid)).getValue());
					// logger.debug("[ZAPService - zapRegularScan()] - Active
					// Scan progress : " + progress + "%");
					if (progress >= 100) {
						break;
					}
				}
				logger.debug("[ZAPService - zapRegularScan()] - Active Scan complete");
			}

			logger.debug("[ZAPService - zapRegularScan()] - End");
			return "scan complete";
		} catch (Exception e) {
			logger.error("[ZAPService - zapRegularScan()] - Exception " + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}

	}

	public StringBuffer openConnectionForPostRequest(String url, String type, JSONObject object,
			ZapServiceRequest zapRequest) throws Exception {
		// logger.debug("[ZAPService - openConnectionForPostRequest()] -
		// Start");
		BufferedReader in = null;
		// logger.debug("[ZAPService - openConnectionForPostRequest()] - Calling
		// to update DB");
		try {

			URL obj = new URL(url);
			HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
			postConnection.setRequestMethod(type);
			postConnection.setRequestProperty("Content-Type", "application/json");
			postConnection.setConnectTimeout(200000);
			postConnection.setReadTimeout(200000);
			postConnection.setDoOutput(true);
			OutputStream os = postConnection.getOutputStream();
			if (null != object) {
				// os.write(object.toString().getBytes());

				os.write(zapRequest.toString().getBytes());

			}
			os.flush();
			os.close();
			String readLine = null;
			int responseCode = postConnection.getResponseCode();
			// logger.debug("[ZAPService - openConnectionForPostRequest()] -
			// ResponseCode -- " + responseCode);

			// ********************* required code written down
			// *************************************
			// if (_200 == responseCode || _201 == responseCode) {
			// in = new BufferedReader(new
			// InputStreamReader(postConnection.getInputStream()));
			// StringBuffer response = new StringBuffer();
			// while ((readLine = in.readLine()) != null) {
			// response.append(readLine);
			// }
			// in.close();

			// logger.debug("[ZAPService -
			// openConnectionForPostRequest()] - End");
			// return response;
			// }

			if (_200 == responseCode || _201 == responseCode) {
				StringBuffer response = new StringBuffer();
				response.append("success");
			}
		} catch (Exception e) {
			// logger.error("[ZAPService - openConnectionForPostRequest()] -
			// Exception" + ExceptionUtils.getStackTrace(e));
			throw new Exception(e);
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					// logger.error("[ZAPService -
					// openConnectionForPostRequest()] - Exception"
					// + ExceptionUtils.getStackTrace(e));
				}
			}
		}
		// logger.debug("[ZAPService - openConnectionForPostRequest()] - End");
		return null;
	}
}

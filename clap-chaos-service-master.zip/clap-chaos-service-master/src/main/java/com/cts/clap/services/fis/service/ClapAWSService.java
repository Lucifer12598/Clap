package com.cts.clap.services.fis.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONArray;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.ec2.AmazonEC2;
import com.amazonaws.services.ec2.AmazonEC2ClientBuilder;
import com.amazonaws.services.ec2.model.DescribeInstancesRequest;
import com.amazonaws.services.ec2.model.DescribeInstancesResult;
import com.amazonaws.services.ec2.model.Instance;
import com.amazonaws.services.ec2.model.Reservation;
import com.amazonaws.services.ec2.model.Tag;
import com.amazonaws.services.fis.AWSFIS;
import com.amazonaws.services.fis.AWSFISClient;
import com.amazonaws.services.fis.model.CreateExperimentTemplateActionInput;
import com.amazonaws.services.fis.model.CreateExperimentTemplateRequest;
import com.amazonaws.services.fis.model.CreateExperimentTemplateResult;
import com.amazonaws.services.fis.model.CreateExperimentTemplateStopConditionInput;
import com.amazonaws.services.fis.model.CreateExperimentTemplateTargetInput;
import com.amazonaws.services.fis.model.StartExperimentRequest;
import com.amazonaws.services.fis.model.StartExperimentResult;
import com.cts.clap.services.fis.dao.MongoDAO;
import com.cts.clap.services.fis.data.ClapFISRequest;

public class ClapAWSService {
	org.json.simple.JSONObject prop = null;
	private final Logger logger = LogManager.getLogger();

	public ClapAWSService(String configProjectName) throws Exception {
		try {
			MongoDAO mongo = MongoDAO.getInstance();
			prop = mongo.getConfigDetails("ClapConfig", configProjectName,"aws");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("[ClapAWSService - ClapAWSService()] - Excception -" + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
	}

	public void executeStopInstance(ClapFISRequest fisRequest) throws Exception {

		logger.debug("[ClapAWSService - executeStopInstance()] - Start");
		fisRequest = describeInstance(fisRequest);
		String s3Region = (String) prop.get("awsRegion").toString();
		Region region = Region.getRegion(Regions.valueOf(s3Region));

		Map<String, String> parameterMap = new HashMap<>();

		Map<String, CreateExperimentTemplateTargetInput> targets = new HashMap<>();
		if (fisRequest.getInstance().size() >= Integer.parseInt(fisRequest.getResourceCount())) {

			if (fisRequest.getInstance() != null) {
				List<String> instanceList = fisRequest.getInstance().stream().map(id -> "arn:aws:ec2:"
						+ region.getName() + ":" + prop.get("awsAccountId").toString() + ":instance/" + id)
						.collect(Collectors.toList());
				targets.put("targets",
						new CreateExperimentTemplateTargetInput().withResourceType("aws:ec2:instance")
								.withResourceArns(instanceList)
								.withSelectionMode(fisRequest.getResourceCount().equalsIgnoreCase("ALL") ? "ALL"
										: "COUNT(" + fisRequest.getResourceCount() + ")"));
			} else {
				throw new Exception("Invalid request. Check instance health...");
			}
		} else {
			throw new Exception("Number of resources specified for operation are greater than running instances");
		}
		Map<String, String> actiontargetMap = new HashMap<>();
		actiontargetMap.put("Instances", "targets");
		Map<String, CreateExperimentTemplateActionInput> actions = new HashMap<>();

		actions.put("Stop-Instance", new CreateExperimentTemplateActionInput().withActionId("aws:ec2:stop-instances")
				.withDescription("aws:ec2:stop-instances").withParameters(parameterMap).withTargets(actiontargetMap));

		CreateExperimentTemplateStopConditionInput stopCondition = new CreateExperimentTemplateStopConditionInput()
				.withSource("none");
		BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(prop.get("awsAccVal").toString(),
				prop.get("awsSecVal").toString());
		AWSFIS client = AWSFISClient.builder().withRegion(region.getName())
				.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials)).build();
		CreateExperimentTemplateRequest request = new CreateExperimentTemplateRequest()
				.withDescription("Stop-Template-Code" + LocalDateTime.now())
				.withRoleArn("arn:aws:iam::" + prop.get("awsAccountId").toString() + ":role/FIS-Role")
				.withActions(actions).withTargets(targets).withStopConditions(stopCondition);
		CreateExperimentTemplateResult result = client.createExperimentTemplate(request);
		logger.debug("[ClapAWSService - executeStopInstance()] - stop-instance experiment template created");
		StartExperimentRequest startExperimentRequest = new StartExperimentRequest()
				.withExperimentTemplateId(result.getExperimentTemplate().getId()).withTags(
						(Map<String, String>) new HashMap<>().put("Name", "Stop-Template-Run-" + LocalDateTime.now()));

		StartExperimentResult experimentResult = client.startExperiment(startExperimentRequest);
		logger.debug("[ClapAWSService - executeStopInstance()] - stop Experiment template execution submitted");

		logger.debug("[ClapAWSService - executeStopInstance()] - End");
	}

	public void executeRebootInstance(ClapFISRequest fisRequest) throws Exception {

		logger.debug("[ClapAWSService - executeRestartInstance()] - Start");
		fisRequest = describeInstance(fisRequest);
		String s3Region = (String) prop.get("awsRegion").toString();
		Region region = Region.getRegion(Regions.valueOf(s3Region));

		Map<String, String> parameterMap = new HashMap<>();

		Map<String, CreateExperimentTemplateTargetInput> targets = new HashMap<>();
		if (fisRequest.getInstance().size() <= Integer.parseInt(fisRequest.getResourceCount())) {

			if (fisRequest.getInstance() != null) {
				List<String> instanceList = fisRequest.getInstance().stream().map(id -> "arn:aws:ec2:"
						+ region.getName() + ":" + prop.get("awsAccountId").toString() + ":instance/" + id)
						.collect(Collectors.toList());
				targets.put("targets",
						new CreateExperimentTemplateTargetInput().withResourceType("aws:ec2:instance")
								.withResourceArns(instanceList)
								.withSelectionMode(fisRequest.getResourceCount().equalsIgnoreCase("ALL") ? "ALL"
										: "COUNT(" + fisRequest.getResourceCount() + ")"));
			} else {
				throw new Exception("Invalid request. Check instance health...");
			}
		} else {
			throw new Exception("Number of resources specified for operation are greater than running instances");
		}
		Map<String, String> actiontargetMap = new HashMap<>();
		actiontargetMap.put("Instances", "targets");
		Map<String, CreateExperimentTemplateActionInput> actions = new HashMap<>();

		actions.put("Stop-Instance", new CreateExperimentTemplateActionInput().withActionId("aws:ec2:stop-instances")
				.withDescription("aws:ec2:reboot-instances").withParameters(parameterMap).withTargets(actiontargetMap));

		CreateExperimentTemplateStopConditionInput stopCondition = new CreateExperimentTemplateStopConditionInput()
				.withSource("none");
		BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(prop.get("awsAccVal").toString(),
				prop.get("awsSecVal").toString());
		AWSFIS client = AWSFISClient.builder().withRegion(region.getName())
				.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials)).build();
		CreateExperimentTemplateRequest request = new CreateExperimentTemplateRequest()
				.withDescription("Reboot-Template-Code" + LocalDateTime.now())
				.withRoleArn("arn:aws:iam::" + prop.get("awsAccountId").toString() + ":role/FIS-Role")
				.withActions(actions).withTargets(targets).withStopConditions(stopCondition);
		CreateExperimentTemplateResult result = client.createExperimentTemplate(request);
		logger.debug("[ClapAWSService - executeRestartInstance()] - restart experiment template created");
		StartExperimentRequest startExperimentRequest = new StartExperimentRequest()
				.withExperimentTemplateId(result.getExperimentTemplate().getId())
				.withTags((Map<String, String>) new HashMap<>().put("Name",
						"Reboot-Template-Run-" + LocalDateTime.now()));

		StartExperimentResult experimentResult = client.startExperiment(startExperimentRequest);
		logger.debug("[ClapAWSService - executeRestartInstance()] - Reboot Experiment template execution submitted");

		logger.debug("[ClapAWSService - executeRestartInstance()] - End");
	}

	public void executeTerminateInstance(ClapFISRequest fisRequest) throws Exception {

		logger.debug("[ClapAWSService - executeTerminateInstance()] - Start");
		fisRequest = describeInstance(fisRequest);
		String s3Region = (String) prop.get("awsRegion").toString();
		Region region = Region.getRegion(Regions.valueOf(s3Region));
		Map<String, String> parameterMap = new HashMap<>();
		// parameterMap.put("startInstancesAfterDuration", "PT2M");

		Map<String, CreateExperimentTemplateTargetInput> targets = new HashMap<>();
		if (fisRequest.getInstance().size() >= Integer.parseInt(fisRequest.getResourceCount())) {

			if (fisRequest.getInstance() != null) {
				List<String> instanceList = fisRequest.getInstance().stream().map(id -> "arn:aws:ec2:"
						+ region.getName() + ":" + prop.get("awsAccountId").toString() + ":instance/" + id)
						.collect(Collectors.toList());
				targets.put("targets",
						new CreateExperimentTemplateTargetInput().withResourceType("aws:ec2:instance")
								.withResourceArns(instanceList)
								.withSelectionMode(fisRequest.getResourceCount().equalsIgnoreCase("ALL") ? "ALL"
										: "COUNT(" + fisRequest.getResourceCount() + ")"));
			} else {
				throw new Exception("Invalid request. Check instance health...");
			}
		} else {
			throw new Exception("Number of resources specified for operation are greater than running instances");
		}

		Map<String, String> actiontargetMap = new HashMap<>();
		actiontargetMap.put("Instances", "targets");
		Map<String, CreateExperimentTemplateActionInput> actions = new HashMap<>();

		actions.put("Terminate-Instance",
				new CreateExperimentTemplateActionInput().withActionId("aws:ec2:terminate-instances")
						.withDescription("aws:ec2:terminate-instances").withParameters(parameterMap)
						.withTargets(actiontargetMap));

		CreateExperimentTemplateStopConditionInput stopCondition = new CreateExperimentTemplateStopConditionInput()
				.withSource("none");
		BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(prop.get("awsAccVal").toString(),
				prop.get("awsSecVal").toString());
		AWSFIS client = AWSFISClient.builder().withRegion(region.getName())
				.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials)).build();
		CreateExperimentTemplateRequest request = new CreateExperimentTemplateRequest()
				.withDescription("Terminate-Template-Code" + LocalDateTime.now())
				.withRoleArn("arn:aws:iam::" + prop.get("awsAccountId").toString() + ":role/FIS-Role")
				.withActions(actions).withTargets(targets).withStopConditions(stopCondition);

		CreateExperimentTemplateResult result = client.createExperimentTemplate(request);
		logger.debug("[ClapAWSService - executeTerminateInstance()] - experiment template created");

		StartExperimentRequest startExperimentRequest = new StartExperimentRequest()
				.withExperimentTemplateId(result.getExperimentTemplate().getId())
				.withTags((Map<String, String>) new HashMap<>().put("Name",
						"Terminate-Template-Run-" + LocalDateTime.now()));

		StartExperimentResult experimentResult = client.startExperiment(startExperimentRequest);
		logger.debug(
				"[ClapAWSService - executeTerminateInstance()] - terminate-instance experiment template submitted");

		logger.debug("[ClapAWSService - executeTerminateInstance()] - End");

	}

	public void executeCPUStress(ClapFISRequest fisRequest) throws Exception {

		logger.debug("[ClapAWSService - executeCPUStress()] - Start");
		fisRequest = describeInstance(fisRequest);
		String s3Region = (String) prop.get("awsRegion").toString();
		Region region = Region.getRegion(Regions.valueOf(s3Region));
		Map<String, String> parameterMap = new HashMap<>();
		parameterMap.put("duration", "PT" + fisRequest.getDuration() + "M");
		parameterMap.put("documentArn", "arn:aws:ssm:" + region.getName() + "::document/AWSFIS-Run-CPU-Stress");
		parameterMap.put("documentParameters", "{\"DurationSeconds\": \"600\"}");

		Map<String, CreateExperimentTemplateTargetInput> targets = new HashMap<>();
		if (fisRequest.getInstance().size() >= Integer.parseInt(fisRequest.getResourceCount())) {

			if (fisRequest.getInstance() != null) {
				List<String> instanceList = fisRequest.getInstance().stream().map(id -> "arn:aws:ec2:"
						+ region.getName() + ":" + prop.get("awsAccountId").toString() + ":instance/" + id)
						.collect(Collectors.toList());
				targets.put("targets",
						new CreateExperimentTemplateTargetInput().withResourceType("aws:ec2:instance")
								.withResourceArns(instanceList)
								.withSelectionMode(fisRequest.getResourceCount().equalsIgnoreCase("ALL") ? "ALL"
										: "COUNT(" + fisRequest.getResourceCount() + ")"));
			} else {
				throw new Exception("Invalid request. Check instance health...");
			}
		} else {
			throw new Exception("Number of resources specified for operation are greater than running instances");
		}
		Map<String, String> actiontargetMap = new HashMap<>();
		actiontargetMap.put("Instances", "targets");
		Map<String, CreateExperimentTemplateActionInput> actions = new HashMap<>();

		actions.put("CPU-Stress", new CreateExperimentTemplateActionInput().withActionId("aws:ssm:send-command")
				.withDescription("run cpu stress using ssm").withParameters(parameterMap).withTargets(actiontargetMap));

		CreateExperimentTemplateStopConditionInput stopCondition = new CreateExperimentTemplateStopConditionInput();
		stopCondition.withSource("none");

		BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(prop.get("awsAccVal").toString(),
				prop.get("awsSecVal").toString());
		AWSFIS client = AWSFISClient.builder().withRegion(region.getName())
				.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials)).build();
		CreateExperimentTemplateRequest request = new CreateExperimentTemplateRequest()
				.withDescription("CPU-Stress-Code" + LocalDateTime.now())
				.withRoleArn("arn:aws:iam::" + prop.get("awsAccountId").toString() + ":role/FIS-Role")
				.withActions(actions).withTargets(targets).withStopConditions(stopCondition);
		CreateExperimentTemplateResult result = client.createExperimentTemplate(request);
		logger.debug("[ClapAWSService - executeCPUStress()] - cpu-stress experiment template created");
		StartExperimentRequest startExperimentRequest = new StartExperimentRequest()
				.withExperimentTemplateId(result.getExperimentTemplate().getId())
				.withTags((Map<String, String>) new HashMap<>().put("Name", "Cpu-Stress-Run-" + LocalDateTime.now()));

		StartExperimentResult experimentResult = client.startExperiment(startExperimentRequest);
		logger.debug("[ClapAWSService - executeCPUStress()] - cpu-stress experiment template submitted ");

		logger.debug("[ClapAWSService - executeCPUStress()] - End");
	}

	public void executeMemoryStress(ClapFISRequest fisRequest) throws Exception {

		logger.debug("[ClapAWSService - executeMemoryStress()] - Start");
		fisRequest = describeInstance(fisRequest);
		String s3Region = (String) prop.get("awsRegion");
		Region region = Region.getRegion(Regions.valueOf(s3Region));
		Map<String, String> parameterMap = new HashMap<>();
		parameterMap.put("duration", "PT" + fisRequest.getDuration() + "M");
		parameterMap.put("documentArn", "arn:aws:ssm:" + region.getName() + "::document/AWSFIS-Run-Memory-Stress");
		parameterMap.put("documentParameters", "{\"DurationSeconds\": \"600\", \"Percent\": \"100\"}");

		Map<String, CreateExperimentTemplateTargetInput> targets = new HashMap<>();
		if (fisRequest.getInstance().size() >= Integer.parseInt(fisRequest.getResourceCount())) {

			if (fisRequest.getInstance() != null) {
				List<String> instanceList = fisRequest.getInstance().stream().map(id -> "arn:aws:ec2:"
						+ region.getName() + ":" + prop.get("awsAccountId").toString() + ":instance/" + id)
						.collect(Collectors.toList());
				targets.put("targets",
						new CreateExperimentTemplateTargetInput().withResourceType("aws:ec2:instance")
								.withResourceArns(instanceList)
								.withSelectionMode(fisRequest.getResourceCount().equalsIgnoreCase("ALL") ? "ALL"
										: "COUNT(" + fisRequest.getResourceCount() + ")"));
			} else {
				throw new Exception("Invalid request. Check instance health...");
			}
		} else {
			throw new Exception("Number of resources specified for operation are greater than running instances");
		}
		Map<String, String> actiontargetMap = new HashMap<>();
		actiontargetMap.put("Instances", "targets");
		Map<String, CreateExperimentTemplateActionInput> actions = new HashMap<>();

		actions.put("Memory-Stress",
				new CreateExperimentTemplateActionInput().withActionId("aws:ssm:send-command")
						.withDescription("run memory stress using ssm").withParameters(parameterMap)
						.withTargets(actiontargetMap));

		CreateExperimentTemplateStopConditionInput stopCondition = new CreateExperimentTemplateStopConditionInput();
		stopCondition.withSource("none");
		BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(prop.get("awsAccVal").toString(),
				prop.get("awsSecVal").toString());
		AWSFIS client = AWSFISClient.builder().withRegion(region.getName())
				.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials)).build();
		CreateExperimentTemplateRequest request = new CreateExperimentTemplateRequest()
				.withDescription("Memory-Stress-Code" + LocalDateTime.now())
				.withRoleArn("arn:aws:iam::" + prop.get("awsAccountId").toString() + ":role/FIS-Role")
				.withActions(actions).withTargets(targets).withStopConditions(stopCondition);

		CreateExperimentTemplateResult result = client.createExperimentTemplate(request);
		logger.debug("[ClapAWSService - executeMemoryStress()] - memory-stress experiment template created");
		StartExperimentRequest startExperimentRequest = new StartExperimentRequest()
				.withExperimentTemplateId(result.getExperimentTemplate().getId()).withTags(
						(Map<String, String>) new HashMap<>().put("Name", "Memory-Stress-Run-" + LocalDateTime.now()));

		StartExperimentResult experimentResult = client.startExperiment(startExperimentRequest);
		logger.debug("[ClapAWSService - executeMemoryStress()] - memory-stress experiment template submitted");

		logger.debug("[ClapAWSService - executeMemoryStress()] - End");
	}

	public ClapFISRequest describeInstance(ClapFISRequest fisRequest) {
		logger.debug("[ClapAWSService - describeInstance()] - Start");
		String s3Region = (String) prop.get("awsRegion");
		Region region = Region.getRegion(Regions.valueOf(s3Region));
		BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(prop.get("awsAccVal").toString(),
				prop.get("awsSecVal").toString());
		AmazonEC2 ec2Client = AmazonEC2ClientBuilder.standard()
				.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials)).withRegion(region.getName())
				.build();
		String resourceValue = null;
		for (Map.Entry<String, String> entry : fisRequest.getResourceTag().entrySet()) {
			resourceValue = entry.getValue();
		}

		// Filter filter=new Filter().withName("Coshofis-env");
		DescribeInstancesRequest requestInstance = new DescribeInstancesRequest();
		DescribeInstancesResult instanceResult = ec2Client.describeInstances(requestInstance);

		List<Reservation> reservationList = instanceResult.getReservations();
		JSONArray reservations = new JSONArray();
		List<String> instanceList = new ArrayList();
		for (Reservation res : reservationList) {
			// reservations.add(res);
			Reservation reservationObj = res;
			List<Instance> instanceArray = reservationObj.getInstances();
			Instance instance = instanceArray.get(0);
			List<Tag> tags = instance.getTags();
			for (Tag tag : tags) {

				if (resourceValue.equalsIgnoreCase(tag.getValue())) {
					if (!instanceList.contains(instance.getInstanceId())
							&& "running".equalsIgnoreCase(instance.getState().getName()))
						instanceList.add(instance.getInstanceId());

				}
			}

		}

		fisRequest.setInstance(instanceList);
		logger.debug("[ClapAWSService - describeInstance()] - End");
		return fisRequest;

	}
}

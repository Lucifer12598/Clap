package com.cts.clap.services.fis.service;

import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cts.clap.services.fis.data.ClapFISRequest;

public class ClapFISService {
	private final Logger logger = LogManager.getLogger();

	public void runChaosInAWS(ClapFISRequest fisRequest) throws Exception {

		logger.debug("[ClapFISService - runChaosInAWS()] - Start - fisRequest - ");
		switch (fisRequest.getType().toLowerCase(Locale.ENGLISH)) {
		case "stop-instance":
			new ClapAWSService(fisRequest.getConfigProjectName()).executeStopInstance(fisRequest);
			break;
		case "terminate-instance":
			new ClapAWSService(fisRequest.getConfigProjectName()).executeTerminateInstance(fisRequest);
			break;

		case "reboot-instance":
			new ClapAWSService(fisRequest.getConfigProjectName()).executeRebootInstance(fisRequest);
			break;
		case "cpu-stress":
			new ClapAWSService(fisRequest.getConfigProjectName()).executeCPUStress(fisRequest);
			break;
		case "memory-stress":
			new ClapAWSService(fisRequest.getConfigProjectName()).executeMemoryStress(fisRequest);
			break;
		case "desc":
			new ClapAWSService(fisRequest.getConfigProjectName()).describeInstance(fisRequest);
			break;
		default:
			throw new Exception("Invalid chaos Type");

		}
		logger.debug("[ClapFISService - runChaosInAWS()] - End");
	}
}

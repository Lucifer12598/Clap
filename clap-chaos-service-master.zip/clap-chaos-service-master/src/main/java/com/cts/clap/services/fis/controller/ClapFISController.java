package com.cts.clap.services.fis.controller;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cts.clap.services.fis.data.ClapFISRequest;
import com.cts.clap.services.fis.service.ClapFISService;

@Path("/api")
public class ClapFISController {

	private final Logger logger = LogManager.getLogger(this.getClass());

	@Path("/chaos-test")
	@POST()
	@Produces(MediaType.APPLICATION_JSON)
	public Response runChaos(ClapFISRequest fisRequest) throws Exception {

		logger.debug("[ClapFISController - runChaos()] Start - fisRequest " + fisRequest);
		ClapFISService fisService = new ClapFISService();
		new java.util.Timer().schedule(new java.util.TimerTask() {
			@Override
			public void run() {

				try {
					fisService.runChaosInAWS(fisRequest);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					logger.error("[ClapFISController - runChaos()] - Exception " + ExceptionUtils.getStackTrace(e));
				}
			}
		}, 3000);
		logger.debug("[ClapFISController - runChaos()] End ");
		return Response.status(Response.Status.OK).entity("Request submitted for chaos testing").build();

	}
}

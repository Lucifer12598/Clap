package com.cts.clap.services.fis.data;

import java.util.List;
import java.util.Map;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class ClapFISRequest {

	private String type;
	private String duration;
	private List<String> instance;
	private Map<String,String> resourceTag;
	private String resourceCount;
	private String configProjectName;
	
	
}

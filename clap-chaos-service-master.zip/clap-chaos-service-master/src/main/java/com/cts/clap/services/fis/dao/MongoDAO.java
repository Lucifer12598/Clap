package com.cts.clap.services.fis.dao;

import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bson.Document;
import org.json.simple.JSONObject;

import com.cts.clap.services.fis.util.ClapFISUtil;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoDAO {
	private String DbName;// ="scheduling_database";
	private String DbHostName;
	private String mongoDBUrl;

	private static MongoDAO instance;

	private final Logger logger = LogManager.getLogger();

	private MongoDAO() throws Exception {

		try {
			Properties prop = new ClapFISUtil().getClapProperties();
			this.DbName = prop.getProperty("DbName");
			this.DbHostName = prop.getProperty("DbHostName");
			this.mongoDBUrl = prop.getProperty("mongoDBURL");

		} catch (Exception ex) {
			logger.error("[MongoDAO - MongoDAO()] Exception in constructor - " + ExceptionUtils.getStackTrace(ex));
			throw new Exception(ex.getMessage());
		}
	}

	public static MongoDAO getInstance() throws Exception {
		if (instance == null) {
			instance = new MongoDAO();
		}
		return instance;
	}
	
	@SuppressWarnings("unchecked")
	public JSONObject getConfigDetails(String collectionName, String configProjectName, String cloudName)
			throws Exception {
		logger.debug("[MongoDAO - getConfigDetails()] Start - configProjectName - " + configProjectName
				+ " cloudName - " + cloudName);
		MongoClient mc = null;
		MongoDatabase md = null;
		MongoCollection<Document> mcoll = null;
		Document configDocument = null;
		JSONObject configObject = new JSONObject();
		String defaultConfig = null;
		try {
			MongoClientURI uri = new MongoClientURI(this.mongoDBUrl);
			mc = new MongoClient(uri);
			md = mc.getDatabase(DbName);
			mcoll = md.getCollection(collectionName);
			BasicDBObject query = new BasicDBObject("projectName", configProjectName);
			Document configDoc = mcoll.find(query).first();
			if (configDoc != null) {

				Document defaultConfigDoc = (Document) configDoc.get("defaultConfigName");
				if (cloudName.equalsIgnoreCase("aws")) {

					defaultConfig = defaultConfigDoc.get("aws").toString();
				} else if (cloudName.equalsIgnoreCase("azure")) {
					defaultConfig = defaultConfigDoc.get("azure").toString();
				}
				List<Document> configObjList = (List<Document>) configDoc.get("configList");
				for (Document configObj : configObjList) {
					if (configObj.get("configName").toString().equalsIgnoreCase(defaultConfig)
							&& configObj.get("checked").toString().equalsIgnoreCase("true")
							&& cloudName.equalsIgnoreCase("aws")) {
						configObject.put("awsAccVal", configObj.get("awsAccessKey").toString());
						configObject.put("awsSecVal", configObj.get("awsSecretKey").toString());
						configObject.put("awsRegion", configObj.get("awsRegion").toString());
						configObject.put("awsAccountId", configObj.get("awsAccountId").toString());
						
					}
			
				}
			} else {
				logger.error("[MongoDAO - getConfigDetails()] Exception - " + "No config found for " + configProjectName
						+ " project");
				throw new Exception("No config found for " + configProjectName + " project");
			}

		} catch (Exception ex) {
			logger.error("[MongoDAO - getConfigDetails()] Exception - " + ExceptionUtils.getStackTrace(ex));
			throw new Exception(ex.getMessage());
		} finally {
			mc.close();
		}
		logger.debug("[MongoDAO - getConfigDetails()] End");
		return configObject;
	}


}

package clap_questionnaire;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import logic.ScoreGenerator;

@Path("/api")
public class Controller {
	@GET
	@Path("/ping")
	@Produces(MediaType.TEXT_PLAIN)
	public Response check() {
		return Response.ok().entity("Server is Running").build();
	}
	
	@POST
	@Path("/calcualteScore")
	@Produces(MediaType.TEXT_PLAIN)
	public Response calculateScore(String jsonString) {
		ScoreGenerator generator = new ScoreGenerator();
		generator.submitAnswers(jsonString);
		return Response.ok().entity("Sucessfully Submitted").build();
	}
	
	@GET
	@Path("/getAnswersData/projectId/{projectId}")
	@Produces(MediaType.TEXT_PLAIN)
	public Response getAnswers(@PathParam("projectId") String projectId) {
		DbUtil util = new DbUtil();
		String response = util.getAnswersData(projectId);
		return Response.ok().entity(response).build();
	}
	
	@GET
	@Path("/getQuestionsData")
	@Produces(MediaType.TEXT_PLAIN)
	public Response getQuestions(@PathParam("projectId") String projectId) {
		DbUtil util = new DbUtil();
		String response = util.getQuestionDetails().toString();
		return Response.ok().entity(response).build();
	}
}

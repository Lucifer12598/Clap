package clap_questionnaire;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBCursor;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.util.JSON;

public class DbUtil {
	private static final String URI = "mongodb://clap:clap2021@ec2-65-1-251-42.ap-south-1.compute.amazonaws.com/CLAPDB";
	private static final Logger logger = Logger.getLogger(DbUtil.class);
	
	@SuppressWarnings("deprecation")
	public void storeAnswerData(String jsonString) {
		MongoClient mongoClient = new MongoClient(new MongoClientURI(URI));
		DB database = mongoClient.getDB("CLAPDB");
		DBCollection collection = database.getCollection("CloudAdvisory");
		DBObject dbObject = (DBObject) JSON.parse(jsonString);
		collection.insert(dbObject);
		logger.info("Document Inserted");
	}
	
	@SuppressWarnings("deprecation")
	public String getAnswersData(String projectId) {
		JSONArray result = new JSONArray();
		if(validateId(projectId)) {
			MongoClient mongoClient = new MongoClient(new MongoClientURI(URI));
			DB database = mongoClient.getDB("CLAPDB");
			DBCollection collection = database.getCollection("CloudAdvisory");
			BasicDBObject query = new BasicDBObject();
			query.put("Details.projectId", projectId);
			DBCursor cursor = collection.find(query);
			while(cursor.hasNext()) {
			    result.put(cursor.next());
			}
			logger.info("Answers fetched for project Id - "+projectId);
		}
		return result.toString();
	}
	
	@SuppressWarnings("deprecation")
	public JSONObject getQuestionDetails() {
		String result = null;
		MongoClient mongoClient = new MongoClient(new MongoClientURI(URI));
		DB database = mongoClient.getDB("CLAPDB");
		DBCollection collection = database.getCollection("CloudAdvisoryQuestions");
		DBCursor cursor = collection.find();
		while(cursor.hasNext()) {
			result = cursor.next().toString();
		}
		JSONObject object = new JSONObject(result);
		logger.info("Questions Fetched");
		return object;
	}
	
	private boolean validateId(String projectId) {
		String pattern= "^[a-zA-Z0-9]*$";
	    return projectId.matches(pattern);
	}
}

package logic;

import org.json.JSONArray;
import org.json.JSONObject;

import data.JsonStructure;
import data.QuestionData;

public class QuestionnaireLogic 
{
	private static JSONObject questions;
	private static JSONObject answers;
	private static QuestionData data;
	
    public static void main( String[] args )
    {
    	JsonStructure structure = new JsonStructure();
    	questions = structure.loadQuestionsJson(questions);
    	answers = structure.loadAnswersJson(answers);
    	data = new QuestionData();
        QuestionnaireLogic logic = new QuestionnaireLogic();
        logic.calculateScore();
    }
    
    private void calculateScore() {
    	JSONObject scores = new JSONObject();
    	JSONObject totalScores = new JSONObject();
    	
    	for(String key : questions.keySet()) {
    		JSONObject mainQuestionTopic = questions.getJSONObject(key);
    		JSONObject mainAnswersTopic = answers.getJSONObject(key);
    		for(String subKey : mainQuestionTopic.keySet()) {
    			data =  new QuestionData();
    			JSONObject subQuestionTopic = mainQuestionTopic.getJSONObject(subKey);
    			JSONObject subAnswerTopic = mainAnswersTopic.getJSONObject(subKey);
    			getWeightage(subQuestionTopic, subAnswerTopic);
    			JSONArray scoreArray = new JSONArray();
    			double totalScore = 0;
    			for(String questionKey : subQuestionTopic.keySet()) {
    				JSONObject question = subQuestionTopic.getJSONObject(questionKey);
    				JSONObject answer = subAnswerTopic.getJSONObject(questionKey);
    				String response = answer.getString("Response");
    				if(response.equalsIgnoreCase("yes")) {
    					double score = getCurrentScore(question);
    					scoreArray.put(score);
    					totalScore += score;
    				} else {
    					scoreArray.put(0);
    				}
    			}
    			if(data.getPercentage() < 0.6) {
    				totalScores.put(subKey, totalScore);
    			} else {
    				totalScores.put(subKey, -1);
    			}
    			scores.put(subKey, scoreArray);
    		}
    	}
    }
    
    private double getCurrentScore(JSONObject question) {
    	double weightage = question.getDouble("weightage");
		int score = question.getInt("score");
		double applicability = question.getInt("applicability");
		double applicabilityPercent = applicability/100;
		double currentWeightage = data.getWeight()+weightage;
		double currentScore = currentWeightage * score * applicabilityPercent;
		return currentScore;
    }
    
    private void getWeightage(JSONObject subQuestionTopic,JSONObject subAnswerTopic) {
    	double nonWeightCount = 0;
    	for(String key : subQuestionTopic.keySet()) {
			JSONObject question = subQuestionTopic.getJSONObject(key);
			JSONObject answer = subAnswerTopic.getJSONObject(key);
			String response = answer.getString("Response");
			if(response.equalsIgnoreCase("yes") || response.equalsIgnoreCase("no") 
					|| response.equalsIgnoreCase("")) {
				data.setCount(data.getCount()+1);
			} else if(response.equalsIgnoreCase("n/a")){
				double weightage = question.getDouble("weightage");
				data.setNonWeight(data.getNonWeight()+weightage);
				nonWeightCount += 1;
			}
			data.setTotalCount(data.getTotalCount()+1);
		}
    	data.setWeight(data.getNonWeight()/data.getCount());
    	double value = nonWeightCount/data.getTotalCount();
    	data.setPercentage(Math.round(value * 100.0)/100.0);
    }
}

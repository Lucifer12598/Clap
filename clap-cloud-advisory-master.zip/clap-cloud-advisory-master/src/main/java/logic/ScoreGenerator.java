package logic;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import clap_questionnaire.DbUtil;

public class ScoreGenerator {
	private double count = 0;
	private double totalScore = 0;
	private final List<String> answerTypes= Arrays.asList("yes","no","<30%",">30<60%",">60<100%",">30%<60%",">60%<100%","manual","automated","both","ad-hoc","unplanned","unsystematic","planned","");
	private static final Logger logger = Logger.getLogger(ScoreGenerator.class);
	
	public void submitAnswers(String jsonString) {
		ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(1);
		executor.submit(() -> {
			try {
				calculateScore(jsonString);
			} catch (Exception e) {
				logger.error(e);
			}
		});
	}
	
	private void calculateScore(String jsonString) {
		try {
			JSONObject requestObject = new JSONObject(jsonString);
			JSONObject answersObject = requestObject.getJSONObject("assessment");
			JSONObject discoveryObject = requestObject.getJSONObject("discovery");
			JSONObject categoriesObject = new JSONObject();
			JSONObject scoresObject = new JSONObject();
			logger.info("Calculating score for project id - "+requestObject.get("projectId"));

			DbUtil util = new DbUtil();
			JSONObject questionsObject = util.getQuestionDetails();
			for(String topicKey : answersObject.keySet()) {
				double topicCount = 0;
				double totalScore = 0;
				JSONObject subObject = answersObject.getJSONObject(topicKey);
				for(String questionKey : subObject.keySet()) {
					topicCount++;
					if(subObject.get(questionKey) instanceof JSONArray) {
						JSONArray answers = subObject.getJSONArray(questionKey);
						double score = getScore(answers);
						if(score == -1) {
							return;
						} else {
							totalScore += score;
						}
					} else if(subObject.get(questionKey) instanceof String){
						String answer = subObject.getString(questionKey).toLowerCase();
						if(answerTypes.contains(answer.trim().toLowerCase())) {
							switch(answer.toLowerCase()) {
								case "yes":totalScore += 1;break;
								case "<30%":totalScore += 0.3;break;
								case ">30<60%":totalScore += 0.6;break;
								case ">60<100%":totalScore += 1;break;
								case "manual":totalScore += 0.5;break;
								case "automated":totalScore += 1;break;
								case "both":totalScore += 1;break;
								case "ad-aoc":totalScore += 0;break;
								case "anplanned":totalScore += 0;break;
								case "ansystematic":totalScore += 0;break;
								case "planned":totalScore += 1;break;
								case "":totalScore += 0;break;
								default:totalScore += 0;break;
							}
						} else {
							logger.info("Invalid answer sent. Answer not present in whitelist.");
							return;
						}
					} else {
						logger.info("Invalid answer type sent. Only array and strings are supported.");
						return;
					}
				}
				
				double topicScore = totalScore/topicCount;
				this.totalScore += topicScore;
				count += topicScore > 0 ? 1 : 0;
				JSONObject subAnswer = new JSONObject();
				subAnswer.put("answers", subObject);
				subAnswer.put("score", topicScore);
				JSONArray recArray = new JSONArray();
				if(questionsObject.has(topicKey)) {
					recArray = getRecommendations(questionsObject.getJSONObject(topicKey),subObject);
				}
				subAnswer.put("recommendations",recArray);
				categoriesObject.put(topicKey, subAnswer);
			}
			
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			JSONObject detailsObject = new JSONObject();
			detailsObject.put("projectId", requestObject.get("projectId"));
			detailsObject.put("projectName", requestObject.get("projectName"));
			detailsObject.put("Overall Score", (totalScore/count));
			detailsObject.put("Timestamp", timestamp.getTime());
			scoresObject.put("Categories", categoriesObject);
			scoresObject.put("Details", detailsObject);
			scoresObject.put("Discovery", discoveryObject);
			
			String resultString = util.getAnswersData(requestObject.getString("projectId"));
			JSONArray resultArray = new JSONArray(resultString);
			if(resultString.isEmpty()) {
				scoresObject.put("runId", 1);
			} else {
				scoresObject.put("runId", getMaximum(resultArray));
			}
			util.storeAnswerData(scoresObject.toString());
		} catch(JSONException e) {
			logger.error(e);
		}
	}
	
	private double getScore(JSONArray answers) {
		double score = 0;
		double selectedCount = 0;
		for(int index = 0; index < answers.length(); index++) {
			String answer = answers.getString(index);
			String[] ansArray = answer.split("-");
			String selection = ansArray[ansArray.length-1];
			if(selection.equalsIgnoreCase("selected") || selection.equalsIgnoreCase("notselected")) {
				if(selection.equalsIgnoreCase("selected")) {
					selectedCount++;
				}
			} else {
				logger.info("Invalid answer sent in array of body");
				return -1;
			}
		}
		score = selectedCount/answers.length();
		return score;
	}
	
	private JSONArray getRecommendations(JSONObject details,JSONObject answers) {
		JSONArray recommendations = new JSONArray();
		for(String question : answers.keySet()) {
			if(details.has(question)) {
				JSONObject detailObject = details.getJSONObject(question);
				String type = detailObject.getString("answerType");
				if(type.equals("yes/no") && answers.get(question) instanceof String) {
					String ans = answers.getString(question);
					if(ans.equalsIgnoreCase("no")) {
						recommendations.put(detailObject.getString("Recommendations"));
					}
				} else if (type.equals("radio") && answers.get(question) instanceof String) {
					JSONArray answerArray = detailObject.has("validAnswer") ? detailObject.getJSONArray("validAnswer")
							: new JSONArray();
					String ans = answers.getString(question);
					if(!isPresent(answerArray, ans)) {
						recommendations.put(detailObject.getString("Recommendations"));
					}
				} else if(type.equals("multiselect") && answers.get(question) instanceof JSONArray) {
					JSONArray ans = answers.getJSONArray(question);
					if(detailObject.get("Recommendations") instanceof String) {
						String rec = detailObject.getString("Recommendations");
						appendRecommendation(rec, ans, recommendations);
					} else if(detailObject.get("Recommendations") instanceof JSONObject) {
						JSONObject recObject = detailObject.getJSONObject("Recommendations");
						if(isPresent(ans, "Contract Testing-notselected")) {
							recommendations.put(recObject.getString("Contract Testing-notselected"));
						}
						String rec = recObject.getString("generic");
						appendRecommendation(rec, ans, recommendations);
					}
				}
			}
		}
		return recommendations;
	}
	
	private void appendRecommendation(String rec, JSONArray ans, JSONArray recommendations) {
		if(rec.contains("~unselected~")) {
			StringBuffer names = new StringBuffer("");
			boolean isInitial = true;
			for(int index = 0; index < ans.length(); index++) {
				String lineAns = ans.getString(index);
				String[] ansArray = lineAns.split("-");
				String selection = ansArray[ansArray.length-1];
				if(selection.equalsIgnoreCase("notselected")) {
					String delimeter = isInitial ? "" :",";
					isInitial = false;
					names.append(delimeter+ansArray[0]);
				}
			}
			if(!names.toString().trim().isEmpty()) {
				rec = rec.replace("~unselected~", names);
				recommendations.put(rec);
			}
		} else {
			recommendations.put(rec);
		}
	}
	
	private int getMaximum(JSONArray array) {
		int id = 0;
		for(int index = 0; index < array.length(); index++) {
			JSONObject object = array.getJSONObject(index);
			int current = object.getInt("runId");
			id = current > id ? current : id;
		}
		return ++id;
	}
	
	private boolean isPresent(JSONArray array, String value) {
		for(int index = 0; index < array.length(); index++) {
			if(array.getString(index).equalsIgnoreCase(value)) {
				return true;
			}
		}
		return false;
	}
}

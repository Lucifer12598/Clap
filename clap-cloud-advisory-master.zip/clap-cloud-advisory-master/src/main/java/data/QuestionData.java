package data;

public class QuestionData {
	private int count;
	private double nonWeight;
	private double weight;
	private int totalCount;
	private double percentage;
	
	public QuestionData() {
		count = 0;
		nonWeight = 0;
		weight = 0;
		totalCount = 0;
		percentage = 0;
	}
	
	public double getNonWeight() {
		return nonWeight;
	}
	
	public void setNonWeight(double nonWeight) {
		this.nonWeight = nonWeight;
	}
	
	public int getCount() {
		return count;
	}
	
	public void setCount(int count) {
		this.count = count;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}
}

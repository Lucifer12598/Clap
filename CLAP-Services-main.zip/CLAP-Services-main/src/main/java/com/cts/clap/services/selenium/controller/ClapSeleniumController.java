package com.cts.clap.services.selenium.controller;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.cts.clap.services.selenium.dao.MongoDAO;
import com.cts.clap.services.selenium.data.ClapProjectRequest;
import com.cts.clap.services.selenium.data.ClapProjectResponse;
import com.cts.clap.services.selenium.services.ClapSeleniumService;

@Path("/api")
public class ClapSeleniumController {
	private final Logger logger = LogManager.getLogger();

	@Path("/create/project")
	@POST()
	@Produces(MediaType.APPLICATION_JSON)
	public Response createProject(ClapProjectRequest clapProjectRequest) throws Exception {
		logger.debug("[ClapSeleniumController - createProject()] - Start : clapProjectRequest - " + clapProjectRequest);
		ClapSeleniumService clapSeleniumService = new ClapSeleniumService();

		clapSeleniumService.authenticate();
		ClapProjectResponse response = clapSeleniumService.createProject(clapProjectRequest);
		if (response.isSuccess()) {
			logger.debug("[ClapSeleniumController - createProject()] - End");
			return Response.status(Response.Status.OK).entity(response).build();
		} else {
			logger.debug("[ClapSeleniumController - createProject()] - End");
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(response).build();
		}

	}

	@Path("/executeselenium")
	@POST()
	@Produces(MediaType.APPLICATION_JSON)
	public Response executeSeleniumScripts(ClapProjectRequest clapProjectRequest) throws Exception {
		logger.debug("[ClapSeleniumController - executeSeleniumScripts()] - Start : clapProjectRequest - "
				+ clapProjectRequest);
		ClapSeleniumService clapSeleniumService = new ClapSeleniumService();
		clapSeleniumService.authenticate();

		ClapProjectResponse response = clapSeleniumService.executeSeleniumScripts(clapProjectRequest);
		if (response.isSuccess()) {
			logger.debug("[ClapSeleniumController - executeSeleniumScripts()] - End");
			return Response.status(Response.Status.OK).entity(response).build();
		} else {
			logger.debug("[ClapSeleniumController - executeSeleniumScripts()] - End");
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(response).build();
		}
	}

	@Path("/status/{executionId}")
	@GET()
	@Produces(MediaType.APPLICATION_JSON)
	public Response getStatus(@PathParam("executionId") String executionId) throws Exception {

		ClapSeleniumService clapSeleniumService = new ClapSeleniumService();
		clapSeleniumService.authenticate();

		ClapProjectResponse response = clapSeleniumService.getTaskStatus(executionId);
		if (response.isSuccess()) {
			// logger.debug("[ClapSeleniumController - getStatus()] - End");
			return Response.status(Response.Status.OK).entity(response).build();
		} else {
			// logger.debug("[ClapSeleniumController - getStatus()] - End");
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(response).build();
		}
	}

	@Path("/detailedreport/{projectname}")
	@GET()
	@Produces(MediaType.APPLICATION_JSON)
	public Response getDetailedProjectReport(@PathParam("projectname") String projectname) throws Exception {
		logger.debug("[ClapSeleniumController - getDetailedProjectReport()] - Start : projectname - " + projectname);
		ClapSeleniumService clapSeleniumService = new ClapSeleniumService();
		clapSeleniumService.authenticate();

		ClapProjectResponse response = clapSeleniumService.getDetailedProjectReport(projectname);
		if (response.isSuccess()) {
			logger.debug("[ClapSeleniumController - getDetailedProjectReport()] - End");
			return Response.status(Response.Status.OK).entity(response).build();
		} else {
			logger.debug("[ClapSeleniumController - getDetailedProjectReport()] - End");
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(response).build();
		}
	}

	@Path("/execute/autosync")
	@POST()
	@Produces(MediaType.APPLICATION_JSON)
	public String executeScriptsAndGenerateReport(ClapProjectRequest clapProjectRequest) throws Exception {
		logger.debug("[ClapSeleniumController - executeScriptsAndGenerateReport()] - Start : clapProjectRequest - "
				+ clapProjectRequest);

		ClapSeleniumService clapSeleniumService = new ClapSeleniumService();
		clapSeleniumService.authenticate();

		// clapSeleniumService.startExecutionAndGenerateReport(clapProjectRequest);
		logger.debug("[ClapSeleniumController - executeScriptsAndGenerateReport()] - End");
		return "Execution request submitted successfully!";

	}

	@Path("/report/execution/{reportId}")
	@GET()
	@Produces(MediaType.APPLICATION_JSON)
	public Response getExecutionReport(@PathParam("reportId") String reportId) throws Exception {

		logger.debug("[ClapSeleniumController - getExecutionReport()] - Start : reportId - " + reportId);
		ClapSeleniumService clapSeleniumService = new ClapSeleniumService();
		clapSeleniumService.authenticate();

		ClapProjectResponse response = clapSeleniumService.getExecutionReport(reportId);
		if (response.isSuccess()) {
			logger.debug("[ClapSeleniumController - getExecutionReport()] - End");
			return Response.status(Response.Status.OK).entity(response).build();
		} else {
			logger.debug("[ClapSeleniumController - getExecutionReport()] - End");
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(response).build();
		}
	}

	@Path("/download/robo/{roboName}")
	@GET()
	@Produces(MediaType.APPLICATION_JSON)
	public String getExecution(@PathParam("roboName") String roboName) throws Exception {
		ClapSeleniumService clapSeleniumService = new ClapSeleniumService();
		clapSeleniumService.authenticate();
		// clapSeleniumService.checkRoboStatusAndDownload(roboName);

		return "roboDownload";
	}

	@Path("/report/{projectName}/live-status/{executionId}")
	@GET()
	@Produces(MediaType.APPLICATION_JSON)
	public ClapProjectResponse getReportExecutionDetails(@PathParam("projectName") String projectName,
			@PathParam("executionId") String executionId) throws Exception {
		logger.debug("[ClapSeleniumController - getReportExecutionDetails()] - Start :projectName : " + projectName
				+ " executionId - " + executionId);
		ClapSeleniumService clapSeleniumService = new ClapSeleniumService();
		clapSeleniumService.authenticate();

		ClapProjectResponse response = clapSeleniumService.getReportExecutionDetails(projectName, executionId);

		logger.debug("[ClapSeleniumController - getReportExecutionDetails()] - End");
		return response;
	}

	@Path("/report/mongo")
	@GET()
	@Produces(MediaType.APPLICATION_JSON)
	public String getExecutionMongo() throws Exception {
		MongoDAO mongo = MongoDAO.getInstance();

		mongo.getConfigDetails("ClapConfig", "native29");
		// return "Hello";
		// ClapSeleniumService clapSeleniumService = new ClapSeleniumService();
		// clapSeleniumService.authenticate();
		// clapSeleniumService.importTestCasesToTestPlanInLeap("contractTesting-2",
		// "craft_mvn_testng",
		// "https://token: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@github.com/gauravdeshpande0190/clapSelenium.git");
		return "success";
	}

	@Path("/report/attachment")
	@GET()
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAttachment() throws Exception {
		ClapSeleniumService clapSeleniumService = new ClapSeleniumService();
		clapSeleniumService.authenticate();

		ClapProjectResponse response = clapSeleniumService.attachments();
		if (response.isSuccess()) {
			logger.debug("[ClapSeleniumController - getStatus() End---] ");
			return Response.status(Response.Status.OK).entity(response).build();
		} else {
			logger.debug("[ClapSeleniumController - getStatus() End---] ");
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(response).build();
		}

	}

	@Path("/stop-aws-container/{serviceId}/project/{configProjectName}")
	@GET()
	@Produces(MediaType.APPLICATION_JSON)
	public String updateAwsContainerCountInService(@PathParam("serviceId") String serviceId,
			@PathParam("configProjectName") String configProjectName) throws Exception {
		ClapSeleniumService clapSeleniumService = new ClapSeleniumService();
		clapSeleniumService.authenticate();

		return clapSeleniumService.updateAwsContainerCountInService(0, serviceId, configProjectName);

	}

	@Path("/get/test-cases")
	@POST()
	@Produces(MediaType.APPLICATION_JSON)
	public String getTestCases(ClapProjectRequest clapProjectRequest) throws Exception {
		ClapSeleniumService clapSeleniumService = new ClapSeleniumService();
		clapSeleniumService.authenticate();

		return clapSeleniumService.importTestCasesToTestPlanInLeap(clapProjectRequest.getProjectName(),
				clapProjectRequest.getFrameworkName(), clapProjectRequest.getGitRepoURL());

	}

	@Path("/get/execution-logs/{executionId}")
	@GET()
	@Produces(MediaType.APPLICATION_JSON)
	public Response getExecutionLogs(@PathParam("executionId") String executionId) throws Exception {
		ClapSeleniumService clapSeleniumService = new ClapSeleniumService();
		clapSeleniumService.authenticate();
		ClapProjectResponse response = clapSeleniumService.getExecutionLogs(executionId);
		if (response.isSuccess()) {
			// logger.debug("[ClapSeleniumController - getStatus()] - End");
			return Response.status(Response.Status.OK).entity(response).build();
		} else {
			// logger.debug("[ClapSeleniumController - getStatus()] - End");
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(response).build();
		}

	}
}

package com.cts.clap.services.selenium.dao;

import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bson.Document;
import org.json.simple.JSONObject;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;

import com.cts.clap.services.selenium.util.ClapUtil;
import com.mongodb.BasicDBObject;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class MongoDAO {
	private String DbName;// ="scheduling_database";
	private String DbHostName;
	private String mongoDBUrl;

	private static MongoDAO instance;
	Properties prop = null;

	private final Logger logger = LogManager.getLogger();

	private MongoDAO() throws Exception {

		try {
			prop = new ClapUtil().getClapProperties();
			this.DbName = prop.getProperty("DbName");
			this.DbHostName = prop.getProperty("DbHostName");
			this.mongoDBUrl = prop.getProperty("mongoDBURL");

		} catch (Exception ex) {
			logger.error("[MongoDAO - MongoDAO()] Exception in constructor - " + ExceptionUtils.getStackTrace(ex));
			throw new Exception(ex.getMessage());
		}
	}

	public static MongoDAO getInstance() throws Exception {
		if (instance == null) {
			instance = new MongoDAO();
		}
		return instance;
	}

	public Document getFrameworkCollection(String collectionName, String frameworkName) throws Exception {
		logger.debug("[MongoDAO - getFrameworkCollection()] Start - frameworkName - " + frameworkName);
		MongoClient mc = null;
		MongoDatabase md = null;
		MongoCollection<Document> mcoll = null;
		Document frameworkDocument = null;

		try {
			MongoClientURI uri = new MongoClientURI(this.mongoDBUrl);
			mc = new MongoClient(uri);
			md = mc.getDatabase(DbName);
			mcoll = md.getCollection(collectionName);
			BasicDBObject query = new BasicDBObject("Name", frameworkName);
			frameworkDocument = mcoll.find(query).first();

		} catch (Exception ex) {
			logger.error("[MongoDAO - getFrameworkCollection()] Exception - " + ExceptionUtils.getStackTrace(ex));
			throw new Exception(ex.getMessage());
		} finally {
			mc.close();
		}
		logger.debug("[MongoDAO - getFrameworkCollection()] End");
		return frameworkDocument;
	}

	public JSONObject getConfigDetails(String collectionName, String configProjectName) throws Exception {
		logger.debug("[MongoDAO - getConfigDetails()] Start - configProjectName - " + configProjectName);
		MongoClient mc = null;
		MongoDatabase md = null;
		MongoCollection<Document> mcoll = null;
		Document configDocument = null;
		JSONObject configObject = new JSONObject();
		try {
			MongoClientURI uri = new MongoClientURI(this.mongoDBUrl);
			mc = new MongoClient(uri);
			md = mc.getDatabase(DbName);
			mcoll = md.getCollection(collectionName);
			BasicDBObject query = new BasicDBObject("projectName", configProjectName);
			Document configDoc = mcoll.find(query).first();
			if (configDoc != null) {
				String defaultConfig = configDoc.getString("defaultConfigName");
				List<Document> configObjList = (List<Document>) configDoc.get("configList");
				for (Document configObj : configObjList) {
					if (configObj.get("configName").toString().equalsIgnoreCase(defaultConfig)
							&& configObj.get("checked").toString().equalsIgnoreCase("true")) {
						configObject.put("awsAccVal", configObj.get("awsAccessKey").toString());
						configObject.put("awsSecVal", configObj.get("awsSecVal").toString());
						configObject.put("awsRegion", configObj.get("awsRegion").toString());
						configObject.put("awsAccountId", configObj.get("awsAccountId").toString());
						configObject.put("fargateSubnet", prop.getProperty("fargateSubnet"));
						configObject.put("fargateSecurityGroup", prop.getProperty("fargateSecurityGroup"));
						configObject.put("leapRoboToken", prop.getProperty("leapRoboToken"));
						configObject.put("cluster", prop.getProperty("cluster"));
						configObject.put("hostName", prop.get("hostName"));
						configObject.put("leapPort", prop.get("leapPort"));
						
					}
					

				}
			} else {
				logger.error("[MongoDAO - getConfigDetails()] Exception - " + "No config found for " + configProjectName
						+ " project");
				throw new Exception("No config found for " + configProjectName + " project");
			}

		} catch (Exception ex) {
			logger.error("[MongoDAO - getConfigDetails()] Exception - " + ExceptionUtils.getStackTrace(ex));
			throw new Exception(ex.getMessage());
		} finally {
			mc.close();
		}
		logger.debug("[MongoDAO - getConfigDetails()] End");
		return configObject;
	}

}

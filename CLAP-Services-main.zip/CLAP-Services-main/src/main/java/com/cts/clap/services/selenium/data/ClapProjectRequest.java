package com.cts.clap.services.selenium.data;

import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import org.json.JSONObject;
import org.json.simple.JSONArray;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
@XmlRootElement
public class ClapProjectRequest {

	private String projectName;
	private String frameworkName;
	private String gitUserName;
	private String gitPassword;
	private String gitRepoURL;
	private String testPlanName;
	private String testSuiteName;
	private String browserName;
	private String executionMode;
	private String scenarioID;
	private String executionType;
	private int containers;
	private String awsLeapServiceId;
	private String testSuiteId;
	private String commandUrl;
	private ClapExecutionRequest clapExecution;
	private JSONArray seletedTestCases;
	private String cloudName;
	private String configProjectName;
	
}

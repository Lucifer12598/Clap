package com.cts.clap.services.selenium.services;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.ecs.AmazonECS;
import com.amazonaws.services.ecs.AmazonECSClientBuilder;
import com.amazonaws.services.ecs.model.AssignPublicIp;
import com.amazonaws.services.ecs.model.AwsVpcConfiguration;
import com.amazonaws.services.ecs.model.Compatibility;
import com.amazonaws.services.ecs.model.ContainerDefinition;
import com.amazonaws.services.ecs.model.CreateServiceRequest;
import com.amazonaws.services.ecs.model.CreateServiceResult;
import com.amazonaws.services.ecs.model.KeyValuePair;
import com.amazonaws.services.ecs.model.LaunchType;
import com.amazonaws.services.ecs.model.LogConfiguration;
import com.amazonaws.services.ecs.model.LogDriver;
import com.amazonaws.services.ecs.model.NetworkConfiguration;
import com.amazonaws.services.ecs.model.NetworkMode;
import com.amazonaws.services.ecs.model.RegisterTaskDefinitionRequest;
import com.amazonaws.services.ecs.model.RegisterTaskDefinitionResult;
import com.amazonaws.services.logs.AWSLogs;
import com.amazonaws.services.logs.AWSLogsClient;
import com.amazonaws.services.logs.model.CreateLogGroupRequest;
import com.amazonaws.services.logs.model.CreateLogGroupResult;
import com.cts.clap.services.selenium.dao.MongoDAO;

public class AWSService {
	JSONObject prop = null;
	private final Logger logger = LogManager.getLogger();

	public AWSService(String dbName, String configProjectName) throws Exception {
		try {
			MongoDAO mongo = MongoDAO.getInstance();
			prop = mongo.getConfigDetails(dbName, configProjectName);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("[AWSService - AWSService()] - Excception -" + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
	}

	public CreateServiceResult createService(String taskDefinationName) throws Exception {
		logger.info("[AWSService - createService()] - Start ");
		try {

			String s3Region = (String) prop.get("awsRegion").toString();
			Region region = Region.getRegion(Regions.valueOf(s3Region));
			BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(prop.get("awsAccVal").toString(),
					prop.get("awsSecVal").toString());
			AmazonECS client = AmazonECSClientBuilder.standard().withRegion(region.getName())
					.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials)).build();
			String serviceName = UUID.randomUUID().toString();
			CreateServiceRequest request = new CreateServiceRequest().withLaunchType(LaunchType.FARGATE)
					.withServiceName(serviceName).withTaskDefinition(taskDefinationName).withEnableExecuteCommand(true)
					.withCluster(prop.get("cluster").toString()).withDesiredCount(0).withNetworkConfiguration(
							new NetworkConfiguration().withAwsvpcConfiguration(new AwsVpcConfiguration()
									.withSubnets(Arrays.asList(prop.get("fargateSubnet").toString().split(",")))
									.withSecurityGroups(prop.get("fargateSecurityGroup").toString())
									.withAssignPublicIp(AssignPublicIp.ENABLED)));

			CreateServiceResult response = client.createService(request);
			if (response.getService().getServiceName() != null) {
				String createdServiceName = response.getService().getServiceName();
				logger.info("[AWSService - createService()] - End : response service created");
			}
			return response;
		} catch (Exception e) {
			logger.error("[AWSService - createService()] - Excception -" + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
	}

	public RegisterTaskDefinitionResult createTaskDefination() throws Exception {
		logger.debug("[AWSService - createTaskDefination()] - Start");
		try {
			String s3Region = (String) prop.get("awsRegion").toString();
			Region region = Region.getRegion(Regions.valueOf(s3Region));
			BasicAWSCredentials basicAWSCredentials = new BasicAWSCredentials(prop.get("awsAccVal").toString(),
					prop.get("awsSecVal").toString());
			AmazonECS client = AmazonECSClientBuilder.standard().withRegion(region.getName())
					.withCredentials(new AWSStaticCredentialsProvider(basicAWSCredentials)).build();
			String serviceName = UUID.randomUUID().toString();
			logger.debug("[AWSService - createTaskDefination()] roboName  -" + serviceName + "-service");

			Collection<KeyValuePair> collection = new ArrayList<>();
			KeyValuePair pair = new KeyValuePair();
			pair.withName("LEAP_ROBOT_HOST");
			pair.withValue(prop.get("hostName") + ":" + prop.get("leapPort").toString() + "/api/execution/");
			collection.add(pair);
			pair = new KeyValuePair();
			pair.withName("LEAP_ROBOT_NAME");
			pair.withValue(serviceName + "-service");
			collection.add(pair);
			pair = new KeyValuePair();
			pair.withName("LEAP_ROBOT_TOKEN");
			pair.withValue(prop.get("leapRoboToken").toString());
			collection.add(pair);
			Map<String, String> logOptions = new HashMap<>();
			logOptions.put("awslogs-group", serviceName);
			logOptions.put("awslogs-region", region.getName());
			logOptions.put("awslogs-stream-prefix", "ecs");

			CreateLogGroupRequest logRequest = new CreateLogGroupRequest();
			logRequest.withLogGroupName(serviceName)
					.withRequestCredentialsProvider(new AWSStaticCredentialsProvider(basicAWSCredentials));

			AWSLogs builderLogs = AWSLogsClient.builder().withRegion(region.getName()).build();
			CreateLogGroupResult logResult = builderLogs.createLogGroup(logRequest);

			RegisterTaskDefinitionRequest request = new RegisterTaskDefinitionRequest()
					.withRequiresCompatibilities(Compatibility.FARGATE).withFamily(serviceName)
					.withExecutionRoleArn("ecsTaskExecutionRole").withNetworkMode(NetworkMode.Awsvpc)
					.withTaskRoleArn("ecsTaskExecutionRole").withCpu("512").withMemory("1024")
					.withContainerDefinitions(new ContainerDefinition().withName(serviceName)
							.withImage("leapci/robot:jdk-11-chrome").withEnvironment(collection).withLogConfiguration(
									new LogConfiguration().withLogDriver(LogDriver.Awslogs).withOptions(logOptions)));

			RegisterTaskDefinitionResult response = client.registerTaskDefinition(request);
			String taskDefinationName = response.getTaskDefinition().getFamily();
			logger.info("[AWSService - createTaskDefination()] End -- task defination createdF --- ");
			return response;
		} catch (Exception e) {
			logger.error("[AWSService - createTaskDefination()] Exception - " + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}

	}
}

package com.cts.clap.services.selenium.services;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Properties;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.bson.Document;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.amazonaws.services.ecs.model.CreateServiceResult;
import com.amazonaws.services.ecs.model.RegisterTaskDefinitionResult;
import com.cts.clap.services.selenium.dao.MongoDAO;
import com.cts.clap.services.selenium.data.ClapExecutionRequest;
import com.cts.clap.services.selenium.data.ClapProjectRequest;
import com.cts.clap.services.selenium.data.ClapProjectResponse;
import com.cts.clap.services.selenium.util.ClapUtil;

public class ClapSeleniumService {
	Properties prop = null;
	final private static String GET = "GET";
	final private static String POST = "POST";
	final private static String PUT = "PUT";
	final private static int _200 = 200;
	final private static int _201 = 201;
	private String token = null;
	private String robo_token = null;
	private final Logger logger = LogManager.getLogger();
	JSONObject awsConfig = null;
	MongoDAO mongoDAO;

	public ClapSeleniumService() throws Exception {
		try {
			prop = new ClapUtil().getClapProperties();
			mongoDAO = MongoDAO.getInstance();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			logger.error("[AWSService - AWSService()] - Excception -" + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
	}

	public String authenticate() {
		// logger.debug("[ClapSeleniumService - authenticate()] - Start");
		try {
			URL obj = new URL(prop.getProperty("hostName") + ":" + prop.getProperty("leapPort") + "/api/auth/token");
			HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
			postConnection.setRequestMethod("POST");
			postConnection.setRequestProperty("Content-Type", "application/json");
			postConnection.setConnectTimeout(200000);
			postConnection.setReadTimeout(200000);
			postConnection.setDoOutput(true);
			OutputStream os = postConnection.getOutputStream();

			JSONObject projectObjRequest = new JSONObject();

			JSONObject authRequestObject = new JSONObject();
			authRequestObject.put("type", "native");
			authRequestObject.put("username", "admin@leap.com");
			authRequestObject.put("password", "admin123");
			os.write(authRequestObject.toString().getBytes());
			os.flush();
			os.close();
			String readLine = null;
			BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
			StringBuffer response = new StringBuffer();
			while ((readLine = in.readLine()) != null) {
				response.append(readLine);
			}
			in.close();
			int responseCode = postConnection.getResponseCode();
			JSONObject tokenObject = (JSONObject) new JSONParser().parse(response.toString());
			token = "Bearer " + tokenObject.get("auth_token").toString();
			// logger.debug("[ClapSeleniumService - authenticate()] - End");
			return tokenObject.get("auth_token").toString();
		} catch (Exception e) {

			logger.error("[ClapSeleniumService - authenticate()] - Exception -" + e.getStackTrace());
		}
		// logger.debug("[ClapSeleniumService - authenticate()] - End");
		return null;

	}

	@SuppressWarnings("unchecked")
	public ClapProjectResponse createProject(ClapProjectRequest clapProjectRequest) {
		logger.debug("[ClapSeleniumService - createProject()] - Start");
		ClapProjectResponse response = null;
		JSONObject projectObject = null;
		try {
			JSONObject projectDetails = isProjectExists(clapProjectRequest.getProjectName());
			if (projectDetails == null) {
				createWorkbenchProject(clapProjectRequest.getProjectName());
				projectObject = createProjectInLeap(clapProjectRequest.getProjectName());
				logger.debug(
						"[ClapSeleniumService - createProject()] - Project obj after creation -- " + projectObject);
				createReportProject(clapProjectRequest.getProjectName());
				JSONObject frameworkObj = isFrameworkExists(clapProjectRequest.getFrameworkName());
				if (frameworkObj == null) {
					createToolInLeap(clapProjectRequest.getFrameworkName(), clapProjectRequest.getGitRepoURL());
					createGithubPropertyInLeap(clapProjectRequest.getProjectName(),
							clapProjectRequest.getFrameworkName(), clapProjectRequest.getGitUserName(),
							clapProjectRequest.getGitPassword());
				} else {
					updateFrameworkInLeap(clapProjectRequest);
				}

				response = createTestPlanSuite(clapProjectRequest, projectObject, "created");

			} else {
				logger.debug("[ClapSeleniumService - createProject()] - Project already exists");
				projectObject = isProjectExists(clapProjectRequest.getProjectName());
				JSONObject frameworkObj = isFrameworkExists(clapProjectRequest.getFrameworkName());
				if (frameworkObj == null) {
					createToolInLeap(clapProjectRequest.getFrameworkName(), clapProjectRequest.getGitRepoURL());
					createGithubPropertyInLeap(clapProjectRequest.getProjectName(),
							clapProjectRequest.getFrameworkName(), clapProjectRequest.getGitUserName(),
							clapProjectRequest.getGitPassword());
				} else {
					updateFrameworkInLeap(clapProjectRequest);
				}
				// createGithubPropertyInLeap(projectName, frameworkName);
				response = createTestPlanSuite(clapProjectRequest, projectObject, "updated");
			}
		} catch (Exception e) {
			logger.error("[ClapSeleniumService - createProject()] - Exception -" + ExceptionUtils.getStackTrace(e));
			response = new ClapProjectResponse();
			response.setSuccess(false);
			response.setMessage("Error in project create/update.");
		}
		logger.debug("[ClapSeleniumService - createProject()] - End");
		return response;
	}

	@SuppressWarnings({ "unchecked" })
	private void updateFrameworkInLeap(ClapProjectRequest clapProjectRequest) throws Exception {
		logger.debug("[ClapSeleniumService - updateFrameworkInLeap()] - Start");
		logger.debug("[ClapSeleniumService - updateFrameworkInLeap()] - frameworkName - "
				+ clapProjectRequest.getFrameworkName());
		JSONObject frameworkObj = isFrameworkExists(clapProjectRequest.getFrameworkName());
		JSONObject properties = (JSONObject) frameworkObj.get("properties");
		String windowsSteps = null;
		String unixSteps = null;
		JSONObject executionSteps = (JSONObject) frameworkObj.get("executionStepsDetails");
		if (null != clapProjectRequest.getCommandUrl()) {

			if (null != executionSteps) {
				JSONArray windowsExecutionSteps = (JSONArray) executionSteps.get("windows");
				JSONArray unixExecutionSteps = (JSONArray) executionSteps.get("unix");
				if (windowsExecutionSteps.size() > 0) {
					windowsSteps = (String) windowsExecutionSteps.get(0);
					if (windowsSteps.contains("-Durl")) {
						windowsSteps = windowsSteps.substring(0, windowsSteps.indexOf(" -Durl"));
					}
					windowsSteps += " -Durl=" + clapProjectRequest.getCommandUrl();
				}
				if (unixExecutionSteps.size() > 0) {
					unixSteps = (String) unixExecutionSteps.get(0);
					if (unixSteps.contains("-Durl")) {
						unixSteps = unixSteps.substring(0, unixSteps.indexOf(" -Durl"));
					}
					unixSteps += " -Durl=" + clapProjectRequest.getCommandUrl();
				}

				windowsExecutionSteps.removeAll(windowsExecutionSteps);
				windowsExecutionSteps.add(windowsSteps);
				unixExecutionSteps.removeAll(unixExecutionSteps);
				unixExecutionSteps.add(unixSteps);
				executionSteps.replace("windows", windowsExecutionSteps);
				executionSteps.replace("unix", unixExecutionSteps);
				frameworkObj.replace("executionStepsDetails", executionSteps);
			}

		} else {
			if (null != executionSteps) {
				JSONArray windowsExecutionSteps = (JSONArray) executionSteps.get("windows");
				JSONArray unixExecutionSteps = (JSONArray) executionSteps.get("unix");
				if (windowsExecutionSteps.size() > 0) {
					windowsSteps = (String) windowsExecutionSteps.get(0);
					windowsSteps = windowsSteps.contains(" -Durl")
							? windowsSteps.substring(0, windowsSteps.indexOf(" -Durl")) : windowsSteps;
				}
				if (unixExecutionSteps.size() > 0) {
					unixSteps = (String) unixExecutionSteps.get(0);
					unixSteps = unixSteps.contains(" -Durl") ? unixSteps.substring(0, unixSteps.indexOf(" -Durl"))
							: unixSteps;
				}

				windowsExecutionSteps.removeAll(windowsExecutionSteps);
				windowsExecutionSteps.add(windowsSteps);
				unixExecutionSteps.removeAll(unixExecutionSteps);
				unixExecutionSteps.add(unixSteps);
				executionSteps.replace("windows", windowsExecutionSteps);
				executionSteps.replace("unix", unixExecutionSteps);
				frameworkObj.replace("executionStepsDetails", executionSteps);
			}
		}
		if (null != clapProjectRequest.getBrowserName()) {
			if (null != executionSteps) {
				JSONArray windowsExecutionSteps = (JSONArray) executionSteps.get("windows");
				JSONArray unixExecutionSteps = (JSONArray) executionSteps.get("unix");
				if (windowsExecutionSteps.size() > 0) {
					windowsSteps = (String) windowsExecutionSteps.get(0);
					if (windowsSteps.contains(" -Dbrowser")) {
						windowsSteps = windowsSteps.substring(0, windowsSteps.indexOf(" -Dbrowser"));
					}
					windowsSteps += " -Dbrowser=" + clapProjectRequest.getBrowserName() + "_headless";
				}
				if (unixExecutionSteps.size() > 0) {
					unixSteps = (String) unixExecutionSteps.get(0);
					if (unixSteps.contains(" -Dbrowser")) {
						unixSteps = unixSteps.substring(0, unixSteps.indexOf(" -Dbrowser"));
					}
					unixSteps += " -Dbrowser=" + clapProjectRequest.getBrowserName() + "_headless";
				}

				windowsExecutionSteps.removeAll(windowsExecutionSteps);
				windowsExecutionSteps.add(windowsSteps);
				unixExecutionSteps.removeAll(unixExecutionSteps);
				unixExecutionSteps.add(unixSteps);
				executionSteps.replace("windows", windowsExecutionSteps);
				executionSteps.replace("unix", unixExecutionSteps);
				frameworkObj.replace("executionStepsDetails", executionSteps);
			}

		} else {
			if (null != executionSteps) {
				JSONArray windowsExecutionSteps = (JSONArray) executionSteps.get("windows");
				JSONArray unixExecutionSteps = (JSONArray) executionSteps.get("unix");
				if (windowsExecutionSteps.size() > 0) {
					windowsSteps = (String) windowsExecutionSteps.get(0);
					windowsSteps = windowsSteps.contains(" -Dbrowser")
							? windowsSteps.substring(0, windowsSteps.indexOf(" -Dbrowser")) : windowsSteps;
				}
				if (unixExecutionSteps.size() > 0) {
					unixSteps = (String) unixExecutionSteps.get(0);
					unixSteps = unixSteps.contains(" -Dbrowser")
							? unixSteps.substring(0, unixSteps.indexOf(" -Dbrowser")) : unixSteps;
				}

				windowsExecutionSteps.removeAll(windowsExecutionSteps);
				windowsExecutionSteps.add(windowsSteps);
				unixExecutionSteps.removeAll(unixExecutionSteps);
				unixExecutionSteps.add(unixSteps);
				executionSteps.replace("windows", windowsExecutionSteps);
				executionSteps.replace("unix", unixExecutionSteps);
				frameworkObj.replace("executionStepsDetails", executionSteps);
			}
		}

		if (!clapProjectRequest.getGitRepoURL().trim().equalsIgnoreCase(properties.get("repo-url").toString())) {
			String repoUrl = clapProjectRequest.getGitRepoURL().trim();
			properties.replace("repo-url", repoUrl);
			frameworkObj.replace("config", "repo-url:" + repoUrl);
			frameworkObj.replace("properties", properties);
			frameworkObj.put("pattern", "{name}");

		}

		logger.debug(
				"[ClapSeleniumService - updateFrameworkInLeap()] - frameworkObj after modification in execution step -"
						+ frameworkObj);
		updateToolInLeap(frameworkObj);
		logger.debug("[ClapSeleniumService - updateFrameworkInLeap()] - End");
	}

	@SuppressWarnings("unchecked")
	private ClapProjectResponse createTestPlanSuite(ClapProjectRequest clapProjectRequest, JSONObject projectObject,
			String type) throws Exception {
		logger.debug("[ClapSeleniumService - createTestPlanSuite()] - Start");
		String projectName = clapProjectRequest.getProjectName();
		String frameworkName = clapProjectRequest.getFrameworkName();
		String serviceId = null;
		ClapProjectResponse response = new ClapProjectResponse();
		String importTestCaseResponse = importTestCasesToTestPlanInLeap(projectName, frameworkName,
				clapProjectRequest.getGitRepoURL());
		String testPlanName = createTestPlanInLeap(projectObject, frameworkName, importTestCaseResponse);
		String testSuite = createTestSuiteInLeap(projectObject, frameworkName, importTestCaseResponse,
				clapProjectRequest.getGitRepoURL().trim(), clapProjectRequest.getExecutionType());
		String testSuiteName = testSuite.split(" ~ ")[0];
		String testSuiteId = testSuite.split(" ~ ")[1];

		JSONObject dataObject = new JSONObject();
		dataObject.put("testPlanName", testPlanName);
		dataObject.put("testSuiteName", testSuiteName.trim());
		dataObject.put("testSuiteId", testSuiteId.trim());
		dataObject.put("awsLeapServiceId", serviceId);
		dataObject.put("awsLeapServiceName", projectName + "_service");
		response.setData(dataObject);
		response.setSuccess(true);
		response.setMessage("Project " + type + " successfully!.");
		logger.debug("[ClapSeleniumService - createTestPlanSuite()] - End");
		return response;
	}

	@SuppressWarnings("unchecked")
	public String createAzureLeapService(String serviceName) throws Exception {
		logger.debug("[ClapSeleniumService - createAzureLeapService()] - Start : serviceName - " + serviceName);
		try {

			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
					+ "/api/execution/cloud/azure/robots/";
			JSONObject azureObjRequest = new JSONObject();

			azureObjRequest.put("containerName", serviceName);
			azureObjRequest.put("location", "central india");

			azureObjRequest.put("name", serviceName);
			azureObjRequest.put("username", "794895@cognizant.com");
			azureObjRequest.put("resourceGroupName", "leapResourceGroup");

			azureObjRequest.put("imageName", "leapci/robot:jdk-11-chrome");
			azureObjRequest.put("osType", "Linux");
			JSONArray envVariables = new JSONArray();
			JSONObject obj = new JSONObject();
			obj.put("name", "LEAP_ROBOT_HOST");
			obj.put("value", prop.get("hostName") + ":" + prop.getProperty("leapPort") + "/api/execution");
			envVariables.add(obj);
			JSONObject obj1 = new JSONObject();
			obj1.put("name", "LEAP_ROBOT_NAME");
			obj1.put("value", serviceName);
			envVariables.add(obj1);
			JSONObject obj2 = new JSONObject();
			obj2.put("name", "LEAP_ROBOT_TOKEN");
			obj2.put("value", "640c6dda-58c3-4928-a98d-87a3a09be0b1");
			envVariables.add(obj2);
			azureObjRequest.put("environmentVariables", envVariables);
			StringBuffer response = openConnectionForPostRequest(url, POST, azureObjRequest);
			JSONObject serviceObj = (JSONObject) new JSONParser().parse(response.toString());
			if (null != serviceObj) {
				logger.debug("[ClapSeleniumService - createAzureLeapService()] - End - success");
				return serviceObj.get("id").toString();
			} else {
				logger.debug("[ClapSeleniumService - createAzureLeapService()] - End - no result");
				return null;
			}
		} catch (Exception e) {
			logger.error("[ClapSeleniumService - createAzureLeapService()] - Exception - "
					+ ExceptionUtils.getStackTrace(e));
			throw new Exception("Azure Service not created.");
		}

	}

	@SuppressWarnings("unchecked")
	private String createAWSLeapService(String serviceName) throws Exception {
		logger.info("[ClapSeleniumService - createAWSLeapService()] - Start");
		try {
			URL obj = new URL(prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
					+ "/api/execution/cloud/aws/robots/");

			HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
			postConnection.setRequestMethod("POST");
			postConnection.setRequestProperty("Authorization", token);
			postConnection.setRequestProperty("Content-Type", "application/json");
			postConnection.setConnectTimeout(200000);
			postConnection.setReadTimeout(200000);
			postConnection.setDoOutput(true);
			OutputStream os = postConnection.getOutputStream();
			JSONObject serviceRequestObj = new JSONObject();

			serviceRequestObj.put("accessId", awsConfig.get("awsAccVal"));
			serviceRequestObj.put("zone", awsConfig.get("awsRegion"));

			serviceRequestObj.put("name", serviceName);
			serviceRequestObj.put("cluster", awsConfig.get("cluster"));

			serviceRequestObj.put("tasks", 0);

			os.write(serviceRequestObj.toString().getBytes());
			os.flush();
			os.close();
			String readLine = null;
			int responseCode = postConnection.getResponseCode();
			if (201 == responseCode) {
				BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
				StringBuffer response = new StringBuffer();
				while ((readLine = in.readLine()) != null) {
					response.append(readLine);
				}
				in.close();

				JSONObject serviceObj = (JSONObject) new JSONParser().parse(response.toString());
				if (null != serviceObj) {
					logger.debug("[ClapSeleniumService - createAWSLeapService()] - End");
					return serviceObj.get("id").toString();
				}
			}
		} catch (Exception e) {
			logger.debug(
					"[ClapSeleniumService - createAWSLeapService()] - Exception - " + ExceptionUtils.getStackTrace(e));
			throw new Exception("AWS Service not created.");
		}
		logger.debug("[ClapSeleniumService - createAWSLeapService()] - End");
		return null;
	}

	private String getLeapCloudServiceId(String serviceName) throws Exception {
		try {
			logger.debug("[ClapSeleniumService - getLeapCloudServiceId()] - Start : serviceName -" + serviceName);
			URL obj = new URL(prop.getProperty("hostName") + ":" + prop.getProperty("roboPort")
					+ "/cloud/aws/robots/search?name=" + serviceName);
			HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
			postConnection.setRequestMethod("GET");
			postConnection.setRequestProperty("Authorization", token);
			postConnection.setRequestProperty("Content-Type", "application/json");
			postConnection.setConnectTimeout(200000);
			postConnection.setReadTimeout(200000);
			postConnection.setDoOutput(true);

			String readLine = null;
			if (200 == postConnection.getResponseCode()) {
				BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
				StringBuffer response = new StringBuffer();
				while ((readLine = in.readLine()) != null) {
					response.append(readLine);
				}
				in.close();
				// print result

				JSONObject serviceObj = (JSONObject) new JSONParser().parse(response.toString());
				logger.debug("[ClapSeleniumService - getLeapCloudServiceId()] - End");
				return serviceObj.get("id").toString();

			} else {

				logger.debug("[ClapSeleniumService - getLeapCloudServiceId()] - End");
				return null;
			}

		} catch (Exception e) {
			logger.error(
					"[ClapSeleniumService - getLeapCloudServiceId()] - Exception - " + ExceptionUtils.getStackTrace(e));
			throw new Exception("Error fetching service details");
		}

	}

	private JSONObject createReportProject(String projectName) throws Exception {
		// TODO Auto-generated method stub
		logger.debug("[ClapSeleniumService - createReportProject()] - Start - " + projectName);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
					+ "/api/reports/dashboard/projects/";
			JSONObject projectObjRequest = new JSONObject();
			projectObjRequest.put("name", projectName);
			projectObjRequest.put("description", "Created by clap code");
			StringBuffer response = openConnectionForPostRequest(url, POST, projectObjRequest);
			if (null != response) {
				JSONObject projectObj = (JSONObject) new JSONParser().parse(response.toString());
				if (null != projectObj) {
					logger.debug("[ClapSeleniumService - createReportProject()] - End");
					return projectObj;
				}
			}
		} catch (Exception e) {
			logger.error(
					"[ClapSeleniumService - createReportProject()] - Exception - " + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - createReportProject()] - End");
		return null;

	}

	private JSONObject createWorkbenchProject(String projectName) throws Exception {
		logger.debug("[ClapSeleniumService - createWorkbenchProject()] - Start - " + projectName);
		JSONObject workbenchProjectRequest = buildWorkbenchProjectRequest(projectName);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort") + "/api/workbench/projects";
			StringBuffer response = openConnectionForPostRequest(url, POST, workbenchProjectRequest);
			if (null != response) {
				JSONObject projectObj = (JSONObject) new JSONParser().parse(response.toString());
				if (null != projectObj) {
					logger.debug("[ClapSeleniumService - createWorkbenchProject()] - End");
					return projectObj;
				}
			}
		} catch (Exception e) {
			logger.error("[ClapSeleniumService - createWorkbenchProject()] - Exception - "
					+ ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - createWorkbenchProject()] - End");
		return null;
	}

	@SuppressWarnings("unchecked")
	public JSONObject buildWorkbenchProjectRequest(String projectName) {
		JSONObject workBenchProjectRequest = new JSONObject();
		JSONObject ci = new JSONObject();
		JSONObject docker = new JSONObject();
		JSONObject pipeline = new JSONObject();
		JSONArray stagesArray = new JSONArray();
		JSONObject stageObject = new JSONObject();
		JSONObject data = new JSONObject();
		workBenchProjectRequest.put("type", "jenkins");
		workBenchProjectRequest.put("version", "2.0");
		workBenchProjectRequest.put("platform", "windows");
		workBenchProjectRequest.put("name", projectName);
		ci.put("name", "jenkins");
		ci.put("type", "docker");
		docker.put("name", "jenkins");
		ci.put("docker", docker);
		stageObject.put("id", "pipeline-config");
		stageObject.put("parallel", false);
		stageObject.put("toolId", "pipeline-config");
		stageObject.put("type", "config");
		data.put("type", "pipeline");
		data.put("steps", new JSONArray());
		stageObject.put("data", data);
		stagesArray.add(stageObject);
		pipeline.put("stages", stagesArray);
		ci.put("pipeline", pipeline);
		workBenchProjectRequest.put("ci", ci);
		return workBenchProjectRequest;
	}

	@SuppressWarnings("unchecked")
	private JSONObject createProjectInLeap(String projectName) throws Exception {
		logger.debug("[ClapSeleniumService - createProjectInLeap()] - Start - " + projectName);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
					+ "/api/execution/execution/projects/";

			JSONObject projectObjRequest = new JSONObject();
			projectObjRequest.put("name", projectName);
			projectObjRequest.put("description", "Created by clap code");
			StringBuffer response = openConnectionForPostRequest(url, POST, projectObjRequest);
			if (null != response) {
				JSONObject projectObj = (JSONObject) new JSONParser().parse(response.toString());
				if (null != projectObj) {
					logger.debug("[ClapSeleniumService - createProjectInLeap()] - End");
					return projectObj;
				}
			}
		} catch (Exception e) {
			logger.error(
					"[ClapSeleniumService - createProjectInLeap()] - Exception - " + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());

		}
		logger.debug("[ClapSeleniumService - createProjectInLeap()] - End");
		return null;
	}

	private void createToolInLeap(String frameWorkName, String gitUrl) throws Exception {
		logger.debug("[ClapSeleniumService - createToolInLeap()] - Start - frameWorkName : " + frameWorkName);
		logger.debug("[ClapSeleniumService - createToolInLeap()] - gitUrl : " + gitUrl);
		JSONObject toolRequestObject = buildFrameWorkObject(frameWorkName, gitUrl);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
					+ "/api/execution/tool-config/";
			StringBuffer response = openConnectionForPostRequest(url, POST, toolRequestObject);
			if (null != response) {
				logger.debug("[ClapSeleniumService - createToolInLeap()] response - " + response);
			}
		} catch (Exception e) {
			logger.error("[ClapSeleniumService - createToolInLeap()] - Exception - " + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - createToolInLeap()] - End");
	}

	private void updateToolInLeap(JSONObject frameworkObject) throws Exception {
		logger.debug("[ClapSeleniumService - updateToolInLeap()] - Start - frameworkObj - " + frameworkObject);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("roboPort") + "/tool-config";
			openConnectionForPostRequest(url, PUT, frameworkObject);
		} catch (Exception e) {
			logger.error("[ClapSeleniumService - createToolInLeap()] - Exception - " + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - updateToolInLeap()] - End");
	}

	@SuppressWarnings("unchecked")
	private JSONObject buildFrameWorkObject(String frameWorkName, String gitUrl) throws Exception {
		logger.debug("[ClapSeleniumService - buildFrameWorkObject()] - Start - frameWorkName - " + frameWorkName);
		MongoDAO mongoDAO = MongoDAO.getInstance();

		Document frameworkDocument = mongoDAO.getFrameworkCollection("Framework",
				frameWorkName.contains("~") ? frameWorkName.split("~")[0] : frameWorkName);
		String buildWindowsContent = null;
		String buildUnixContent = null;
		String buildWindowsExecutionContent = null;
		String buildUnixExecutionContent = null;
		JSONObject toolRequestObject = new JSONObject();
		if (null != frameworkDocument) {

			JSONObject buildStepDetails = new JSONObject();
			JSONObject executionStepsDetails = new JSONObject();
			JSONObject properties = new JSONObject();
			JSONArray windowsArray = new JSONArray();
			JSONArray windowsExecutionArray = new JSONArray();
			JSONArray unixExecutionArray = new JSONArray();
			JSONArray unixArray = new JSONArray();
			toolRequestObject.put("name", frameWorkName.contains("~") ? frameWorkName.split("~")[1] : frameWorkName);
			List<Document> buildObjList = (List<Document>) frameworkDocument.get("Build");
			for (Document buildObj : buildObjList) {
				String buildType = (String) buildObj.get("Type");

				if (buildType.equalsIgnoreCase("Windows")) {
					buildWindowsContent = (null == (String) buildObj.get("Steps") ? ""
							: (String) buildObj.get("Steps"));
				} else if (buildType.equalsIgnoreCase("unix")) {
					buildUnixContent = (null == (String) buildObj.get("Steps") ? "" : (String) buildObj.get("Steps"));
				}
			}
			windowsArray.add(buildWindowsContent);
			unixArray.add(buildUnixContent);
			buildStepDetails.put("windows", windowsArray);
			buildStepDetails.put("unix", unixArray);
			toolRequestObject.put("buildStepsDetails", buildStepDetails);
			List<Document> executionObjList = (List<Document>) frameworkDocument.get("Execution");
			for (Document executionType : executionObjList) {
				String executionTypeList = (String) executionType.get("Type");

				if (executionTypeList.equalsIgnoreCase("Windows")) {
					buildWindowsExecutionContent = (String) executionType.get("Steps");
				} else if (executionTypeList.equalsIgnoreCase("unix")) {
					buildUnixExecutionContent = (null == (String) executionType.get("Steps") ? ""
							: (String) executionType.get("Steps"));
				}
			}
			windowsExecutionArray.add(buildWindowsExecutionContent);
			unixExecutionArray.add(buildUnixExecutionContent);
			executionStepsDetails.put("windows", windowsExecutionArray);
			executionStepsDetails.put("unix", unixExecutionArray);
			toolRequestObject.put("executionStepsDetails", executionStepsDetails);

			toolRequestObject.put("pattern", frameworkDocument.get("Pattern"));
			toolRequestObject.put("separator", frameworkDocument.get("Separator"));
			properties.put("repo-url", gitUrl);
			toolRequestObject.put("properties", properties);
			toolRequestObject.put("config", "repo-url:" + gitUrl);
			logger.debug("[ClapSeleniumService - buildFrameWorkObject()] - End");
			return toolRequestObject;
		} else {
			logger.error(
					"[ClapSeleniumService - buildFrameWorkObject()] - Exception - " + frameWorkName + " not found.");
			throw new Exception("Framework not found.");
		}

	}

	private JSONObject isProjectExists(String projectName) throws Exception {
		logger.debug("[ClapSeleniumService - isProjectExists()] - Start - projectName - " + projectName);
		try {

			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
					+ "/api/execution/execution/projects/";
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {
				JSONArray projectArray = (JSONArray) new JSONParser().parse(response.toString());
				for (int i = 0; i < projectArray.size(); i++) {
					JSONObject projectObj = (JSONObject) projectArray.get(i);
					if (projectObj.get("name").toString().equalsIgnoreCase(projectName)) {
						logger.debug("[ClapSeleniumService - isProjectExists()] - End ");
						return projectObj;
					}
				}
			}

		} catch (Exception e) {
			logger.error("[ClapSeleniumService - isProjectExists()] - Exception - " + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - isProjectExists()] - End ");
		return null;
	}

	private JSONObject isFrameworkExists(String frameworkName) throws Exception {
		logger.debug("[ClapSeleniumService - isFrameworkExists()] - Start - frameworkName -" + frameworkName);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("roboPort") + "/tool-config/search?name="
					+ frameworkName;
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {
				JSONObject frameworkObj = (JSONObject) new JSONParser().parse(response.toString());
				if (frameworkObj != null) {
					if (frameworkObj.get("name").toString().equalsIgnoreCase(frameworkName)) {
						logger.debug("[ClapSeleniumService - isFrameworkExists()] - End ");
						return frameworkObj;
					}
				}
			}

		} catch (Exception e) {
			logger.error(
					"[ClapSeleniumService - isFrameworkExists()] - Exception - " + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - isFrameworkExists()] - End");
		return null;
	}

	@SuppressWarnings("unchecked")
	private void createGithubPropertyInLeap(String projectName, String frameworkName, String gitUserName,
			String gitPass) throws Exception {
		logger.debug("[ClapSeleniumService - createGithubPropertyInLeap()] - Start - gitHub_Property -" + frameworkName
				+ "_prop");
		JSONObject githubPropertyObj = checkGitPropertyNameExists(frameworkName + "_prop");
		logger.debug("[ClapSeleniumService - createGithubPropertyInLeap()] - Create new property");
		if (null != githubPropertyObj) {
			githubPropertyObj.replace("userName", gitUserName);
			githubPropertyObj.replace("token", gitPass);
			githubPropertyObj.replace("type", "CREDENTIAL");
			try {
				String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
						+ "/api/execution/properties/";
				StringBuffer response = openConnectionForPostRequest(url, PUT, githubPropertyObj);
				if (null != response) {
					logger.debug("[ClapSeleniumService - createGithubPropertyInLeap()] - End");
				}
			} catch (Exception e) {
				logger.error("[ClapSeleniumService - createGithubPropertyInLeap()] - Exception - "
						+ ExceptionUtils.getStackTrace(e));
				throw new Exception(e.getMessage());
			}
		} else {
			logger.debug("[ClapSeleniumService - createGithubPropertyInLeap()] - update existing property");
			try {
				JSONObject githubAuthCredObj = new JSONObject();
				githubAuthCredObj.put("name", frameworkName + "_prop");
				githubAuthCredObj.put("type", "CREDENTIAL");
				// githubAuthCredObj.put("value", null); commented for aws
				githubAuthCredObj.put("userName", gitUserName);
				githubAuthCredObj.put("token", gitPass);
				String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
						+ "/api/execution/properties/";
				StringBuffer response = openConnectionForPostRequest(url, POST, githubAuthCredObj);
				if (null != response) {
					logger.debug("[ClapSeleniumService - createGithubPropertyInLeap()] - End");
				}
			} catch (Exception e) {
				logger.error("[ClapSeleniumService - createGithubPropertyInLeap()] - Exception - "
						+ ExceptionUtils.getStackTrace(e));
				throw new Exception(e.getMessage());
			}
		}
	}

	private JSONObject checkGitPropertyNameExists(String frameworkName) throws Exception {
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("roboPort") + "/properties/search?name="
					+ frameworkName;
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {
				JSONObject githubPropertyObj = (JSONObject) new JSONParser().parse(response.toString());
				return githubPropertyObj;
			}

		} catch (Exception e) {
			throw new Exception(e);
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	private String createTestPlanInLeap(JSONObject projectObject, String frameworkName, String importTestCaseResponse)
			throws Exception {
		logger.debug(
				"[ClapSeleniumService - createTestPlanInLeap()] - start - projectName -" + projectObject.get("name"));
		try {
			String testPlanName = generateUniqueName(projectObject.get("id").toString(),
					projectObject.get("name").toString(), "test-plans");
			logger.debug("[ClapSeleniumService - createTestPlanInLeap()] testPlan details - frameWorkName - "
					+ frameworkName + " importTestCaseResponse isEmpty - " + importTestCaseResponse.isEmpty()
					+ " testPlanName -" + testPlanName);

			JSONArray tasks = null;

			tasks = (JSONArray) new JSONParser().parse(importTestCaseResponse);

			JSONObject testPlanObject = new JSONObject();
			JSONObject taskObject = new JSONObject();
			testPlanObject.put("name", testPlanName);
			testPlanObject.put("projectName", projectObject.get("name").toString());
			testPlanObject.put("toolType", frameworkName);
			taskObject.put("type", frameworkName);
			taskObject.put("tasks", tasks);

			testPlanObject.put("task", taskObject);
			testPlanObject.put("autoSync", false);
			testPlanObject.put("createSuite", false);

			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
					+ "/api/execution/test-plans/";
			StringBuffer response = openConnectionForPostRequest(url, POST, testPlanObject);
			if (null != response) {
				JSONObject testPlanResponseObject = null;

				testPlanResponseObject = (JSONObject) new JSONParser().parse(response.toString());
				logger.debug("[ClapSeleniumService - createTestPlanInLeap()] - End");
				return testPlanResponseObject.get("name").toString();

			}

		} catch (Exception e) {
			logger.error(
					"[ClapSeleniumService - createTestPlanInLeap()] - Exception - " + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - createTestPlanInLeap()] - End");
		return null;
	}

	private String generateUniqueName(String projectId, String projectName, String name) throws Exception {
		logger.debug("[ClapSeleniumService - generateUniqueName()] - Start - projectName - " + projectName);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("roboPort") + "/execution/projects/"
					+ projectId + "/" + name;
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {
				JSONArray testPlanArray = (JSONArray) new JSONParser().parse(response.toString());
				List<String> myJsonArrayAsList = new ArrayList<String>();
				int count = 0;

				for (int i = 0; i < testPlanArray.size(); i++) {
					JSONObject planName = (JSONObject) testPlanArray.get(i);
					myJsonArrayAsList.add(planName.get("name").toString());
				}

				count = myJsonArrayAsList.size();
				String finalName = null;
				if (name.equalsIgnoreCase("test-plans")) {
					finalName = projectName + "_tp" + "_" + count;
					if (myJsonArrayAsList.contains(finalName)) {
						finalName = finalName + "_" + count;
					}
					logger.debug("[ClapSeleniumService - generateUniqueName()] - TestPlan Name - " + finalName);
					logger.debug("[ClapSeleniumService - generateUniqueName()] - End");
					return finalName;
				} else {
					finalName = projectName + "_ts" + "_" + count;
					if (myJsonArrayAsList.contains(finalName)) {
						finalName = finalName + "_" + count;
					}
					logger.debug("[ClapSeleniumService - generateUniqueName()] - Testsuite Name - " + finalName);
					logger.debug("[ClapSeleniumService - generateUniqueName()] - End");
					return finalName;
				}
			}
		} catch (Exception e) {
			logger.error(
					"[ClapSeleniumService - generateUniqueName()] - Exception - " + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - generateUniqueName()] - End");
		return null;

	}

	@SuppressWarnings("unchecked")
	public String importTestCasesToTestPlanInLeap(String projectName, String toolName, String gitUrl) throws Exception {
		logger.debug("[ClapSeleniumService - importTestCasesToTestPlanInLeap()] - Start");
		logger.debug("[ClapSeleniumService - importTestCasesToTestPlanInLeap()] - projectName -" + projectName
				+ " toolName - " + toolName + " gitUrl - " + gitUrl);
		JSONObject importTestPlanRequest = new JSONObject();
		importTestPlanRequest.put("show", true);
		importTestPlanRequest.put("credential", toolName + "_prop");
		importTestPlanRequest.put("branch", "master");
		if (toolName.equalsIgnoreCase("gradle-testng")) {
			importTestPlanRequest.put("toolType", "testng_java_gradle");
			importTestPlanRequest.put("importType", "testng_java_method");
		} else if (toolName.equalsIgnoreCase("cucumber-test")) {
			importTestPlanRequest.put("toolType", "cucumber_feature");
			importTestPlanRequest.put("importType", "cucumber_feature_file");
		} else {
			importTestPlanRequest.put("toolType", "testng_java_maven");
			importTestPlanRequest.put("importType", "testng_java_method");
		}

		importTestPlanRequest.put("autoSync", false);
		importTestPlanRequest.put("createSuite", true);

		importTestPlanRequest.put("url", gitUrl);
		importTestPlanRequest.put("projectName", projectName);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
					+ "/api/execution/test/import/";
			StringBuffer response = openConnectionForPostRequest(url, POST, importTestPlanRequest);
			if (null != response) {
				logger.debug("[ClapSeleniumService - importTestCasesToTestPlanInLeap()] - Import test Cases success!");
				logger.debug("[ClapSeleniumService - importTestCasesToTestPlanInLeap()] - End");
				return response.toString();
			}
		} catch (Exception e) {
			logger.error("[ClapSeleniumService - importTestCasesToTestPlanInLeap()] - Exception - "
					+ ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - importTestCasesToTestPlanInLeap()] - End");
		return null;
	}

	public String createTestSuiteInLeap(JSONObject projectObject, String frameworkName, String importTestCaseResponse,
			String gitUrl, String executionType) throws Exception {
		logger.debug(
				"[ClapSeleniumService - createTestSuiteInLeap()] - Start - projectName -" + projectObject.get("name"));
		JSONObject testSuiteRequestObject = buildTestSuitekObject(projectObject.get("name").toString(), frameworkName,
				importTestCaseResponse, projectObject.get("id").toString(), gitUrl, executionType);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort") + "/api/execution/suites/";
			StringBuffer response = openConnectionForPostRequest(url, POST, testSuiteRequestObject);
			if (null != response) {
				JSONObject testSuiteResponseObject = null;

				testSuiteResponseObject = (JSONObject) new JSONParser().parse(response.toString());
				logger.debug("[ClapSeleniumService - createTestSuiteInLeap()] - End");
				return testSuiteResponseObject.get("name").toString() + " ~ " + testSuiteResponseObject.get("id");

			}

		} catch (Exception e) {
			logger.error(
					"[ClapSeleniumService - createTestSuiteInLeap()] - Exception - " + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - createTestSuiteInLeap()] - End");
		return null;

	}

	@SuppressWarnings("unchecked")
	public JSONObject buildTestSuitekObject(String projectName, String frameworkName, String importTestCaseResponse,
			String projectId, String gitUrl, String executionType) throws Exception {
		String testSuiteName = generateUniqueName(projectId, projectName, "test-suites");
		JSONObject testSuiteRequestObject = new JSONObject();
		JSONObject properties = new JSONObject();
		JSONObject taskObject = new JSONObject();
		JSONArray robots = new JSONArray();

		JSONArray tasks = null;
		try {
			tasks = (JSONArray) new JSONParser().parse(importTestCaseResponse);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		if (!executionType.equalsIgnoreCase("container")) {
			String robotName = createRobotIfNotExists(projectName);
			robots.add(robotName != null ? robotName : "dummy_rob");
		}

		testSuiteRequestObject.put("name", testSuiteName);
		testSuiteRequestObject.put("projectName", projectName);
		testSuiteRequestObject.put("allocationType", "auto");
		testSuiteRequestObject.put("priority", 0);
		testSuiteRequestObject.put("deleteJobCache", false);

		testSuiteRequestObject.put("robots", robots);
		testSuiteRequestObject.put("toolType", frameworkName);
		taskObject.put("type", frameworkName);
		taskObject.put("tasks", tasks);

		testSuiteRequestObject.put("task", taskObject);
		properties.put("repo-url", gitUrl);
		properties.put("suiteName", testSuiteName);
		properties.put("projectname", projectName);
		properties.put("host", prop.get("hostName") + ":" + prop.getProperty("leapPort") + "/api/reports/");
		testSuiteRequestObject.put("properties", properties);
		testSuiteRequestObject.put("config", "repo-url:" + gitUrl);

		return testSuiteRequestObject;
	}

	private String createRobotIfNotExists(String projectName) throws Exception {
		logger.debug("[ClapSeleniumService - createRobotIfNotExists()] - Start - projectName -" + projectName);
		try {

			boolean roboStatus = checkRobotStatus(projectName + "_rob", false);
			if (!roboStatus) {
				logger.debug("[ClapSeleniumService - createRobotIfNotExists()] In Else Create Robo - " + projectName
						+ "_rob");
				String roboName = createRobotForProject(projectName + "_rob");
				if (null != roboName) {
					logger.debug("[ClapSeleniumService - createRobotIfNotExists()] - End ");
					return roboName;
				} else {
					throw new Exception("Unable to create robo.");
				}
			} else {
				logger.debug("[ClapSeleniumService - createRobotIfNotExists()] - End ");
				return projectName + "_rob";
			}

		} catch (Exception e) {
			logger.error("[ClapSeleniumService - createRobotIfNotExists()] - Exception - "
					+ ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}

	}

	@SuppressWarnings("unchecked")
	private String createRobotForProject(String roboName) throws Exception {
		logger.debug("[ClapSeleniumService - createRobotForProject()] - Start - roboName -" + roboName);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("roboPort") + "/robots";

			JSONObject roboObjRequest = new JSONObject();
			roboObjRequest.put("name", roboName);
			roboObjRequest.put("rating", 100);
			roboObjRequest.put("properties", new JSONObject());
			roboObjRequest.put("createNew", true);

			StringBuffer response = openConnectionForPostRequest(url, POST, roboObjRequest);
			if (null != response) {
				JSONObject roboResponse = (JSONObject) new JSONParser().parse(response.toString());
				boolean tokenResponse = createTokenForRobo(roboResponse.get("id").toString());
				if (tokenResponse) {
					logger.debug("[ClapSeleniumService - createRobotForProject()] - End");
					return roboResponse.get("name").toString();
				} else {
					throw new Exception("Unable to create robo for project");
				}
			}
		} catch (Exception e) {
			logger.error(
					"[ClapSeleniumService - createRobotForProject()] - Exception - " + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - createRobotForProject()] - End");
		return null;
	}

	private boolean createTokenForRobo(String roboId) throws Exception {
		logger.debug("[ClapSeleniumService - createTokenForRobo()] - Start - roboId -" + roboId);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("roboPort") + "/robots/" + roboId
					+ "/token?years=99";

			StringBuffer response = openConnectionForPostRequest(url, POST, null);
			if (null != response) {
				logger.debug("[ClapSeleniumService - createTokenForRobo()] -  robo token created - 200");
				return true;
			}

		} catch (Exception e) {
			logger.error(
					"[ClapSeleniumService - createTokenForRobo()] - Exception - " + ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}
		return false;
	}

	@SuppressWarnings("unchecked")
	public JSONObject executeSeleniumScriptInLeap(ClapProjectRequest clapProjectRequest, String testPlanId,
			String testSuiteId, String importTestCaseResponse, String gitUrl) throws Exception {
		logger.debug("[ClapSeleniumService - executeSeleniumScriptInLeap()] - Start - clapProjectRequest -"
				+ clapProjectRequest);
		try {
			if (!"container".equalsIgnoreCase(clapProjectRequest.getExecutionType())) {
				// if (clapProjectRequest.getCommandUrl() != null ||
				// clapProjectRequest.getBrowserName() != null) {
				// if (null == isFrameworkExists(
				// clapProjectRequest.getProjectName() + "_" +
				// clapProjectRequest.getBrowserName())) {
				// createToolInLeap(clapProjectRequest.getFrameworkName().concat("~").concat(
				// clapProjectRequest.getProjectName() + "_" +
				// clapProjectRequest.getBrowserName()),
				// gitUrl);
				// }
				// clapProjectRequest.setFrameworkName(
				// clapProjectRequest.getProjectName() + "_" +
				// clapProjectRequest.getBrowserName());
				// updateFrameworkInLeap(clapProjectRequest);
				// }
				//
				// // if user wants to execute selected testcases.received as
				// input
				// // from user.
				// if (clapProjectRequest.getSeletedTestCases() != null
				// && !clapProjectRequest.getSeletedTestCases().isEmpty()) {
				// importTestCaseResponse =
				// clapProjectRequest.getSeletedTestCases().toString();
				// }
				//
				// clapProjectRequest.setTestSuiteId(testSuiteId);
				// updateTestSuiteForExecution(null, clapProjectRequest);
				// JSONObject executionRequestObject =
				// buildExecutionRequestObject(clapProjectRequest, testPlanId,
				// testSuiteId, importTestCaseResponse, gitUrl, null);
				//
				// File file = new File("C:\\" +
				// clapProjectRequest.getProjectName() +
				// "_rob").getCanonicalFile();
				// if (!file.exists()) {
				// checkRoboStatusAndDownload(clapProjectRequest.getProjectName()
				// + "_rob");
				// } else {
				// if
				// (!checkRoboStatusAndDownload(clapProjectRequest.getProjectName()
				// + "_rob")) {
				// String path = "cmd /c start " + "C:\\" +
				// clapProjectRequest.getProjectName()
				// + "_rob\\start.bat";
				// path = path.replaceAll("[^A-Za-z0-9-_]", "");
				// Runtime rn = Runtime.getRuntime();
				// Process pr = rn.exec(new File(path).getCanonicalPath());
				// }
				// }
				//
				// String url = prop.getProperty("hostName") + ":" +
				// prop.getProperty("leapPort")
				// + "/api/execution/executions";
				//
				// StringBuffer response = openConnectionForPostRequest(url,
				// POST, executionRequestObject);
				// if (null != response) {
				// JSONObject executionObject = null;
				//
				// executionObject = (JSONObject) new
				// JSONParser().parse(response.toString());
				// logger.debug("[ClapSeleniumService -
				// executeSeleniumScriptInLeap()] - Execution Id -- "
				// + executionObject.get("id"));
				// JSONObject executionResponseObject = new JSONObject();
				// executionResponseObject.put("executionId",
				// executionObject.get("id").toString());
				// clapProjectRequest.setCommandUrl(null);
				// clapProjectRequest.setBrowserName(null);
				// // updateFrameworkInLeap(clapProjectRequest);
				// logger.debug("[ClapSeleniumService -
				// executeSeleniumScriptInLeap()] End");
				// return executionResponseObject;
				//
				// }
			} else {
				String serviceId = null;
				String result = null;
				// update number of containers in robo.
				if (clapProjectRequest.getCloudName().equalsIgnoreCase("AWS")) {

					MongoDAO mongo = MongoDAO.getInstance();
					awsConfig = mongo.getConfigDetails("ClapConfig", clapProjectRequest.getConfigProjectName());
					AWSService service = new AWSService("ClapConfig", clapProjectRequest.getConfigProjectName());

					RegisterTaskDefinitionResult taskDefination = service.createTaskDefination();
					// req.setTaskDefination(taskDefination.getTaskDefinition().getFamily());
					CreateServiceResult serviceResponse = service
							.createService(taskDefination.getTaskDefinition().getFamily());
					if (serviceResponse.getService().getServiceName() != null)
						logger.debug("[ClapSeleniumService - executeSeleniumScriptInLeap()] Service created");

					serviceId = createAWSLeapService(serviceResponse.getService().getServiceName());

					result = updateAwsContainerCountInService(clapProjectRequest.getContainers(), serviceId,
							clapProjectRequest.getConfigProjectName());

					if (result.equalsIgnoreCase("success")) {
						executeScriptsInContainer(clapProjectRequest, testPlanId, testSuiteId, importTestCaseResponse,
								gitUrl, taskDefination.getTaskDefinition().getFamily(), serviceId);
						JSONObject executionResponseObject = new JSONObject();
						executionResponseObject.put("status", "Execution in progress...");
						logger.debug("[ClapSeleniumService - executeSeleniumScriptInLeap()] End");
						return executionResponseObject;
					}
				} else {
					String serviceName = UUID.randomUUID().toString();
					serviceId = createAzureLeapService(serviceName + "-service");
					logger.debug("[ClapSeleniumService - executeSeleniumScriptInLeap()] serviceId - " + serviceId
							+ " serviceName - " + serviceName);
					result = updateAzureContainerCountInService(clapProjectRequest.getContainers(), serviceId);
					if (result.equalsIgnoreCase("success")) {
						executeScriptsInContainer(clapProjectRequest, testPlanId, testSuiteId, importTestCaseResponse,
								gitUrl, serviceName, serviceId);
						JSONObject executionResponseObject = new JSONObject();
						executionResponseObject.put("status", "Execution in progress...");
						logger.debug("[ClapSeleniumService - executeSeleniumScriptInLeap()] End");
						return executionResponseObject;
					}
				}
			}

		} catch (Exception e) {

			logger.error("[ClapSeleniumService - executeSeleniumScriptInLeap()] Exception - "
					+ ExceptionUtils.getStackTrace(e));
			ClapProjectResponse response = new ClapProjectResponse();
			response.setMessage("Test Plan/ Test suite not found.");
			response.setSuccess(false);
			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - executeSeleniumScriptInLeap()] End");
		return null;

	}

	private void executeScriptsInContainer(ClapProjectRequest clapProjectRequest, String testPlanId, String testSuiteId,
			String importTestCaseResponse, String gitUrl, String roboName, String serviceId) {
		logger.debug("[ClapSeleniumService - executeScriptsInContainer()] Start - " + clapProjectRequest);
		Timer timer = new Timer();
		TimerTask tt = new TimerTask() {
			public void run() {
				String importTestCaseObject = (clapProjectRequest.getSeletedTestCases() == null
						|| clapProjectRequest.getSeletedTestCases().isEmpty()) ? importTestCaseResponse
								: clapProjectRequest.getSeletedTestCases().toString();
				try {
					List<JSONObject> roboList = getAllRobosAndFilterByName(roboName);
					if (roboList != null)
						if (roboList.size() > 0 && roboList.size() >= clapProjectRequest.getContainers()) {
							List<String> roboListOnline = updateTestSuiteForExecution(roboList, clapProjectRequest);
							if (clapProjectRequest.getCommandUrl() != null
									|| clapProjectRequest.getBrowserName() != null) {
								if (null == isFrameworkExists(clapProjectRequest.getTestSuiteName() + "_"
										+ clapProjectRequest.getBrowserName() + "_"
										+ clapProjectRequest.getExecutionMode())) {
									createToolInLeap(
											clapProjectRequest.getFrameworkName().concat("~")
													.concat(clapProjectRequest.getTestSuiteName() + "_"
															+ clapProjectRequest.getBrowserName() + "_"
															+ clapProjectRequest.getExecutionMode()),
											gitUrl);
								}
								clapProjectRequest.setFrameworkName(clapProjectRequest.getTestSuiteName() + "_"
										+ clapProjectRequest.getBrowserName() + "_"
										+ clapProjectRequest.getExecutionMode());
								updateFrameworkInLeap(clapProjectRequest);
							}
							// if user wants to execute selected
							// testcases.received as input from user.

							JSONObject executionRequestObject = buildExecutionRequestObject(clapProjectRequest,
									testPlanId, testSuiteId, importTestCaseObject, gitUrl, roboListOnline);

							String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
									+ "/api/execution/executions";
							StringBuffer response = openConnectionForPostRequest(url, POST, executionRequestObject);

							if (null != response) {

								JSONObject executionObject = null;
								executionObject = (JSONObject) new JSONParser().parse(response.toString());
								clapProjectRequest.setCommandUrl(null);
								clapProjectRequest.setBrowserName(null);
								// updateFrameworkInLeap(clapProjectRequest);
								updateExecutionIdInCollection(clapProjectRequest, executionObject.get("id").toString(),
										serviceId);
							}
							timer.cancel();
						}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					timer.cancel();
					logger.error("[ClapSeleniumService - executeScriptsInContainer()] Exception - "
							+ ExceptionUtils.getStackTrace(e));

				}

			};
		};
		timer.schedule(tt, 10000, 50000);
		logger.debug("[ClapSeleniumService - executeScriptsInContainer()] End");
	}

	@SuppressWarnings("unchecked")
	private List<String> updateTestSuiteForExecution(List<JSONObject> roboList, ClapProjectRequest clapProjectRequest)
			throws Exception {
		logger.debug("[ClapSeleniumService - updateTestSuiteForExecution()] Start - clapProjectRequest - "
				+ clapProjectRequest);
		List<String> roboListOnline = null;
		JSONObject testSuiteObj = fetchTestSuiteById(clapProjectRequest.getTestSuiteId());
		if (clapProjectRequest.getExecutionType().equalsIgnoreCase("container")) {
			if (clapProjectRequest.getContainers() < roboList.size()) {
				roboListOnline = roboList.stream().map(JSONObject.class::cast)
						.filter(tagObject -> tagObject.get("status").toString().equalsIgnoreCase("online"))
						.map(tagObject -> tagObject.get("name").toString()).collect(Collectors.toList());
			} else {
				roboListOnline = roboList.stream().map(JSONObject.class::cast)
						.map(tagObject -> tagObject.get("name").toString()).collect(Collectors.toList());
			}

			testSuiteObj.replace("robots", roboListOnline);
			testSuiteObj.put("toolType", clapProjectRequest.getFrameworkName());
			testSuiteObj.put("type", clapProjectRequest.getFrameworkName());
		}

		if (clapProjectRequest.getSeletedTestCases() != null && !clapProjectRequest.getSeletedTestCases().isEmpty()) {
			JSONObject taskObj = (JSONObject) testSuiteObj.get("task");
			taskObj.replace("tasks", clapProjectRequest.getSeletedTestCases());
			testSuiteObj.replace("task", taskObj);
		}
		updateTestSuite(testSuiteObj);
		logger.debug("[ClapSeleniumService - updateTestSuiteForExecution()] Test suite obj after modification -- "
				+ testSuiteObj);

		return roboListOnline;

	}

	private void updateTestSuite(JSONObject testSuiteObj) throws Exception {
		logger.debug("[ClapSeleniumService - updateTestSuite()] Start ");
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort") + "/api/execution/suites/";
			openConnectionForPostRequest(url, PUT, testSuiteObj);
			logger.debug("[ClapSeleniumService - updateTestSuite()] End ");
		} catch (Exception e) {
			logger.error("[ClapSeleniumService - updateTestSuite()] Exception - " + ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());
		}
	}

	private List<JSONObject> getAllRobosAndFilterByName(String projectName) throws Exception {
		logger.debug("[ClapSeleniumService - getAllRobosAndFilterByName()] Start - " + projectName);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort") + "/api/execution/robots/";
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {

				JSONArray serviceObj = (JSONArray) new JSONParser().parse(response.toString());

				List<JSONObject> finalRoboList = new ArrayList<>();
				for (int i = 0; i < serviceObj.size(); i++) {
					JSONObject object = (JSONObject) serviceObj.get(i);
					if (object.get("name").toString().startsWith(projectName + "-service")) {
						finalRoboList.add(object);
					}
				}
				logger.debug("[ClapSeleniumService - getAllRobosAndFilterByName()] roboList - " + finalRoboList);
				return finalRoboList;

			} else {
				logger.debug("[ClapSeleniumService - getAllRobosAndFilterByName()] End");
				return null;
			}

		} catch (Exception e) {
			logger.error("[ClapSeleniumService - getAllRobosAndFilterByName()] Exception - "
					+ ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());
		}

	}

	@SuppressWarnings("unchecked")
	private String updateAzureContainerCountInService(int containers, String azureLeapserviceId) throws Exception {
		logger.debug("[ClapSeleniumService - updateAzureContainerCountInService()] Start - azureLeapserviceId - "
				+ azureLeapserviceId);
		try {

			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
					+ "/api/execution/cloud/azure/robots/" + azureLeapserviceId + "/update/";

			JSONObject serviceRequestObj = new JSONObject();

			// serviceRequestObj.put("token", prop.get("azureSecret"));
			serviceRequestObj.put("token", "0110@Ciqd10");
			serviceRequestObj.put("tasks", containers);
			serviceRequestObj.put("encode", "PLAIN");

			StringBuffer response = openConnectionForPostRequest(url, POST, serviceRequestObj);
			if (null != response) {
				logger.debug("[ClapSeleniumService - updateAzureContainerCountInService()] End - success");
				return "Success";
			}
		} catch (Exception e) {
			logger.error("[ClapSeleniumService - updateAzureContainerCountInService()] Exception - "
					+ ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - updateAzureContainerCountInService()] End - failure");
		return "failure";
	}

	@SuppressWarnings("unchecked")
	public String updateAwsContainerCountInService(int containers, String awsLeapserviceId, String configProjectName)
			throws Exception {
		logger.debug("[ClapSeleniumService - updateAwsContainerCountInService()] Start  - awsLeapserviceId - "
				+ awsLeapserviceId);

		try {
			awsConfig = mongoDAO.getConfigDetails("ClapConfig", configProjectName);
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
					+ "/api/execution/cloud/aws/robots/" + awsLeapserviceId + "/update/";

			JSONObject serviceRequestObj = new JSONObject();

			serviceRequestObj.put("secretKey", awsConfig.get("awsSecVal"));
			serviceRequestObj.put("tasks", containers);

			StringBuffer response = openConnectionForPostRequest(url, POST, serviceRequestObj);
			if (null != response) {
				logger.debug("[ClapSeleniumService - updateAwsContainerCountInService()] End - Success");
				return "Success";
			}
		} catch (Exception e) {
			logger.error("[ClapSeleniumService - updateAwsContainerCountInService()] Exception - "
					+ ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - updateAwsContainerCountInService()] End - failure");
		return "failure";
	}

	@SuppressWarnings("unchecked")
	public JSONObject buildExecutionRequestObject(ClapProjectRequest clapProjectRequest, String testPlanId,
			String testSuiteId, String importTestCaseResponse, String gitUrl, List<String> roboList) throws Exception {
		JSONObject executionRequestObject = new JSONObject();
		JSONObject properties = new JSONObject();
		JSONObject taskObject = new JSONObject();
		JSONArray robots = new JSONArray();

		if (!clapProjectRequest.getExecutionType().equalsIgnoreCase("container")) {
			String robotName = createRobotIfNotExists(clapProjectRequest.getProjectName());
			robots.add(robotName != null ? robotName : "dummy_rob");
			executionRequestObject.put("robots", robots);
		} else {
			executionRequestObject.put("robots", roboList);
		}

		JSONArray tasks = null;
		try {

			tasks = (JSONArray) new JSONParser().parse(importTestCaseResponse);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		executionRequestObject.put("robotsType", "NATIVE");
		executionRequestObject.put("name", clapProjectRequest.getProjectName() + "_ng");
		executionRequestObject.put("projectName", clapProjectRequest.getProjectName());
		executionRequestObject.put("testPlanId", null);
		// executionRequestObject.put("testPlanId", testPlanId); commented for
		// aws execution
		executionRequestObject.put("autoSync", false);
		executionRequestObject.put("priority", 100);
		executionRequestObject.put("allocationType", "auto");
		executionRequestObject.put("reportId", null);
		executionRequestObject.put("reportProjectId", null);
		executionRequestObject.put("toolType", clapProjectRequest.getFrameworkName());
		executionRequestObject.put("deleteJobCache", false);
		executionRequestObject.put("suiteId", testSuiteId);

		taskObject.put("type", clapProjectRequest.getFrameworkName());

		// taskObject.put("tasks", tasks);
		taskObject.put("tasks", tasks);
		taskObject.put("properties", null);
		executionRequestObject.put("task", taskObject);
		properties.put("repo-url", gitUrl);
		properties
				.put("suiteName",
						(clapProjectRequest.getExecutionMode() != null && clapProjectRequest.getBrowserName() != null)
								? clapProjectRequest.getTestSuiteName() + "_" + clapProjectRequest.getBrowserName()
										+ "_" + clapProjectRequest.getExecutionMode()
								: clapProjectRequest.getTestSuiteName());
		properties.put("projectname", clapProjectRequest.getProjectName());

		executionRequestObject.put("properties", properties);
		// executionRequestObject.put("config", "repo-url:" + gitUrl); commented
		// for aws flow

		return executionRequestObject;
	}

	public ClapProjectResponse executeSeleniumScripts(ClapProjectRequest clapProjectRequest) throws Exception {
		logger.debug(
				"[ClapSeleniumService - executeSeleniumScripts()] Start - clapProjectRequest - " + clapProjectRequest);
		// TODO Auto-generated method stub
		ClapProjectResponse response = new ClapProjectResponse();
		JSONObject projectDetails = isProjectExists(clapProjectRequest.getProjectName());
		JSONObject testPlan = null;
		String testSuiteId = null;

		if (projectDetails != null) {

			testPlan = fetchTestPlanForProject(projectDetails.get("id").toString(),
					clapProjectRequest.getTestPlanName());
			testSuiteId = fetchTestSuiteIdForProject(projectDetails.get("id").toString(),
					clapProjectRequest.getTestSuiteName());

			if (null != testPlan && null != testSuiteId) {

				JSONObject task = (JSONObject) testPlan.get("task");

				JSONObject executionResponseObject = executeSeleniumScriptInLeap(clapProjectRequest,
						testPlan.get("id").toString(), testSuiteId, task.get("tasks").toString(),
						clapProjectRequest.getGitRepoURL());
				response.setData(executionResponseObject);
				response.setMessage("Execution request submitted successfully.");
				response.setSuccess(true);
			} else {

				response.setMessage("Test Plan/ Test suite not found.");
				response.setSuccess(false);
				logger.debug("[ClapSeleniumService - executeSeleniumScripts()] Test Plan/ Test suite not found");
				throw new Exception("Test Plan/ Test suite not found");
			}
		} else {
			logger.debug(
					"[ClapSeleniumService - executeSeleniumScripts()] Project not found for fetching test plans/suites.");
			response.setMessage("Project not found for fetching test plans/suites.");
			response.setSuccess(false);
			throw new Exception("Project not found for fetching test plans/suites.");
		}
		logger.debug("[ClapSeleniumService - executeSeleniumScripts()] End.");
		return response;
	}

	public JSONObject fetchTestPlanForProject(String projectId, String testPlanName) throws Exception {
		logger.debug("[ClapSeleniumService - fetchTestPlanForProject()] Start - testPlanName - " + testPlanName);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("roboPort") + "/execution/projects/"
					+ projectId + "/test-plans";
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {
				JSONArray testPlanArray = (JSONArray) new JSONParser().parse(response.toString());

				for (int i = 0; i < testPlanArray.size(); i++) {
					JSONObject testPlanObj = (JSONObject) testPlanArray.get(i);

					if (testPlanObj.get("name").toString().equalsIgnoreCase(testPlanName)) {
						logger.debug("[ClapSeleniumService - fetchTestPlanForProject()] End");
						return testPlanObj;
					}
				}
			}

		} catch (Exception e) {
			logger.error(
					"[ClapSeleniumService - fetchTestPlanForProject()] Exception - " + ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());

		}
		logger.debug("[ClapSeleniumService - fetchTestPlanForProject()] End");
		return null;
	}

	public String fetchTestSuiteIdForProject(String projectId, String testSuiteName) throws Exception {
		logger.debug("[ClapSeleniumService - fetchTestSuiteIdForProject()] Start - testSuiteName - " + testSuiteName);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("roboPort") + "/execution/projects/"
					+ projectId + "/test-suites";
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {

				JSONArray testSuiteArray = (JSONArray) new JSONParser().parse(response.toString());

				for (int i = 0; i < testSuiteArray.size(); i++) {
					JSONObject testSuiteObj = (JSONObject) testSuiteArray.get(i);
					if (testSuiteObj.get("name").toString().equalsIgnoreCase(testSuiteName)) {
						logger.debug("[ClapSeleniumService - fetchTestSuiteIdForProject()] End");
						return testSuiteObj.get("id").toString();
					}
				}
			}
		} catch (Exception e) {
			logger.error("[ClapSeleniumService - fetchTestSuiteIdForProject()] Exception - "
					+ ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - fetchTestSuiteIdForProject()] End");
		return null;
	}

	public JSONObject fetchTestSuiteById(String suiteId) throws Exception {
		logger.debug("[ClapSeleniumService - fetchTestSuiteById()] Start - suiteId - " + suiteId);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("roboPort") + "/suites/" + suiteId;
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {
				JSONObject testSuiteObj = (JSONObject) new JSONParser().parse(response.toString());
				logger.debug("[ClapSeleniumService - fetchTestSuiteById()] End");
				return testSuiteObj;

			} else {
				logger.debug("[ClapSeleniumService - fetchTestSuiteById()] End");
				return null;
			}

		} catch (Exception e) {
			logger.error("[ClapSeleniumService - fetchTestSuiteById()] Exception - " + ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());
		}
	}

	class TestPlanComparator implements Comparator<JSONObject> {

		@Override
		public int compare(JSONObject o1, JSONObject o2) {
			return Integer.compare(
					Integer.valueOf(
							o2.get("name").toString().substring(o2.get("name").toString().lastIndexOf("_") + 1)),
					Integer.valueOf(
							o1.get("name").toString().substring(o1.get("name").toString().lastIndexOf("_") + 1)));
		}
	}

	public ClapProjectResponse getTaskStatus(String executionId) throws Exception {
		logger.debug("[ClapSeleniumService - getTaskStatus()] Start - executionId - " + executionId);
		ClapProjectResponse statusResponse = new ClapProjectResponse();
		try {
			String hostname = prop.getProperty("hostName").replaceAll("[^A-Za-z0-9-]", "");
			String roboPort = prop.getProperty("roboPort").replaceAll("[^0-9]", "");
			String url = hostname + ":" + roboPort + "/executions/" + executionId;
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {
				JSONObject statusObj = (JSONObject) new JSONParser().parse(response.toString());

				statusResponse.setData(statusObj);
				statusResponse.setMessage("Status Fetched successfully");
				statusResponse.setSuccess(true);
				logger.debug("[ClapSeleniumService - getTaskStatus()] End");
				return statusResponse;

			} else {
				statusResponse.setMessage("Status for" + executionId + " not found.");
				statusResponse.setSuccess(false);
				logger.debug("[ClapSeleniumService - getTaskStatus()] End");
				return statusResponse;
			}

		} catch (Exception e) {
			logger.error("[ClapSeleniumService - getTaskStatus()] Exception - " + ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());
		}

	}

	public ClapProjectResponse getDetailedProjectReport(String projectName) throws Exception {
		logger.debug("[ClapSeleniumService - getDetailedProjectReport()] Start - projectName - " + projectName);
		ClapProjectResponse statusResponse = new ClapProjectResponse();
		String projectId = fetchReportProjectId(projectName);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
					+ "/api/reports/dashboard/projects/" + projectId;
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {
				JSONObject consolidatedReport = new JSONObject();
				JSONObject statusObj = (JSONObject) new JSONParser().parse(response.toString());

				consolidatedReport.put("projectReportStatus", statusObj);
				JSONArray executionArray = (JSONArray) statusObj.get("executions");
				statusResponse.setData(consolidatedReport);
				statusResponse.setMessage("Status Fetched successfully");
				statusResponse.setSuccess(true);
				logger.debug("[ClapSeleniumService - getDetailedProjectReport()] End");
				return statusResponse;

			} else {
				statusResponse.setMessage("Report for" + projectName + " not found.");
				statusResponse.setSuccess(false);
				logger.debug("[ClapSeleniumService - getDetailedProjectReport()] End");
				return statusResponse;
			}

		} catch (Exception e) {
			logger.error("[ClapSeleniumService - getDetailedProjectReport()] Exception - "
					+ ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());
		}

	}

	private JSONObject fetchTestSuiteExecutionStatus(JSONObject executionObj) throws Exception {
		logger.debug("[ClapSeleniumService - fetchTestSuiteExecutionStatus()] Start - executionObj - " + executionObj);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
					+ "/api/reports/test/reports/" + executionObj.get("id").toString();
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {
				JSONObject statusObj = (JSONObject) new JSONParser().parse(response.toString());
				logger.debug("[ClapSeleniumService - fetchTestSuiteExecutionStatus()] End");
				return statusObj;

			}

		} catch (Exception e) {
			logger.error("[ClapSeleniumService - fetchTestSuiteExecutionStatus()] Exception - "
					+ ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - fetchTestSuiteExecutionStatus()] End");
		return null;

	}

	private String fetchReportProjectId(String projectName) throws Exception {
		logger.debug("[ClapSeleniumService - fetchReportProjectId()] Start - projectName - " + projectName);
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
					+ "/api/reports/dashboard/projects/";
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {
				JSONArray projectArray = (JSONArray) new JSONParser().parse(response.toString());
				for (int i = 0; i < projectArray.size(); i++) {
					JSONObject projectObj = (JSONObject) projectArray.get(i);
					if (projectObj.get("name").toString().equalsIgnoreCase(projectName)) {
						logger.debug("[ClapSeleniumService - fetchReportProjectId()] End");
						return projectObj.get("id").toString();
					}
				}
			}
		} catch (Exception e) {
			logger.error(
					"[ClapSeleniumService - fetchReportProjectId()] Exception - " + ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());
		}
		logger.debug("[ClapSeleniumService - fetchReportProjectId()] End");
		return null;
	}

	// public JSONObject executeScriptAndGenerateReport(ClapProjectRequest
	// clapProjectRequest,
	// ClapProjectResponse response) throws Exception {
	// // ClapProjectResponse reportResponse = new ClapProjectResponse();
	//
	// try {
	// JSONObject data = response.getData();
	// if (data != null && data.containsKey("executionId")) {
	// String executionId = data.get("executionId").toString();
	// JSONObject statusData = null;
	// ClapProjectResponse statusResponse = null;
	// int counter = 0;
	// // do {
	// statusResponse = getTaskStatus(executionId);
	//
	// if (statusResponse != null) {
	// statusData = statusResponse.getData();
	// return statusData;
	// }
	//
	// }
	// } catch (Exception e) {
	//
	// e.printStackTrace();
	// }
	// return null;
	// }

	// private static void zipReport(String infile, String ofile,
	// ClapProjectResponse reportResponse) {
	// // try with resources - creating outputstream and ZipOutputSttream
	// try (FileOutputStream fos = new FileOutputStream(ofile); ZipOutputStream
	// zos = new ZipOutputStream(fos)) {
	// Path sourcePath = Paths.get(infile);
	// // using WalkFileTree to traverse directory
	// Files.walkFileTree(sourcePath, new SimpleFileVisitor<Path>() {
	// @Override
	// public FileVisitResult preVisitDirectory(final Path dir, final
	// BasicFileAttributes attrs)
	// throws IOException {
	// // it starts with the source folder so skipping that
	// if (!sourcePath.equals(dir)) {
	// zos.putNextEntry(new ZipEntry(sourcePath.relativize(dir).toString() +
	// "/"));
	// zos.closeEntry();
	// }
	// return FileVisitResult.CONTINUE;
	// }
	//
	// @Override
	// public FileVisitResult visitFile(final Path file, final
	// BasicFileAttributes attrs) throws IOException {
	// zos.putNextEntry(new ZipEntry(sourcePath.relativize(file).toString()));
	// Files.copy(file, zos);
	// zos.closeEntry();
	// return FileVisitResult.CONTINUE;
	// }
	// });
	// } catch (Exception e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// }
	// }

	public ClapProjectResponse getExecutionReport(String executionId) throws Exception {
		logger.debug("[ClapSeleniumService - getExecutionReport()] Start - executionId - " + executionId);
		ClapProjectResponse reportResponse = new ClapProjectResponse();
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
					+ "/api/reports/test/reports/" + executionId;
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {

				JSONObject reportObject = (JSONObject) new JSONParser().parse(response.toString());

				if (reportObject.get("toolName").toString().equalsIgnoreCase("Cucumber")) {
					JSONArray testSuitesArray = (JSONArray) reportObject.get("testSuites");
					JSONObject testSuiteObj = (JSONObject) testSuitesArray.get(0);
					JSONArray testCasesArray = (JSONArray) testSuiteObj.get("testCases");
					JSONObject testCasesObject = (JSONObject) testCasesArray.get(0);
					String componentList = (String) testCasesObject.get("remarks");

					if (componentList != null) {
						componentList = componentList.substring(componentList.indexOf("-- [") + 4,
								componentList.indexOf("]\n"));

						reportObject.put("FailedComponents", componentList);
					}
				}

				reportResponse.setMessage("Report generated successfully!");
				reportResponse.setData(reportObject);
				reportResponse.setSuccess(true);
				logger.debug("[ClapSeleniumService - getExecutionReport()] End");
				return reportResponse;
			} else {
				reportResponse.setMessage("Report not found for id - " + executionId);

				reportResponse.setSuccess(false);
				return reportResponse;
			}

		} catch (Exception e) {
			logger.error("[ClapSeleniumService - getExecutionReport()] Exception - " + ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());
		}

	}

	// public void startExecutionAndGenerateReport(ClapProjectRequest
	// clapProjectRequest) throws Exception {
	//
	// ClapProjectResponse response =
	// executeSeleniumScripts(clapProjectRequest);
	// JSONObject data = response.getData();
	// if (data != null && data.containsKey("executionId")) {
	// String executionDetails = data.get("executionId").toString();
	// updateCICDExecutionIdInCollection(clapProjectRequest.getScenarioID(),
	// executionDetails);
	// }
	//
	// Timer timer = new Timer();
	// TimerTask tt = new TimerTask() {
	//
	// public void run() {
	//
	// try {
	// JSONObject status = executeScriptAndGenerateReport(clapProjectRequest,
	// response);
	// if (status != null)
	// if (status.get("status").toString().equalsIgnoreCase("completed")) {
	// JSONObject statusData = null;
	// ClapProjectResponse statusResponse = null;
	// String executionId = null;
	// if (data != null && data.containsKey("executionId")) {
	// executionId = data.get("executionId").toString();
	// }
	// statusResponse = getTaskStatus(executionId);
	// if (statusResponse != null) {
	// statusData = statusResponse.getData();
	// if (statusData != null && statusData.get("reportId") != null) {
	// if (statusData.get("status").toString().equalsIgnoreCase("completed")) {
	// ClapProjectResponse reportResponse = new ClapProjectResponse();
	// reportResponse =
	// getExecutionReport(statusData.get("reportId").toString());
	// FileOutputStream fos = new FileOutputStream(
	// "C:\\" + clapProjectRequest.getProjectName() + "_"
	// + statusData.get("reportId").toString() + ".json");
	// fos.write(reportResponse.getData().toString().getBytes());
	// fos.close();
	//
	// JSONObject result = reportResponse.getData();
	// JSONArray testSuitesArray = (JSONArray) result.get("testSuites");
	// JSONObject testSuiteObj = (JSONObject) testSuitesArray.get(0);
	// JSONArray testCaseArray = (JSONArray) testSuiteObj.get("testCases");
	// JSONObject testCaseObj = (JSONObject) testCaseArray.get(0);
	// JSONArray steps = (JSONArray) testCaseObj.get("steps");
	// JSONObject step = (JSONObject) steps.get(1);
	// JSONArray logs = (JSONArray) step.get("logs");
	// JSONObject log = (JSONObject) logs.get(0);
	// String msg = (String) log.get("message");
	// msg = msg.substring(msg.indexOf("C:"), msg.indexOf("\\Surefire suite"));
	//
	// try {
	// zipReport(msg,
	// "C:\\" + clapProjectRequest.getProjectName() + "_"
	// + statusData.get("reportId").toString() + ".zip",
	// reportResponse);
	// } catch (Exception e) {
	// e.printStackTrace();
	// timer.cancel();
	// }
	//
	// }
	// }
	// }
	// timer.cancel();
	// }
	//
	// } catch (Exception e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	// timer.cancel();
	// }
	//
	// };
	// };
	// timer.schedule(tt, 10000, 10000);
	//
	// }

	private void updateExecutionIdInCollection(ClapProjectRequest clapProjectRequest, String executionId,
			String serviceName) throws Exception {
		logger.debug("[ClapSeleniumService - updateExecutionIdInCollection()] Start");

		try {
			ClapExecutionRequest clapExecution = clapProjectRequest.getClapExecution();
			logger.debug("[ClapSeleniumService - updateExecutionIdInCollection()] clapExecution - " + clapExecution
					+ " executionId - " + executionId + " awsContainerServiceID - " + serviceName);
			String url = prop.getProperty("cloudAPI") + "/cloudAPI/updateExecutionIDByAsync?type="
					+ clapExecution.getType() + "&scenarioExecutionID=" + clapExecution.getScenarioExecutionID()
					+ "&indexID=" + clapExecution.getIndexID() + "&executionID=" + executionId
					+ "&awsContainerServiceID=" + serviceName;
			StringBuffer response = openConnection(url, GET, _200);
			logger.debug(
					"[ClapSeleniumService - updateExecutionIdInCollection()] response in updating execution id to DB - "
							+ response);

		} catch (Exception e) {
			logger.error("[ClapSeleniumService - updateExecutionIdInCollection()] Exception - "
					+ ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());
		}

	}

	private void updateCICDExecutionIdInCollection(String scenarioId, String executionId) throws Exception {
		try {
			String url = "http://ec2-65-1-251-42.ap-south-1.compute.amazonaws.com:5010/cloudAPI/executeScenarioByCICD?scenarioID="
					+ scenarioId + "&executionID=" + executionId;
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {
				JSONObject reportObject = (JSONObject) new JSONParser().parse(response.toString());
			}

		} catch (Exception e) {
			throw new Exception(e);
		}

	}

	// public boolean checkRoboStatusAndDownload(String roboName) throws
	// Exception {
	// logger.debug("[ClapSeleniumService - checkRoboStatusAndDownload()] Start
	// - roboName - " + roboName);
	// boolean roboStatus = checkRobotStatus(roboName, true);
	//
	// if (!roboStatus) {
	// downloadRobot(roboName);
	// }
	// logger.debug("[ClapSeleniumService - checkRoboStatusAndDownload()] End");
	// return roboStatus;
	// }

	// private void downloadRobot(String roboName) throws Exception {
	// logger.debug("[ClapSeleniumService - downloadRobot()] Start - roboName -
	// " + roboName);
	// InputStream in = null;
	// OutputStream out = null;
	// try {
	// String url = prop.getProperty("hostName") + ":" +
	// prop.getProperty("roboPort") + "/robots/download";
	// // StringBuffer response = openConnection(url, GET, _200);
	// URL obj = new URL(url);
	// HttpURLConnection postConnection = (HttpURLConnection)
	// obj.openConnection();
	// postConnection.setRequestMethod("GET");
	// postConnection.setRequestProperty("Authorization", token);
	// postConnection.setRequestProperty("Content-Type", "application/json");
	// postConnection.setConnectTimeout(200000);
	// postConnection.setReadTimeout(200000);
	// postConnection.setDoOutput(true);
	//
	// int responseCode = postConnection.getResponseCode();
	// String readLine = null;
	// StringBuffer response = null;
	// if (200 == responseCode) {
	//
	// File localFile = new File("C:\\" + roboName).getCanonicalFile();
	// localFile.mkdirs();
	//
	// out = new BufferedOutputStream(
	// new FileOutputStream(new File(localFile +
	// "\\leap-robot.jar").getCanonicalPath()));
	// in = postConnection.getInputStream();
	//
	// byte[] buffer = new byte[1024];
	// int numRead;
	// while ((numRead = in.read(buffer)) != -1) {
	// out.write(buffer, 0, numRead);
	//
	// }
	// out.flush();
	//
	// createPropertyFilesForRobot(localFile, roboName);
	//
	// }
	//
	// } catch (Exception e) {
	// logger.error("[ClapSeleniumService - downloadRobot()] Exception - " +
	// ExceptionUtils.getStackTrace(e));
	//
	// throw new Exception(e.getMessage());
	// } finally {
	// try {
	// if (in != null) {
	// in.close();
	// }
	// if (out != null) {
	// out.close();
	// }
	// } catch (IOException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	//
	// }
	// }
	//
	// }

	// private void createPropertyFilesForRobot(File localFile, String roboName)
	// throws IOException {
	// // File file = new File(localFile.toString()).getCanonicalFile(); //
	// // initialize File object
	// // and passing path as
	// // argument
	//
	// boolean result;
	// FileOutputStream fout = null;
	// try {
	//
	// fout = new FileOutputStream(new File(localFile.toString() +
	// "\\robot.properties").getCanonicalFile());
	// StringBuilder fileBuilder = new StringBuilder();
	// fileBuilder.append(
	// "leap.robot.host =
	// http://ec2-3-108-178-223.ap-south-1.compute.amazonaws.com:2023/api/execution/\n");
	// fileBuilder.append("leap.robot.name = " + roboName + "\n");
	// fileBuilder.append("leap.robot.working_dir = .\n");
	// fileBuilder.append("leap.robot.token = " + robo_token + "\n");
	// fout.write(fileBuilder.toString().getBytes());
	// fout.close();
	//
	// fout = new FileOutputStream(new File(localFile.toString() +
	// "\\start.bat").getCanonicalFile());
	// fileBuilder = new StringBuilder();
	// fileBuilder.append("pushd \"%~dp0\"\n");
	// fileBuilder.append("path = %JAVA_HOME%\\bin;%path%\n");
	// fileBuilder.append("start java -Drobot-prop=./robot.properties -jar
	// leap-robot.jar");
	// fout.write(fileBuilder.toString().getBytes());
	// fout.close();
	//
	// } catch (IOException e) {
	// e.printStackTrace(); // prints exception if any
	// } finally {
	// try {
	// if (fout != null) {
	// fout.close();
	// }
	//
	// } catch (IOException e) {
	// // TODO Auto-generated catch block
	// e.printStackTrace();
	//
	// }
	// }
	// }

	private boolean checkRobotStatus(String roboName, boolean chkByStatus) {

		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("roboPort") + "/robots/search?name="
					+ roboName;
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {
				JSONObject robotObj = (JSONObject) new JSONParser().parse(response.toString());
				if (!chkByStatus) {
					return true;
				} else {
					if (robotObj.get("status").toString().equalsIgnoreCase("offline")) {
						getRoboToken(robotObj.get("id").toString());
						return false;
					} else {
						return true;
					}
				}

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	private void getRoboToken(String robotId) throws Exception {
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("roboPort") + "/robots/" + robotId
					+ "/token";
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {
				JSONObject robotObj = (JSONObject) new JSONParser().parse(response.toString());
				this.robo_token = robotObj.get("id").toString();
			} else {
				throw new Exception("Robot not found.");
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("Robot not found.");

		}

	}

	public StringBuffer openConnection(String url, String type, int expectedResponseCode) throws Exception {
		BufferedReader in = null;
		BufferedReader reader = null;
		try {
			URL obj = new URL(url);
			HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
			postConnection.setRequestMethod(type);
			postConnection.setRequestProperty("Authorization", token);
			postConnection.setRequestProperty("Content-Type", "application/json");
			postConnection.setConnectTimeout(200000);
			postConnection.setReadTimeout(200000);
			postConnection.setDoOutput(true);

			int responseCode = postConnection.getResponseCode();
			
			StringBuffer response = null;
			if (expectedResponseCode == responseCode) {

//				in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
				response = new StringBuffer();
//
//				reader = new BufferedReader(in);
//				String line = reader.readLine();
//				while (line != null) {
//					response.append(line);
//					line = reader.readLine();
//				}
//				in.close();
//				reader.close();
				
				return response;

			} else {
				return null;
			}
		} catch (Exception e) {
			logger.error("[ClapSeleniumService - openConnection()] Exception - " + ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());
		} finally {
			if (reader != null) {
				reader.close();
			}
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

	public StringBuffer openConnectionForPostRequest(String url, String type, JSONObject object) throws Exception {

		BufferedReader in = null;
		BufferedReader reader = null;
		try {
			URL obj = new URL(url);
			
			HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
			postConnection.setRequestMethod(type);
			postConnection.setRequestProperty("Authorization", token);
			postConnection.setRequestProperty("Content-Type", "application/json");
			postConnection.setConnectTimeout(200000);
			postConnection.setReadTimeout(200000);
			postConnection.setDoOutput(true);
			OutputStream os = postConnection.getOutputStream();
			if (null != object) {
//				os.write(object.toString().getBytes());
				os.write("object".toString().getBytes());
			}
			os.flush();
			os.close();

			int responseCode = postConnection.getResponseCode();
			logger.debug("Response code" + responseCode);
			if (_200 == responseCode || _201 == responseCode) {
//				in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
//				reader = new BufferedReader(in);
				StringBuffer response = new StringBuffer();

//				String line = reader.readLine();
//				while (line != null) {
//					response.append(line);
//					line = reader.readLine();
//				}
//				in.close();
				response.append("Success");
				return response;
			}
		} catch (Exception e) {
			logger.error("[ClapSeleniumService - openConnectionForPostRequest()] Exception - "
					+ ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());
		} finally {
			if (reader != null) {
				reader.close();
			}
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return null;
	}

	public ClapProjectResponse getReportExecutionDetails(String projectName, String testSuiteName) throws Exception {
		logger.debug("[ClapSeleniumService - getReportExecutionDetails()] Start - projectName - " + projectName
				+ " testSuiteName - " + testSuiteName);
		ClapProjectResponse statusResponse = new ClapProjectResponse();
		String executionId = null;

		try {
			ClapProjectResponse projectExecutionResponse = getDetailedProjectReport(projectName);
			JSONObject projectExecutionDetails = (JSONObject) new JSONParser()
					.parse(projectExecutionResponse.getData().get("projectReportStatus").toString());
			JSONArray executionArray = (JSONArray) projectExecutionDetails.get("executions");

			for (int i = 0; i < executionArray.size(); i++) {
				JSONObject obj = (JSONObject) executionArray.get(i);
				String suiteName = (String) obj.get("suiteName");

				if (suiteName != null) {
					if (suiteName.equalsIgnoreCase(testSuiteName)) {
						executionId = obj.get("id").toString();
						break;
					}
				}
			}
			// projectExecutionDetails);
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
					+ "/api/reports/test/reports/" + executionId;
			StringBuffer response = openConnection(url, GET, _200);

			if (null != response) {
				JSONObject statusObj = (JSONObject) new JSONParser().parse(response.toString());

				statusResponse.setData(statusObj);
				statusResponse.setMessage("Status Fetched successfully");
				statusResponse.setSuccess(true);
				logger.debug("[ClapSeleniumService - getReportExecutionDetails()] End");
				return statusResponse;

			} else {
				statusResponse.setMessage("Status for" + testSuiteName + " not found.");
				statusResponse.setSuccess(false);
				logger.debug("[ClapSeleniumService - getReportExecutionDetails()] End");
				return statusResponse;
			}

		} catch (Exception e) {
			logger.error("[ClapSeleniumService - getReportExecutionDetails()] Exception - "
					+ ExceptionUtils.getStackTrace(e));
			throw new Exception(e.getMessage());
		}

	}

	public ClapProjectResponse attachments() throws Exception {
		ClapProjectResponse statusResponse = new ClapProjectResponse();
		try {
			String url = "http://ec2-3-108-178-223.ap-south-1.compute.amazonaws.com:2023/api/reports/attachments/60e3e9e9760f7f75b108ae07";
			StringBuffer response = openConnection(url, GET, _200);
			if (null != response) {
				JSONObject statusObj = (JSONObject) new JSONParser().parse(response.toString());

				statusResponse.setData(statusObj);
				statusResponse.setMessage("Status Fetched successfully");
				statusResponse.setSuccess(true);
				return statusResponse;

			} else {
				statusResponse.setMessage("Status for 60e3e9e9760f7f75b108ae07 not found.");
				statusResponse.setSuccess(false);
				return statusResponse;
			}

		} catch (Exception e) {
			e.printStackTrace();

			statusResponse.setMessage("Status for 60e3e9e9760f7f75b108ae07 not found.");
			statusResponse.setSuccess(false);
			throw new Exception(e);
		}

	}

	public ClapProjectResponse getExecutionLogs(String executionId) throws Exception {
		logger.debug("[ClapSeleniumService - getExecutionLogs()] Start - executionId - " + executionId);
		ClapProjectResponse statusResponse = new ClapProjectResponse();
		try {
			String url = prop.getProperty("hostName") + ":" + prop.getProperty("roboPort") + "/executions/"
					+ executionId + "/jobs";
			StringBuffer response = openConnection(url, GET, _200);

			JSONArray responseArray = (JSONArray) new JSONParser().parse(response.toString());
			if (null != responseArray && responseArray.size() > 0) {
				JSONObject statusObj = null;

				statusObj = (JSONObject) responseArray.get(0);
				String jobId = statusObj.get("id").toString();
				String jobUrl = prop.getProperty("hostName") + ":" + prop.getProperty("leapPort")
						+ "/api/execution/jobs/logs/search?jobId=" + jobId;
				response = openConnection(jobUrl, GET, _200);
				responseArray = (JSONArray) new JSONParser().parse(response.toString());
				if (null != responseArray && responseArray.size() > 0) {
					statusObj = (JSONObject) responseArray.get(0);
				}
				statusResponse.setData(statusObj);
				statusResponse.setMessage("Execution logs Fetched successfully");
				statusResponse.setSuccess(true);
				logger.debug("[ClapSeleniumService - getExecutionLogs()] End");
				return statusResponse;

			} else {
				statusResponse.setMessage("Execution logs for" + executionId + " not found.");
				statusResponse.setSuccess(false);
				logger.debug("[ClapSeleniumService - getExecutionLogs()] End");
				return statusResponse;
			}

		} catch (Exception e) {
			logger.error("[ClapSeleniumService - getExecutionLogs()] Exception - " + ExceptionUtils.getStackTrace(e));

			throw new Exception(e.getMessage());
		}
	}
}

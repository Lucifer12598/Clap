package com.cts.clap.services.selenium.data;

import org.json.simple.JSONObject;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class ClapProjectResponse {

	private boolean isSuccess;
	private String message;
	private JSONObject data;

}

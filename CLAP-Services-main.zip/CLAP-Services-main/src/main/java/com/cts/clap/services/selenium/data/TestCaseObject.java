package com.cts.clap.services.selenium.data;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class TestCaseObject {
	private String name;
	private String description;
	private String type;
	private String parentName;
	private List<String> tags;

}

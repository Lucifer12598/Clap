//package com.cts.clap.services.selenium.controller;
//
//import javax.ws.rs.GET;
//import javax.ws.rs.POST;
//import javax.ws.rs.Path;
//import javax.ws.rs.PathParam;
//import javax.ws.rs.Produces;
//import javax.ws.rs.core.MediaType;
//
//import com.amazonaws.services.ecs.model.CreateServiceResult;
//import com.amazonaws.services.ecs.model.ListTasksResult;
//import com.amazonaws.services.ecs.model.RegisterTaskDefinitionResult;
//import com.amazonaws.services.ecs.model.StopTaskResult;
//import com.amazonaws.services.ecs.model.UpdateServiceResult;
//import com.cts.clap.services.selenium.data.AWSServiceRequest;
//import com.cts.clap.services.selenium.services.AWSService;
//
//@Path("/api/aws/")
//public class AWSController {
//
//	@Path("/update/{name}/count/{count}")
//	@POST()
//	@Produces(MediaType.APPLICATION_JSON)
//	public UpdateServiceResult updateService(@PathParam("name") String name, @PathParam("count") String count) throws Exception {
//
//		AWSService service = new AWSService("","");
//		AWSServiceRequest awsServiceRequest=new AWSServiceRequest();
//		awsServiceRequest.setName(name);
//		awsServiceRequest.setTasks(Integer.parseInt(count));
//
//		return service.updateService(awsServiceRequest);
//
//	}
//
//	@Path("/describe")
//	@GET()
//	@Produces(MediaType.APPLICATION_JSON)
//	public ListTasksResult getService(AWSServiceRequest awsServiceRequest) throws Exception {
//
//		AWSService service = new AWSService("","");
//
//		return service.describeService(awsServiceRequest);
//
//	}
//
//	@Path("/delete")
//	@GET()
//	@Produces(MediaType.APPLICATION_JSON)
//	public StopTaskResult stopService(AWSServiceRequest awsServiceRequest) throws Exception {
//
//		AWSService service = new AWSService("","");
//
//		return service.stopService(awsServiceRequest);
//
//	}
//
//	@Path("/create")
//	@POST()
//	@Produces(MediaType.APPLICATION_JSON)
//	public CreateServiceResult createService(AWSServiceRequest awsServiceRequest) throws Exception {
//
//		AWSService service = new AWSService("","");
//
//		return service.createService("string");
//
//	}
//	
//	@Path("/createTaskDefination")
//	@POST()
//	@Produces(MediaType.APPLICATION_JSON)
//	public RegisterTaskDefinitionResult createTaskDefination() throws Exception {
//
//		AWSService service = new AWSService("","");
//
//		return service.createTaskDefination();
//
//	}
//	
////	@Path("/createinstance")
////	@POST()
////	@Produces(MediaType.APPLICATION_JSON)
////	public Instance createInstance(){
////		AWSService service = new AWSService();
////
////		return service.createEC2Instance();
////	}
//	
////	@Path("/describeinstance")
////	@POST()
////	@Produces(MediaType.APPLICATION_JSON)
////	public Instance describeInstance(){
////		AWSService service = new AWSService();
////
////		return service.describeInstance();
////	}
//	
//}

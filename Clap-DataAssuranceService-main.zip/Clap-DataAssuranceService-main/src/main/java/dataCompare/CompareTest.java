package dataCompare;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;

public class CompareTest {

	private ConnectionDetails conDetails;
	private ConnectionManager conManager = null;
	private String srcPrimary_key;
	private String tgtPrimary_key;
	private String srcColNames;
	private String tgtColNames;
	private Map<String, String> srcRows;
	private Map<String, String> tgtRows;
	private String SummaryReport;
	private String Detailed1Report;
	private String Detailed2Report;
	LinkedHashMap<String, ArrayList<String>> mapkeys;
	LinkedHashMap<String, ArrayList<String>> mapTgtkeys;
	String SrcCompositeKey;
	String TgtCompisteKey;
	private static final Logger logger = Logger.getLogger(CompareTest.class);

	public String getSrcCompositeKey() {
		return SrcCompositeKey;
	}

	public void setSrcCompositeKey(String srcCompositeKey) {
		SrcCompositeKey = srcCompositeKey;
	}

	public String getTgtCompisteKey() {
		return TgtCompisteKey;
	}

	public void setTgtCompisteKey(String tgtCompisteKey) {
		TgtCompisteKey = tgtCompisteKey;
	}

	public CompareTest(ConnectionDetails conDetails)
			throws ClassNotFoundException, SQLException {
		super();
		this.conDetails = conDetails;
		conManager = new ConnectionManager(conDetails);

	}

	public CompareTest(ConnectionDetails conDetails, String srcQuery, String tgtQuery,
			LinkedHashMap<String, ArrayList<String>> mapkeys, LinkedHashMap<String, ArrayList<String>> mapTgtkeys)
			throws ClassNotFoundException, SQLException {
		super();
		this.conDetails = conDetails;
		this.mapkeys = mapkeys;
		this.mapTgtkeys = mapTgtkeys;
		conManager = new ConnectionManager(conDetails);

	}

	// Get Summary Report

	public ConnectionManager getConManager() {
		return conManager;
	}

	public void setConManager(ConnectionManager conManager) {
		this.conManager = conManager;
	}

	public String getSrcPrimary_key() {
		return srcPrimary_key;
	}

	public void setSrcPrimary_key(String srcPrimary_key) {
		this.srcPrimary_key = srcPrimary_key;
	}

	public String getTgtPrimary_key() {
		return tgtPrimary_key;
	}

	public void setTgtPrimary_key(String tgtPrimary_key) {
		this.tgtPrimary_key = tgtPrimary_key;
	}

	public String getSrcColNames() {
		return srcColNames;
	}

	public void setSrcColNames(String srcColNames) {
		this.srcColNames = srcColNames;
	}

	public String getTgtColNames() {
		return tgtColNames;
	}

	public void setTgtColNames(String tgtColNames) {
		this.tgtColNames = tgtColNames;
	}

	public Map<String, String> getSrcRows() {
		return srcRows;
	}

	public void setSrcRows(Map<String, String> srcRows) {
		this.srcRows = srcRows;
	}

	public Map<String, String> getTgtRows() {
		return tgtRows;
	}

	public void setTgtRows(Map<String, String> tgtRows) {
		this.tgtRows = tgtRows;
	}

	public int[] getSummaryReport() throws IOException {

		Set<String> srcKeys = srcRows.keySet();
		Set<String> tgtKeys = tgtRows.keySet();
		int noRecordsCompared = 0;
		int noRecordsUnmasked = 0;
		int noRecordsPunmasked = 0;

		for (String srckey : srcKeys) {

			if (tgtKeys.contains(srckey)) {
				noRecordsCompared++;
				if (srcRows.get(srckey).equalsIgnoreCase(tgtRows.get(srckey))) {
					noRecordsUnmasked++;
				} else {
					String[] srcrow = srcRows.get(srckey).split(",");
					String[] tgtrow = tgtRows.get(srckey).split(",");
					for (int i = 0; i < srcrow.length & i < tgtrow.length; i++) {
						if (srcrow[i].equalsIgnoreCase(tgtrow[i])) {
							noRecordsPunmasked++;
							break;
						}
					}
				}

			}

		}

		int[] maprecords = new int[4];
		maprecords[0] = srcRows.size();
		maprecords[1] = tgtRows.size();
		maprecords[2] = noRecordsCompared;
		maprecords[3] = noRecordsCompared - noRecordsUnmasked - noRecordsPunmasked;

		return maprecords;
	}

	public File generateDetailedReport1() throws IOException {
		Set<String> srckeySet = srcRows.keySet();
		Set<String> tgtkeySet = tgtRows.keySet();

		Set<Entry<String, String>> srcEntrySet = srcRows.entrySet();
		Iterator<Entry<String, String>> srcEntryitr = srcEntrySet.iterator();

		StringBuilder sb = new StringBuilder();

		Set<Entry<String, String>> tgtEntrySet = tgtRows.entrySet();
		Iterator<Entry<String, String>> tgtEntryitr = tgtEntrySet.iterator();
		sb.append("            ----------Data Not Found in Source---------------               ")
				.append(System.lineSeparator());
		sb.append("Primary key Column Name is " + srcPrimary_key + ",Column Name Sequence for Values are : "
				+ srcColNames + "").append(System.lineSeparator());

		while (tgtEntryitr.hasNext()) {

			Entry<String, String> tgtEntry = (Entry<String, String>) tgtEntryitr.next();

			if (!srckeySet.contains(tgtEntry.getKey())) {
				String[] tgtEntrysplit = tgtEntry.toString().split("=");
				sb.append("Primary Key is : " + tgtEntrysplit[0] + ",Values are : " + tgtEntrysplit[1])
						.append(System.lineSeparator());
				;
			}
		}

		sb.append("           ----------End of Data Not Found in Source---------------                ")
				.append(System.lineSeparator()).append(System.lineSeparator());

		sb.append("            ----------Data Not Found in Target---------------               ")
				.append(System.lineSeparator());
		sb.append("Primary key Column Name is " + tgtPrimary_key + ",Column Name Sequence for Values are : "
				+ tgtColNames + "").append(System.lineSeparator());
		while (srcEntryitr.hasNext()) {
			Entry<String, String> srcEntry = (Entry<String, String>) srcEntryitr.next();
			if (!tgtkeySet.contains(srcEntry.getKey())) {
				String[] srcEntrysplit = srcEntry.toString().split("=");
				sb.append("Primary Key is : " + srcEntrysplit[0] + ",Values are : " + srcEntrysplit[1])
						.append(System.lineSeparator());
				;
			}
		}

		sb.append("           ----------End of Data Not Found in Target---------------                ");

		String tempFolder = new File(System.getProperty("java.io.tmpdir")).getCanonicalPath();
		Detailed1Report = tempFolder + "/_DtlReport.csv";
		File f = new File(Detailed1Report);

		FileWriter fw = new FileWriter(f);
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write(sb.toString());
		bw.close();
		
		return f;
	}

	public File getDetailedReport2() throws IOException {
		Set<String> srcKeys = srcRows.keySet();
		Set<String> tgtKeys = tgtRows.keySet();
		StringBuilder sb1 = new StringBuilder();

		sb1.append("Primary key Column Name is " + srcPrimary_key + ",Column Name Sequence for Values are : "
				+ srcColNames + " in Source").append(System.lineSeparator());
		sb1.append("Primary key Column Name is " + tgtPrimary_key + ",Column Name Sequence for Values are : "
				+ tgtColNames + " in Target").append(System.lineSeparator());
		sb1.append("            ----------Unmasked Data---------------               ").append(System.lineSeparator());
		StringBuilder sb2 = new StringBuilder();
		sb2.append("            ----------Partially Masked Data---------------               ")
				.append(System.lineSeparator());
		for (String srckey : srcKeys) {

			if (tgtKeys.contains(srckey)) {

				if (srcRows.get(srckey).equalsIgnoreCase(tgtRows.get(srckey))) {
					sb1.append("Primary Key is : " + srckey + ",Values are : " + srcRows.get(srckey))
							.append(",Indicator : Unmasked").append(System.lineSeparator());
				} else {
					String[] srcrow = srcRows.get(srckey).split(",");
					String[] tgtrow = tgtRows.get(srckey).split(",");
					for (int i = 0; i < srcrow.length & i < tgtrow.length; i++) {
						if (srcrow[i].equalsIgnoreCase(tgtrow[i])) {
							sb2.append("Primary Key is : " + srckey + ",Values are : " + srcRows.get(srckey))
									.append(",Indicator : Partially Masked").append(System.lineSeparator());
							break;
						}
					}
				}

			}

		}
		sb1.append("            ----------End of Unmasked Data---------------               ,");
		sb2.append("            ----------End of Partially Masked Data---------------               ");
		sb1.append(sb2);

		String tempFolder = new File(System.getProperty("java.io.tmpdir")).getCanonicalPath();
		Detailed2Report = tempFolder + "_DtlReport2.csv";
		File f1 = new File(Detailed2Report);

		FileWriter fw = new FileWriter(f1);
		BufferedWriter bw = new BufferedWriter(fw);
		bw.write(sb1.toString());
		bw.close();
		return f1;
	}

	// Set Source Primary Key and Column Names

	public void collectSrcPrimaryKey(ResultSet srcRs) throws ClassNotFoundException, SQLException {

		Connection con = conManager.getSrcConnection();
		DatabaseMetaData databaseMetaData = con.getMetaData();
		String Src_Column_Key = new String();
		StringBuilder src_sbCKey = new StringBuilder();
		ResultSet rs = databaseMetaData.getPrimaryKeys(null, conDetails.getSourceSchema(), conDetails.getSourceTable());
		srcPrimary_key = "";
		while (rs.next()) {
			srcPrimary_key = srcPrimary_key + rs.getString("COLUMN_NAME") + ",";
		}
		StringBuilder dum = new StringBuilder();
		try {
			dum = new StringBuilder(srcPrimary_key).deleteCharAt(srcPrimary_key.length() - 1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
		}
		srcPrimary_key = dum.toString();
		if (srcPrimary_key == null || srcPrimary_key.equals("")) {
			if (SrcCompositeKey == null || SrcCompositeKey.equals("")) {
				NullPointerException n = new NullPointerException();
				throw n;
			}
			srcPrimary_key = SrcCompositeKey;

		}
		ResultSetMetaData rsmd = srcRs.getMetaData();
		int colcount = rsmd.getColumnCount();

		for (int k = 1; k <= colcount; k++) {
			Src_Column_Key = rsmd.getColumnName(k);
			if (!(srcPrimary_key.contains(Src_Column_Key + ",") || srcPrimary_key.endsWith(Src_Column_Key))) {

				src_sbCKey.append(Src_Column_Key).append(",");

			}

		}
		if (src_sbCKey.length() > 0)
			srcColNames = src_sbCKey.deleteCharAt(src_sbCKey.length() - 1).toString();

		con.close();
	}

	// Collect Target Primary Key and Column Names from database meta data

	public void collectTgtPrimaryKey(ResultSet tgtRs) throws ClassNotFoundException, SQLException {

		Connection con = conManager.getTgtConnection();
		DatabaseMetaData databaseMetaData = con.getMetaData();
		String Tgt_Column_Key = new String();
		StringBuilder tgt_sbCKey = new StringBuilder();
		ResultSet rs = databaseMetaData.getPrimaryKeys(null, conDetails.getTargetSchema(), conDetails.getTargetTable());
		tgtPrimary_key = "";
		while (rs.next()) {
			tgtPrimary_key = tgtPrimary_key + rs.getString("COLUMN_NAME") + ",";
		}
		StringBuilder dum = new StringBuilder();
		try {
			dum = new StringBuilder(tgtPrimary_key).deleteCharAt(tgtPrimary_key.length() - 1);
		} catch (Exception e) {
			logger.error(e);
		}
		tgtPrimary_key = dum.toString();
		if (tgtPrimary_key == null || tgtPrimary_key.equals("")) {

			if (TgtCompisteKey == null || TgtCompisteKey.equals("")) {
				NullPointerException n = new NullPointerException();
				throw n;
			}
			tgtPrimary_key = TgtCompisteKey;

		}

		ResultSetMetaData rsmd = tgtRs.getMetaData();
		int colcount = rsmd.getColumnCount();
		for (int k = 1; k <= colcount; k++) {
			Tgt_Column_Key = rsmd.getColumnName(k);
			if (!(tgtPrimary_key.contains(Tgt_Column_Key + ",") || tgtPrimary_key.endsWith(Tgt_Column_Key))) {
				tgt_sbCKey.append(Tgt_Column_Key).append(",");

			}

		}
		if (tgt_sbCKey.length() > 0)
			tgtColNames = tgt_sbCKey.deleteCharAt(tgt_sbCKey.length() - 1).toString();
		con.close();
	}
//

	public void getSrcColumnnames() {

	}

	// ResultSet to Map

	public Map<String, String> ResultSetToMap(ResultSet rs, String pk) throws SQLException {
		ResultSetMetaData rsmd = rs.getMetaData();
		List<String> columns = new ArrayList<String>(rsmd.getColumnCount());
		for (int i = 1; i <= rsmd.getColumnCount(); i++) {
			columns.add(rsmd.getColumnName(i));
		}
		Map<String, String> rows = new HashMap<String, String>();
		StringBuffer pkCol = new StringBuffer();

		String result = "";
		while (rs.next()) {
			StringBuilder sb = new StringBuilder();
			pkCol = new StringBuffer();
			result = "";
			for (String col : columns) {

				String colval = "";
				try {
					colval = rs.getString(col).trim();
				} catch (Exception e) {
					logger.error(e);
				}
				if (pk.contains(col + ",") || pk.endsWith(col))

				{
					pkCol = pkCol.append(colval).append(",");
				}

				else {
					sb.append(colval).append(",");
				}

			}
			if (sb.length() > 0)
				result = sb.deleteCharAt(sb.length() - 1).toString();
			if (pkCol.length() > 0)
				pkCol = pkCol.deleteCharAt(pkCol.length() - 1);
			rows.put(pkCol.toString(), result);
		}

		return rows;

	}

	public String getDateStamp() {
		Date date = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss");
		String strdate = formatter.format(date);
		return strdate;
	}

	public String[] getReportPaths() {
		String[] reportPaths = new String[3];
		reportPaths[0] = SummaryReport;
		reportPaths[1] = Detailed1Report;
		reportPaths[2] = Detailed2Report;
		return reportPaths;
	}

	public String ListToString(List<String> list) {
		StringBuffer string = new StringBuffer();
		for (String s : list) {
			string.append(s).append(",");
		}

		return string.toString();
	}
}

package dataCompare;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionManager {

	private ConnectionDetails condetails;

	public ConnectionManager(ConnectionDetails condetails) {

		this.condetails = condetails;
	}

	public Connection getSrcConnection() throws ClassNotFoundException, SQLException {
		Class.forName(condetails.getSourceDriver());

		Connection srcCon = DriverManager.getConnection(condetails.getSourceUrl(), condetails.getSourceUname(),
				condetails.getSourcePwd());

		return srcCon;
	}

	public Connection getTgtConnection() throws ClassNotFoundException, SQLException {

		Class.forName(condetails.getTargetDriver());
		Connection tgtCon = DriverManager.getConnection(condetails.getTargetUrl(), condetails.getTargetUname(),
				condetails.getTargetPwd());
		return tgtCon;
	}

}

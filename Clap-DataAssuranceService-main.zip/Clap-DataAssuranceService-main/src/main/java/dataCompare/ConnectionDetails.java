package dataCompare;


public class ConnectionDetails {

	private String connectionName;
	private String sourceUrl;
	private String sourceDriver;
	private String sourceSchema;
	private String sourceTable;
	private String sourceUname;
	private String sourcePwd;
	private String targetUrl;
	private String targetDriver;
	private String targetSchema;
	private String targetTable;
	private String targetUname;
	private String targetPwd;



	public ConnectionDetails(String connectionName, String sourceUrl, String sourceDriver, String sourceSchema,
			String sourceTable, String sourceUname, String sourcePwd, String targetUrl, String targetDriver,
			String targetSchema, String targetTable, String targetUname, String targetPwd) {
		super();
		this.connectionName = connectionName;
		this.sourceUrl = sourceUrl;
		this.sourceDriver = sourceDriver;
		this.sourceSchema = sourceSchema;
		this.sourceTable = sourceTable;
		this.sourceUname = sourceUname;
		this.sourcePwd = sourcePwd;
		this.targetUrl = targetUrl;
		this.targetDriver = targetDriver;
		this.targetSchema = targetSchema;
		this.targetTable = targetTable;
		this.targetUname = targetUname;
		this.targetPwd = targetPwd;
	}

	public String getSourceSchema() {
		return sourceSchema;
	}

	public void setSourceSchema(String sourceSchema) {
		this.sourceSchema = sourceSchema;
	}

	public String getSourceTable() {
		return sourceTable;
	}

	public void setSourceTable(String sourceTable) {
		this.sourceTable = sourceTable;
	}

	public String getTargetSchema() {
		return targetSchema;
	}

	public void setTargetSchema(String targetSchema) {
		this.targetSchema = targetSchema;
	}

	public String getTargetTable() {
		return targetTable;
	}

	public void setTargetTable(String targetTable) {
		this.targetTable = targetTable;
	}

	public String getSourceDriver() {
		return sourceDriver;
	}

	public void setSourceDriver(String sourceDriver) {
		this.sourceDriver = sourceDriver;
	}

	public String getTargetDriver() {
		return targetDriver;
	}

	public void setTargetDriver(String targetDriver) {
		this.targetDriver = targetDriver;
	}

	public String getConnectionName() {
		return connectionName;
	}

	public void setConnectionName(String connectionName) {
		this.connectionName = connectionName;
	}

	public String getSourceUrl() {
		return sourceUrl;
	}

	public void setSourceUrl(String sourceUrl) {
		this.sourceUrl = sourceUrl;
	}

	public String getSourceUname() {
		return sourceUname;
	}

	public void setSourceUname(String sourceUname) {
		this.sourceUname = sourceUname;
	}

	public String getSourcePwd() {
		return sourcePwd;
	}

	public void setSourcePwd(String sourcePwd) {
		this.sourcePwd = sourcePwd;
	}

	public String getTargetUrl() {
		return targetUrl;
	}

	public void setTargetUrl(String targetUrl) {
		this.targetUrl = targetUrl;
	}

	public String getTargetUname() {
		return targetUname;
	}

	public void setTargetUname(String targetUname) {
		this.targetUname = targetUname;
	}

	public String getTargetPwd() {
		return targetPwd;
	}

	public void setTargetPwd(String targetPwd) {
		this.targetPwd = targetPwd;
	}

}

package data;

import org.json.JSONObject;

public class DbData{
	private String dbName;
	private String driver;
	private String schema;
	private String url;
	private String user;
	private String password;

	public DbData(JSONObject detailsObject){
		url = detailsObject.getString("url");
		user = detailsObject.getString("userName");
		password = detailsObject.getString("databaseKey");
		driver = detailsObject.getString("driver");
		schema = detailsObject.getString("schema");
		dbName = detailsObject.getString("dbName");
	}

	public String getDbName() {
		return dbName;
	}

	public void setDbName(String dbName) {
		this.dbName = dbName;
	}

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		this.driver = driver;
	}

	public String getSchema() {
		return schema;
	}

	public void setSchema(String schema) {
		this.schema = schema;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}

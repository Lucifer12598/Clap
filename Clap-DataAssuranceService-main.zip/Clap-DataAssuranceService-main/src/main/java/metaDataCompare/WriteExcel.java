package metaDataCompare;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class WriteExcel {
	private String Path;
	private File excelFile;
	private static final Logger logger = Logger.getLogger(WriteExcel.class);

	public WriteExcel(String path) throws InvalidFormatException, IOException {
		Path = path;

		excelFile = new File(Path);
		FileInputStream fs = new FileInputStream(excelFile);
		Workbook wb = WorkbookFactory.create(fs);
		Sheet sheet = wb.getSheet("Sheet1");
		int n = sheet.getLastRowNum();
		int i = 0;

		while (i <= n) {
			try {
				sheet.removeRow(sheet.getRow(i));
			} catch (Exception e) {
				logger.error(e);
			}
			i++;
		}
		wb.write(new FileOutputStream(excelFile));
	}

	public String writeCellData(int row, int col, String diff)
			throws EncryptedDocumentException, InvalidFormatException, IOException {

		File file = new File(Path);
		FileInputStream fs = new FileInputStream(file);
		Workbook wb = WorkbookFactory.create(fs);
		Sheet sheet = wb.getSheet("Sheet1");
		Row valr = sheet.getRow(row);
		if (valr == null) {
			valr = sheet.createRow(row);
		}
		Cell cell = valr.createCell(col);
		cell.setCellValue(diff);

		wb.write(new FileOutputStream(file));
		return "Successful";
	}
	
	public File getExcelFile() {
		return excelFile;
	}

}

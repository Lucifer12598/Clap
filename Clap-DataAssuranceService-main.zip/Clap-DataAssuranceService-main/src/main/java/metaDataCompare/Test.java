package metaDataCompare;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

public class Test {

	
	
//	public String readCellData (int row, int col) throws EncryptedDocumentException,InvalidFormatException,IOException {
//		
//			String path= "C:\\Users\\UYHTIJLFST\\Desktop\\Metadata_Comparison\\tables.xlsx";
//			File file = new File(path);
//			FileInputStream fs=new FileInputStream(file);
//			Workbook wb=WorkbookFactory.create(fs);
//			Sheet sheet=wb.getSheet("Sheet1");
//			Row valRow=sheet.getRow(row);
//			String value;
//			
//			if(valRow==null) {
//				value="";
//			}
//			else 
//			{
//				Cell vCell=valRow.getCell(col);				
//				value=vCell.getStringCellValue();				
//			}
//			return value;
//			
//	}
			
	public Map<String,String> resulttoList (String table,String owner,String dbURL,String strUserID, String strPassword, String driver, String dbName)
	throws SQLException, ClassNotFoundException{
		
		StringBuilder sb = new StringBuilder();
		String colLen=null;
		String colType=null;
		String valCom=null;
		String colName=null;
		String colNull=null;

		
		Map<String,String> map= new HashMap<String,String>();
			
	
		    Class.forName(driver);
			Connection myConnection=DriverManager.getConnection(dbURL,strUserID,strPassword);
			PreparedStatement sqlStatement;
			if(dbName.equalsIgnoreCase("mysql")) {
				sqlStatement = myConnection.prepareStatement("select * from information_schema.columns where table_schema = '?' and table_name = '?'");
				sqlStatement.setString(1, owner);
				sqlStatement.setString(2, table);
			} else {
				sqlStatement = myConnection.prepareStatement("Select COLUMN_NAME,DATA_TYPE,DATA_LENGTH,NULLABLE FROM ALL_TAB_COLUMNS WHERE TABLE_NAME='?' and OWNER='?' ");
				sqlStatement.setString(1, table);
				sqlStatement.setString(2, owner);
			}
			ResultSet myResultSet = sqlStatement.executeQuery();
			
			while (myResultSet.next()) {
				colName=myResultSet.getString("COLUMN_NAME");
				colType=myResultSet.getString("DATA_TYPE");
				colLen= dbName.equalsIgnoreCase("mysql") ? myResultSet.getString("CHARACTER_MAXIMUM_LENGTH") : myResultSet.getString("DATA_LENGTH");
				colNull= dbName.equalsIgnoreCase("mysql") ? myResultSet.getString("IS_NULLABLE") : myResultSet.getString("NULLABLE");
				valCom=colType+","+colLen+","+colNull;
				sb.append(valCom);
				map.put(colName,valCom);
				sb=new StringBuilder ();
		}
				
	
		myResultSet.close();
		myConnection.close();
			
	
		
		return map;
		
	}
	
	public boolean isTableExists(String table,String owner,String dbURL,String strUserID, String strPassword, String driver) throws SQLException, ClassNotFoundException
	{
		boolean b =false;
		if(dbURL.startsWith("jdbc:")){
			Class.forName(driver);
			Connection myConnection=DriverManager.getConnection(dbURL,strUserID,strPassword);
			DatabaseMetaData dbm = myConnection.getMetaData();
			ResultSet tables = dbm.getTables(null, owner, table, null);
			if (tables.next()) {
			  b= true;
			}
			else {
				b=false;
			}
		}
	
		return b;
	}
	
			
	}

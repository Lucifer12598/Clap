package metaDataCompare;

public class MetaDataConnectionDetails {
	
	private String conName;
	private String srcDriver;
	private String srcDbURL;
	private String srcUID;
	private String srcPWD;
	private String srcSchema;
	private String srcDbName;
	private String tgtDriver;
	private String tgtDbURL;
	private String tgtUID;
	private String tgtPWD;
	private String tgtSchema;
	private String tgtDbName;



	public MetaDataConnectionDetails(String conName, String srcDriver, String srcDbURL, String srcUID, String srcPWD,
			String srcSchema, String srcDbName,String tgtDriver, String tgtDbURL, String tgtUID, String tgtPWD, String tgtSchema, String tgtDbName) {
		super();
		this.conName = conName;
		this.srcDriver = srcDriver;
		this.srcDbURL = srcDbURL;
		this.srcUID = srcUID;
		this.srcPWD = srcPWD;
		this.srcSchema = srcSchema;
		this.setSrcDbName(srcDbName);
		this.tgtDriver = tgtDriver;
		this.tgtDbURL = tgtDbURL;
		this.tgtUID = tgtUID;
		this.tgtPWD = tgtPWD;
		this.tgtSchema = tgtSchema;
		this.setTgtDbName(tgtDbName);
	}
	
	public String getSrcSchema() {
		return srcSchema;
	}

	public void setSrcSchema(String srcSchema) {
		this.srcSchema = srcSchema;
	}

	public String getTgtSchema() {
		return tgtSchema;
	}

	public void setTgtSchema(String tgtSchema) {
		this.tgtSchema = tgtSchema;
	}

	public String getConName() {
		return conName;
	}
	public void setConName(String conName) {
		this.conName = conName;
	}
	public String getSrcDriver() {
		return srcDriver;
	}
	public void setSrcDriver(String srcDriver) {
		this.srcDriver = srcDriver;
	}
	public String getSrcDbURL() {
		return srcDbURL;
	}
	public void setSrcDbURL(String srcDbURL) {
		this.srcDbURL = srcDbURL;
	}
	public String getSrcUID() {
		return srcUID;
	}
	public void setSrcUID(String srcUID) {
		this.srcUID = srcUID;
	}
	public String getSrcPWD() {
		return srcPWD;
	}
	public void setSrcPWD(String srcPWD) {
		this.srcPWD = srcPWD;
	}
	public String getTgtDriver() {
		return tgtDriver;
	}
	public void setTgtDriver(String tgtDriver) {
		this.tgtDriver = tgtDriver;
	}
	public String getTgtDbURL() {
		return tgtDbURL;
	}
	public void setTgtDbURL(String tgtDbURL) {
		this.tgtDbURL = tgtDbURL;
	}
	public String getTgtUID() {
		return tgtUID;
	}
	public void setTgtUID(String tgtUID) {
		this.tgtUID = tgtUID;
	}
	public String getTgtPWD() {
		return tgtPWD;
	}
	public void setTgtPWD(String tgtPWD) {
		this.tgtPWD = tgtPWD;
	}

	public String getSrcDbName() {
		return srcDbName;
	}

	public void setSrcDbName(String srcDbName) {
		this.srcDbName = srcDbName;
	}

	public String getTgtDbName() {
		return tgtDbName;
	}

	public void setTgtDbName(String tgtDbName) {
		this.tgtDbName = tgtDbName;
	}
	
	

}

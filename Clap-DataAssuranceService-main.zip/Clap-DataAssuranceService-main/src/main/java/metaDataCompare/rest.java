package metaDataCompare;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

public class rest {
	private static final Logger logger = Logger.getLogger(rest.class);
	public Map<String,String> resulttoList (String table,String owner,String dbURL,String strUserID,String strPassword,String driver)
			throws SQLException{
			
		String colType= null;
		String colName= null;
		
		Map<String,String> map= new HashMap<String,String>();
		try {
		      Class.forName(driver);
			Connection myConnection=DriverManager.getConnection(dbURL,strUserID,strPassword);
			PreparedStatement sqlStatement = myConnection.prepareStatement("SELECT COLUMN_NAME,LISTAGG(CONSTRAINT_TYPE,',') "
					+ "WITHIN GROUP (ORDER BY CONSTRAINT_TYPE) AS CONSTRAINT_TYPE FROM (SELECT DISTINCT B.COLUMN_NAME,A.CONSTRAINT_TYPE "
					+ "FROM  ALL_CONSTRAINTS A,ALL_CONS_COLUMNS B WHERE A.TABLE_NAME='?' and A.OWNER='?' AND A.TABLE_NAME=B.TABLE_NAME) GROUP BY COLUMN_NAME");
			sqlStatement.setString(1, table);
			sqlStatement.setString(2, owner);
			ResultSet myResultSet = sqlStatement.executeQuery();
			while (myResultSet.next()) {
				
				colName= myResultSet.getString("COLUMN_NAME");
				colType= myResultSet.getString("CONSTRAINT_TYPE");
				map.put(colName,colType);
			}
		   
			myResultSet.close();
			myConnection.close();
			} catch(Exception e) {
			  logger.error(e);
			} 
		
		return map;
			
		}
	
	public boolean isTableExists(String table,String owner,String dbURL,String strUserID, String strPassword, String driver) throws SQLException, ClassNotFoundException
	{
		if(dbURL.startsWith("jdbc:")){
			Class.forName(driver);
			Connection myConnection=DriverManager.getConnection(dbURL,strUserID,strPassword);
			DatabaseMetaData dbm = myConnection.getMetaData();
			ResultSet tables = dbm.getTables(null, owner, table, null);
			if (tables.next()) {
			  return true;
			}
		}
	
		return false;
	}
}

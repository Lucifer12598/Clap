package cloud_assurance;

import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import com.google.common.collect.MapDifference;
import com.google.common.collect.Maps;

import metaDataCompare.MetaDataConnectionDetails;
import metaDataCompare.Test;
import metaDataCompare.WriteExcel;
import metaDataCompare.rest;

public class GenerateExcelOutput {
	private static final Logger logger = Logger.getLogger(GenerateExcelOutput.class);
	int tblsnasrc = 0, tblsnatgt = 0, tblsComparedColStr = 0, tblsComparedCons = 0, consequal = 0, coluequal = 0,
			nosrctbls = 0, notgttbls = 0;
	WriteExcel wed;

	public File generateMetaDataReport(MetaDataConnectionDetails mdcd, List<String> srcTableNames,
			List<String> tgtTableNames, String choice) throws SQLException, EncryptedDocumentException,
			InvalidFormatException, IOException, ClassNotFoundException {

		int row = 1;
		int col1 = 0;
		Test tes = new Test();
		rest res = new rest();
		int count = 0;
		nosrctbls = srcTableNames.size();
		notgttbls = tgtTableNames.size();
		String Path = new File(System.getProperty("java.io.tmpdir")).getCanonicalPath()+"/MetaDataReport.xlsx";
		wed = new WriteExcel(Path);
		Map<String, String> map1 = null;
		Map<String, String> map2 = null;
		Map<String, String> map3 = null;
		Map<String, String> map4 = null;

		if (choice.equalsIgnoreCase("columns")) {
			wed.writeCellData(0, 0, "Source_Schema_Name");
			wed.writeCellData(0, 1, "Target_Schema_Name");
			wed.writeCellData(0, 2, "Source_Table_Name");
			wed.writeCellData(0, 3, "Target_Table_Name");
			wed.writeCellData(0, 4, "Column Structure Compare");

			do {
				wed.writeCellData(row, col1 + 2, srcTableNames.get(count));
				wed.writeCellData(row, col1 + 3, tgtTableNames.get(count));
				wed.writeCellData(row, col1, mdcd.getSrcSchema());
				wed.writeCellData(row, col1 + 1, mdcd.getTgtSchema());
				boolean insrc = tes.isTableExists(srcTableNames.get(count), mdcd.getSrcSchema(), mdcd.getSrcDbURL(),
						mdcd.getSrcUID(), mdcd.getSrcPWD(), mdcd.getSrcDriver());
				boolean intgt = tes.isTableExists(tgtTableNames.get(count), mdcd.getTgtSchema(), mdcd.getTgtDbURL(),
						mdcd.getTgtUID(), mdcd.getTgtPWD(), mdcd.getTgtDriver());
				if (!insrc & !intgt) {

					logger.info("Table Not Found in Source(L) and Target(R)");
					wed.writeCellData(row, col1 + 4, "Table Not Found in Source(L) and Target(R)");
					row++;
					count++;
					continue;
				} else if (!insrc) {
					wed.writeCellData(row, col1 + 4, "Table Not Found in Source(L)");
					row++;
					count++;
					continue;
				} else if (!intgt) {
					wed.writeCellData(row, col1 + 4, "Table Not Found in Target(R)");
					row++;
					count++;
					continue;
				}

				map1 = tes.resulttoList(srcTableNames.get(count), mdcd.getSrcSchema(), mdcd.getSrcDbURL(),
						mdcd.getSrcUID(), mdcd.getSrcPWD(), mdcd.getSrcDriver(),mdcd.getSrcDbName());
				map2 = tes.resulttoList(tgtTableNames.get(count), mdcd.getTgtSchema(), mdcd.getTgtDbURL(),
						mdcd.getTgtUID(), mdcd.getTgtPWD(), mdcd.getTgtDriver(),mdcd.getTgtDbName());

				columnStructureCompare(map1, map2, row, 4);

				row++;
				count++;
			} while (count < srcTableNames.size() && count < tgtTableNames.size());

		}

		else if (choice.equalsIgnoreCase("constraints")) {
			wed.writeCellData(0, 0, "Source_Schema_Name");
			wed.writeCellData(0, 1, "Target_Schema_Name");
			wed.writeCellData(0, 2, "Source_Table_Name");
			wed.writeCellData(0, 3, "Target_Table_Name");
			wed.writeCellData(0, 4, "Constraints Compare");

			do {

				boolean insrc = res.isTableExists(srcTableNames.get(count), mdcd.getSrcSchema(), mdcd.getSrcDbURL(),
						mdcd.getSrcUID(), mdcd.getSrcPWD(), mdcd.getSrcDriver());
				boolean intgt = res.isTableExists(tgtTableNames.get(count), mdcd.getTgtSchema(), mdcd.getTgtDbURL(),
						mdcd.getTgtUID(), mdcd.getTgtPWD(), mdcd.getTgtDriver());
				if (!insrc & !intgt) {

					logger.info("Table Not Found in Source(L) and Target(R)");
					wed.writeCellData(row, col1 + 4, "Table Not Found in Source(L) and Target(R)");
					row++;
					count++;
					continue;
				} else if (!insrc) {
					wed.writeCellData(row, col1 + 4, "Table Not Found in Source(L)");
					row++;
					count++;
					continue;
				} else if (!intgt) {
					wed.writeCellData(row, col1 + 4, "Table Not Found in Target(R)");
					row++;
					count++;
					continue;
				}
				wed.writeCellData(row, col1 + 2, srcTableNames.get(count));
				wed.writeCellData(row, col1 + 3, tgtTableNames.get(count));
				wed.writeCellData(row, col1, mdcd.getSrcSchema());
				wed.writeCellData(row, col1 + 1, mdcd.getTgtSchema());

				map3 = res.resulttoList(srcTableNames.get(count), mdcd.getSrcSchema(), mdcd.getSrcDbURL(),
						mdcd.getSrcUID(), mdcd.getSrcPWD(), mdcd.getSrcDriver());
				map4 = res.resulttoList(tgtTableNames.get(count), mdcd.getTgtSchema(), mdcd.getTgtDbURL(),
						mdcd.getTgtUID(), mdcd.getTgtPWD(), mdcd.getTgtDriver());

				columnConstraintCompare(map3, map4, row, 4);
				row++;
				count++;
			} while (count < srcTableNames.size() && count < tgtTableNames.size());
		} else if (choice.equals("both")) {
			wed.writeCellData(0, 0, "Source_Schema_Name");
			wed.writeCellData(0, 1, "Target_Schema_Name");
			wed.writeCellData(0, 2, "Source_Table_Name");
			wed.writeCellData(0, 3, "Target_Table_Name");
			wed.writeCellData(0, 4, "Column Structure Compare");
			wed.writeCellData(0, 5, "Constraints Compare");

			do {

				boolean insrc = res.isTableExists(srcTableNames.get(count), mdcd.getSrcSchema(), mdcd.getSrcDbURL(),
						mdcd.getSrcUID(), mdcd.getSrcPWD(), mdcd.getSrcDriver());
				boolean intgt = res.isTableExists(tgtTableNames.get(count), mdcd.getTgtSchema(), mdcd.getTgtDbURL(),
						mdcd.getTgtUID(), mdcd.getTgtPWD(), mdcd.getTgtDriver());
				if (!insrc & !intgt) {

					logger.info("Table Not Found in Source(L) and Target(R)");
					wed.writeCellData(row, col1 + 4, "Table Not Found in Source(L) and Target(R)");
					wed.writeCellData(row, col1 + 5, "Table Not Found in Source(L) and Target(R)");
					row++;
					count++;
					continue;
				} else if (!insrc) {
					wed.writeCellData(row, col1 + 4, "Table Not Found in Source(L)");
					wed.writeCellData(row, col1 + 5, "Table Not Found in Source(L)");
					row++;
					count++;
					continue;
				} else if (!intgt) {
					wed.writeCellData(row, col1 + 4, "Table Not Found in Target(R)");
					wed.writeCellData(row, col1 + 5, "Table Not Found in Target(R)");
					row++;
					count++;
					continue;
				}
				wed.writeCellData(row, col1 + 2, srcTableNames.get(count));
				wed.writeCellData(row, col1 + 3, tgtTableNames.get(count));
				wed.writeCellData(row, col1, mdcd.getSrcSchema());
				wed.writeCellData(row, col1 + 1, mdcd.getTgtSchema());
				try {
					map1 = tes.resulttoList(srcTableNames.get(count), mdcd.getSrcSchema(), mdcd.getSrcDbURL(),
							mdcd.getSrcUID(), mdcd.getSrcPWD(), mdcd.getSrcDriver(),mdcd.getSrcDbName());
					map2 = tes.resulttoList(tgtTableNames.get(count), mdcd.getTgtSchema(), mdcd.getTgtDbURL(),
							mdcd.getTgtUID(), mdcd.getTgtPWD(), mdcd.getTgtDriver(),mdcd.getTgtDbName());
				} catch (ClassNotFoundException e) {
					logger.error(e);
				} catch (SQLException e) {
					logger.error(e);
				}
				map3 = res.resulttoList(srcTableNames.get(count), mdcd.getSrcSchema(), mdcd.getSrcDbURL(),
						mdcd.getSrcUID(), mdcd.getSrcPWD(), mdcd.getSrcDriver());
				map4 = res.resulttoList(tgtTableNames.get(count), mdcd.getTgtSchema(), mdcd.getTgtDbURL(),
						mdcd.getTgtUID(), mdcd.getTgtPWD(), mdcd.getTgtDriver());

				columnStructureCompare(map1, map2, row, 4);
				columnConstraintCompare(map3, map4, row, 5);
				row++;
				count++;
			} while (count < srcTableNames.size() && count < tgtTableNames.size());
		}

		return wed.getExcelFile();
	}

	public void columnStructureCompare(Map<String, String> map1, Map<String, String> map2, int row, int col1)
			throws EncryptedDocumentException, InvalidFormatException, IOException {

		if (map1.size() == 0 || map2.size() == 0) {

			if (map1.size() == 0 && map2.size() == 0) {

				wed.writeCellData(row, col1, "No Columns Found in Source(L) and Target(R)");
				tblsnasrc++;
				tblsnatgt++;

			} else {
				if (map1.size() == 0) {

					wed.writeCellData(row, col1, "No Columns Found in Source(L)");
					tblsnasrc++;
				}

				else {

					wed.writeCellData(row, col1, "No Columns Found in Target(R)");
					tblsnatgt++;
				}
			}

			row = row + 1;
		} else {
			tblsComparedColStr++;
			MapDifference<String, String> diff = Maps.difference(map1, map2);
			if (diff.toString().equalsIgnoreCase("equal")) {
				coluequal++;
			}
			wed.writeCellData(row, col1, replaceWords(diff.toString()));
			row = row + 1;
		}

	}

	public String replaceWords(String original) {
		if (original.contains("only on left")) {
			original = original.replaceAll("only on left", "only on source");
		}
		if (original.contains("only on right")) {
			original = original.replaceAll("only on right", "only on target");
		}
		return original;
	}

	public void columnConstraintCompare(Map<String, String> map3, Map<String, String> map4, int row1, int col1)
			throws EncryptedDocumentException, InvalidFormatException, IOException {
		if (map3.size() == 0 || map4.size() == 0) {

			if (map3.size() == 0 && map4.size() == 0) {

				wed.writeCellData(row1, col1, "No Constraints Found in Source(L) and Target(R)");

			} else {
				if (map3.size() == 0) {

					wed.writeCellData(row1, col1, "No Constraints Found in Source(L)");
				}

				else {

					wed.writeCellData(row1, col1, "No Constraints Found in Target(R)");
				}
			}

		} else {
			tblsComparedCons++;
			MapDifference<String, String> diff = Maps.difference(map3, map4);
			if (diff.toString().equalsIgnoreCase("equal")) {
				consequal++;
			}
			wed.writeCellData(row1, col1, replaceWords(diff.toString()));

		}

	}
}

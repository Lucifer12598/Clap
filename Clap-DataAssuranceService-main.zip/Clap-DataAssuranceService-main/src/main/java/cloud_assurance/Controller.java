package cloud_assurance;


import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/api")
public class Controller {
	@GET
	@Path("/check")
	@Produces(MediaType.TEXT_PLAIN)
	public Response check() {
		return Response.ok().entity("Server is Running").build();
	}
	
	@POST
	@Path("/validateConnection")
	@Produces(MediaType.TEXT_PLAIN)
	public Response checkConnection(String jsonString) {
		try {
			String responseString = DatabaseConnection.getInstance().checkConnection(jsonString);
			return Response.ok().entity(responseString).build();
		} catch(Exception e) {
			return Response.status(400).entity(e.getMessage()).build();
		}
	}
	
	@POST
	@Path("/getTables")
	@Produces(MediaType.TEXT_PLAIN)
	public Response getTables(String jsonString) {
		try {
			String responseString = DatabaseConnection.getInstance().getTables(jsonString,false);
			return Response.ok().entity(responseString).build();
		} catch(Exception e) {
			return Response.status(400).entity(e.getMessage()).build();
		}
	}
	
	@POST
	@Path("/getTablesWithColumns")
	@Produces(MediaType.TEXT_PLAIN)
	public Response getTablesWithColumns(String jsonString) {
		try {
			String responseString = DatabaseConnection.getInstance().getTables(jsonString,true);
			return Response.ok().entity(responseString).build();
		} catch(Exception e) {
			return Response.status(400).entity(e.getMessage()).build();
		}
	}
	
	@POST
	@Path("/getMetadataReport")
	@Produces(MediaType.TEXT_PLAIN)
	public Response getMetadataReport(String jsonString) {
		try {
			String responseString = DatabaseConnection.getInstance().getMetadataReport(jsonString);
			return Response.ok().entity(responseString).build();
		} catch(Exception e) {
			return Response.status(400).entity(e.getMessage()).build();
		}
	}
	
	@POST
	@Path("/getDataReport")
	@Produces(MediaType.TEXT_PLAIN)
	public Response getDataReport(String jsonString) {
		try {
			String responseString = DatabaseConnection.getInstance().startAsyncMethod(jsonString,"Data");
			return Response.ok().entity(responseString).build();
		} catch(Exception e) {
			return Response.status(400).entity(e.getMessage()).build();
		}
	}
}

package cloud_assurance;

import java.io.File;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import data.DbData;
import node.NodeSubmission;

public class DatabaseConnection {
	private static DatabaseConnection conn = null;
	private static final Logger logger = Logger.getLogger(DatabaseConnection.class);
	private static final int MAX_LOOPS = 100;

	public static DatabaseConnection getInstance() {
		if (conn == null) {
			conn = new DatabaseConnection();
		}
		return conn;
	}

	private String validateConnection(String url, String user, String pass, String driverString) throws SQLException {
		Connection con = null;
		String re = "Unable to connect. Something went wrong";
		try {
			if(url.startsWith("jdbc:")) {
				Class.forName(driverString);
				con = DriverManager.getConnection(url, user, pass);
				re = "Connection Established";
				con.close();
			}
		} catch (Exception e) {
			re = "Invalid Connection Details";
			if(e.getMessage().contains("Unknown database")) {
				re += ". "+e.getMessage();
			} else if(e.getMessage().contains("Access denied")) {
				re += ". Authentication failed.";
			} else if(e.getMessage().contains("Communications link failure")) {
				re = "Unable to establish connection to the url provided.";
			} else if(e.getMessage().contains("is not allowed to connect")) {
				re = e.getMessage();
			}
			logger.error(e);
		}
		return re;
	}

	public String checkConnection(String jsonString) throws Exception {
		JSONObject tables = new JSONObject();
		JSONObject detailsObject = new JSONObject(jsonString);
		try {
			DbData sourceData = new DbData(detailsObject.getJSONObject("source"));
			DbData targetData = new DbData(detailsObject.getJSONObject("target"));
			tables.put("sourceConnection", validateConnection(sourceData.getUrl(), sourceData.getUser(),
					sourceData.getPassword(), sourceData.getDriver()));
			tables.put("targetConnection", validateConnection(targetData.getUrl(), targetData.getUser(),
					targetData.getPassword(), targetData.getDriver()));
		} catch (SQLException e) {
			throw new Exception("Something Went Wrong");
		} catch (JSONException e) {
			throw new Exception("Invalid Body");
		}
		return tables.toString();
	}
	
	public static JSONObject getSQLColumns(Connection con, String Schema, String table)
			throws SQLException, ClassNotFoundException {

		JSONArray columnnames = new JSONArray();
		JSONArray primaryKeys = new JSONArray();
		JSONObject tableObject = new JSONObject();

		PreparedStatement queryStatement1 = con.prepareStatement("SELECT COLUMN_NAME " + " FROM INFORMATION_SCHEMA.COLUMNS " + " WHERE TABLE_SCHEMA = '?' " 
				+ " AND COLUMN_KEY = 'PRI' AND TABLE_NAME='?'");
		queryStatement1.setString(1, Schema);
		queryStatement1.setString(2, table);
		PreparedStatement queryStatement2 = con.prepareStatement("SELECT COLUMN_NAME " + " FROM INFORMATION_SCHEMA.COLUMNS" + " WHERE TABLE_SCHEMA = '?'" 
				+ " AND TABLE_NAME='?'");
		queryStatement2.setString(1, Schema);
		queryStatement2.setString(2, table);

		ResultSet rs1 = queryStatement1.executeQuery();
		while (rs1.next()) {
			primaryKeys.put(rs1.getString("COLUMN_NAME"));
		}
		rs1.close();

		ResultSet rs2 = queryStatement2.executeQuery();
		while (rs2.next()) {
			columnnames.put(rs2.getString("COLUMN_NAME"));
		}
		rs2.close();
		tableObject.put("table", table);
		tableObject.put("columns", columnnames);
		tableObject.put("primaryKey", primaryKeys);
		
		return tableObject;

	}

	private JSONArray getSQLTables(DbData sb, boolean withCOlumns) throws ClassNotFoundException, SQLException {
		String tblsQuery = "SELECT TABLE_NAME " + " FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=?";

		JSONArray tblNames = new JSONArray();

		if(sb.getUrl().startsWith("jdbc:")){
			Class.forName(sb.getDriver());
			Connection con = DriverManager.getConnection(sb.getUrl()+"?autoReconnect=true&useSSL=false", sb.getUser(), sb.getPassword());
			PreparedStatement st = con.prepareStatement(tblsQuery);
			st.setString(1, sb.getSchema());
			ResultSet rs = st.executeQuery();
			while (rs.next()) {
				String tableName = rs.getString("TABLE_NAME");
				if(withCOlumns) {
					tblNames.put(getSQLColumns(con, sb.getSchema(), tableName));
				} else {
					tblNames.put(tableName);
				}
			}	
		}

		return tblNames;
	}

	private JSONObject getGenericColumns(DatabaseMetaData md, String schema, String table)
			throws SQLException, ClassNotFoundException {
		ResultSet rs1 = md.getPrimaryKeys(null, schema, table);
		JSONArray columnnames = new JSONArray();
		JSONArray primaryKeys = new JSONArray();
		JSONObject tableObject = new JSONObject();
		while (rs1.next()) {
			primaryKeys.put(rs1.getString("COLUMN_NAME"));
		}
		rs1.close();
		ResultSet rs = md.getColumns(null, schema, table, null);

		while (rs.next()) {

			columnnames.put(rs.getString("COLUMN_NAME"));

		}

		tableObject.put("table", table);
		tableObject.put("columns", columnnames);
		tableObject.put("primaryKey", primaryKeys);
		return tableObject;

	}

	public JSONArray getGenericTables(DbData sb, boolean withColumns) {
		JSONArray tables = new JSONArray();
		try {
			if(sb.getUrl().startsWith("jdbc:")){
				Class.forName(sb.getDriver());
				Connection con = DriverManager.getConnection(sb.getUrl(), sb.getUser(), sb.getPassword());
				DatabaseMetaData md = con.getMetaData();
				String[] types = { "TABLE" };
				ResultSet rs = md.getTables(null, sb.getSchema(), "%", types);
				while (rs.next()) {
					String table = rs.getString(3);
					if (withColumns) {
						tables.put(getGenericColumns(md, sb.getSchema(), table));
					} else {
						tables.put(table);
					}

				}
				con.close();
			}
			return tables;
		} catch (SQLException e) {
			logger.error(e);
		} catch (ClassNotFoundException e) {
			logger.error(e);
		}
		return tables;
	}

	public String getTables(String jsonString, boolean withColumns) throws Exception {
		JSONObject tables = new JSONObject();
		JSONObject detailsObject = new JSONObject(jsonString);
		try {
			DbData sourceData = new DbData(detailsObject.getJSONObject("source"));
			DbData targetData = new DbData(detailsObject.getJSONObject("target"));
			if(sourceData.getDbName().equalsIgnoreCase("mysql")) {
				tables.put("sourceTables", getSQLTables(sourceData, withColumns));
			} else {
				tables.put("sourceTables", getGenericTables(sourceData, withColumns));
			}
			if(targetData.getDbName().equalsIgnoreCase("mysql")) {
				tables.put("targetTables", getSQLTables(targetData, withColumns));
			} else {
				tables.put("targetTables", getGenericTables(targetData, withColumns));
			}
		} catch (JSONException e) {
			throw new Exception("Invalid Body");
		} catch (Exception e) {
			throw new Exception("Something Went Wrong");
		}
		return tables.toString();
	}
	
	public String startAsyncMethod(String jsonString, String method) throws InterruptedException {
		ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(1);
		executor.submit(() -> {
			try {
				Thread.sleep(10000);
				if(method.equals("Data")) {
					getDataReport(jsonString);
				} else {
					getMetadataReport(jsonString);
				}
			} catch (InterruptedException e) {
				logger.error(e);
			} catch (Exception e) {
				logger.error(e);
			}
		});
		return "Request Submitted";
	}

	public String getMetadataReport(String jsonString) throws Exception {
		JSONArray resultArray = new JSONArray();
		try {
			GenerateJsonOutput output = new GenerateJsonOutput();
			JSONObject detailsObject = new JSONObject(jsonString);
			JSONArray srcTableNames = detailsObject.getJSONArray("sourceTables");
			JSONArray tgtTableNames = detailsObject.getJSONArray("targetTables");
			DbData sourceData = new DbData(detailsObject.getJSONObject("source"));
			DbData targetData = new DbData(detailsObject.getJSONObject("target"));
			String choice = detailsObject.getString("option");
			resultArray = output.generateMetaDataReport(sourceData, targetData, srcTableNames, tgtTableNames, choice);
		} catch (JSONException e) {
			throw new Exception("Invalid Body");
		} catch (Exception e) {
			throw new Exception("Something Went Wrong");
		}
		return resultArray.toString();
	}

	public Map<String, ArrayList<String>> convertToMap(JSONObject tables) {
		int loopCount = 0;
		Map<String, ArrayList<String>> map = new LinkedHashMap<>();
		Iterator<String> keys = tables.keys();
		while (keys.hasNext()) {
			if(loopCount <= MAX_LOOPS) {
				String key = keys.next();
				ArrayList<String> columns = new ArrayList<>();
				if (tables.get(key) instanceof JSONArray) {
					JSONArray array = tables.getJSONArray(key);
					for (int i = 0; i < array.length(); i++) {
						columns.add(array.getString(i));
					}
				}
				map.put(key, columns);
				loopCount++;
			} else {
				break;
			}
		}
		return map;
	}

	public String getDataReport(String jsonString) throws Exception {
		try {
			GenerateCsvOuput output = new GenerateCsvOuput();
			JSONObject detailsObject = new JSONObject(jsonString);
			DbData sourceData = new DbData(detailsObject.getJSONObject("source"));
			DbData targetData = new DbData(detailsObject.getJSONObject("target"));
			String executionId = detailsObject.getString("executionId");
			Map<String, ArrayList<String>> sourceTables = convertToMap(detailsObject.getJSONObject("sourceTables"));
			Map<String, ArrayList<String>> targetTables = convertToMap(detailsObject.getJSONObject("targetTables"));
			Map<String, ArrayList<String>> sourceKeys = convertToMap(detailsObject.getJSONObject("sourceKeys"));
			Map<String, ArrayList<String>> targetKeys = convertToMap(detailsObject.getJSONObject("targetKeys"));
			File zipFile = output.compareDbData(sourceTables, targetTables, sourceData, targetData, 
								sourceKeys, targetKeys, executionId);
			if(zipFile != null) {
				NodeSubmission ns = new NodeSubmission(executionId);
				ns.postDataReport(zipFile);
			}
		} catch (JSONException e) {
			throw new Exception("Invalid Body");
		} catch (Exception e) {
			throw new Exception("Something Went Wrong");
		}
		return "Success";
	}
}

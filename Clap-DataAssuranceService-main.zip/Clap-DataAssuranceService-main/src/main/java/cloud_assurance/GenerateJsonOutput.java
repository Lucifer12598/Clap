package cloud_assurance;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.json.JSONArray;
import org.json.JSONObject;

import com.google.common.collect.MapDifference;
import com.google.common.collect.Maps;

import data.DbData;
import metaDataCompare.Test;
import metaDataCompare.rest;

public class GenerateJsonOutput {
	private static final Logger logger = Logger.getLogger(GenerateJsonOutput.class);
	int tblsnasrc = 0, tblsnatgt = 0, tblsComparedColStr = 0, tblsComparedCons = 0, consequal = 0, coluequal = 0,
			nosrctbls = 0, notgttbls = 0;

	public JSONArray generateMetaDataReport(DbData sourceData, DbData targetData, JSONArray srcTableNames,
			JSONArray tgtTableNames, String choice) throws SQLException, EncryptedDocumentException,
			InvalidFormatException, IOException, ClassNotFoundException {

		int row = 1;
		Test tes = new Test();
		rest res = new rest();
		int count = 0;
		nosrctbls = srcTableNames.length();
		notgttbls = tgtTableNames.length();
		Map<String, String> map1 = null;
		Map<String, String> map2 = null;
		Map<String, String> map3 = null;
		Map<String, String> map4 = null;
		JSONArray jsonOutput = new JSONArray();

		if (choice.equalsIgnoreCase("columns")) {

			do {
				JSONObject object = new JSONObject();
				object.put("Source_Schema_Name", sourceData.getSchema());
				object.put("Target_Schema_Name", targetData.getSchema());
				object.put("Source_Table_Name", srcTableNames.get(count));
				object.put("Target_Table_Name", tgtTableNames.get(count));
				
				boolean insrc = tes.isTableExists(srcTableNames.getString(count), sourceData.getSchema(), sourceData.getUrl(),
						sourceData.getUser(), sourceData.getPassword(), sourceData.getDriver());
				boolean intgt = tes.isTableExists(tgtTableNames.getString(count), targetData.getSchema(), targetData.getUrl(),
						targetData.getUser(), targetData.getPassword(), targetData.getDriver());
				if (!insrc & !intgt) {

					logger.info("Table Not Found in Source(L) and Target(R)");
					object.put("Column Structure Compare", "Table Not Found in Source(L) and Target(R)");
					row++;
					count++;
					continue;
				} else if (!insrc) {
					object.put("Column Structure Compare", "Table Not Found in Source(L)");
					row++;
					count++;
					continue;
				} else if (!intgt) {
					object.put("Column Structure Compare", "Table Not Found in Target(R)");
					row++;
					count++;
					continue;
				}

				map1 = tes.resulttoList(srcTableNames.getString(count), sourceData.getSchema(), sourceData.getUrl(),
						sourceData.getUser(), sourceData.getPassword(), sourceData.getDriver(),sourceData.getDbName());
				map2 = tes.resulttoList(tgtTableNames.getString(count), targetData.getSchema(), targetData.getUrl(),
						targetData.getUser(), targetData.getPassword(), targetData.getDriver(),targetData.getDbName());

				columnStructureCompare(map1, map2, row, object);

				row++;
				count++;
				jsonOutput.put(object);
			} while (count < srcTableNames.length() && count < tgtTableNames.length());

		}

		else if (choice.equalsIgnoreCase("constraints")) {

			do {
				JSONObject object = new JSONObject();
				object.put("Source_Schema_Name", sourceData.getSchema());
				object.put("Target_Schema_Name", targetData.getSchema());
				object.put("Source_Table_Name", srcTableNames.get(count));
				object.put("Target_Table_Name", tgtTableNames.get(count));
				boolean insrc = res.isTableExists(srcTableNames.getString(count), sourceData.getSchema(), sourceData.getUrl(),
						sourceData.getUser(), sourceData.getPassword(), sourceData.getDriver());
				boolean intgt = res.isTableExists(tgtTableNames.getString(count), targetData.getSchema(), targetData.getUrl(),
						targetData.getUser(), targetData.getPassword(), targetData.getDriver());
				if (!insrc & !intgt) {

					object.put("Constraints Compare", "Table Not Found in Source(L) and Target(R)");
					row++;
					count++;
					continue;
				} else if (!insrc) {
					object.put("Constraints Compare", "Table Not Found in Source(L)");
					row++;
					count++;
					continue;
				} else if (!intgt) {
					object.put("Constraints Compare", "Table Not Found in Target(R)");
					row++;
					count++;
					continue;
				}
				map3 = res.resulttoList(srcTableNames.getString(count), sourceData.getSchema(), sourceData.getUrl(),
						sourceData.getUser(), sourceData.getPassword(), sourceData.getDriver());
				map4 = res.resulttoList(tgtTableNames.getString(count), targetData.getSchema(), targetData.getUrl(),
						targetData.getUser(), targetData.getPassword(), targetData.getDriver());

				columnConstraintCompare(map3, map4, row, object);
				row++;
				count++;
				jsonOutput.put(object);
			} while (count < srcTableNames.length() && count < tgtTableNames.length());
		} else if (choice.equals("both")) {

			do {
				JSONObject object = new JSONObject();
				object.put("Source_Schema_Name", sourceData.getSchema());
				object.put("Target_Schema_Name", targetData.getSchema());
				object.put("Source_Table_Name", srcTableNames.get(count));
				object.put("Target_Table_Name", tgtTableNames.get(count));
				boolean insrc = res.isTableExists(srcTableNames.getString(count), sourceData.getSchema(), sourceData.getUrl(),
						sourceData.getUser(), sourceData.getPassword(), sourceData.getDriver());
				boolean intgt = res.isTableExists(tgtTableNames.getString(count), targetData.getSchema(), targetData.getUrl(),
						targetData.getUser(), targetData.getPassword(), targetData.getDriver());
				if (!insrc & !intgt) {
					object.put("Column Structure Compare", "Table Not Found in Source(L) and Target(R)");
					object.put("Constraints Compare", "Table Not Found in Source(L) and Target(R)");
					row++;
					count++;
					continue;
				} else if (!insrc) {
					object.put("Column Structure Compare", "Table Not Found in Source(L) and Target(R)");
					object.put("Constraints Compare", "Table Not Found in Source(L)");
					row++;
					count++;
					continue;
				} else if (!intgt) {
					object.put("Column Structure Compare", "Table Not Found in Source(L) and Target(R)");
					object.put("Constraints Compare", "Table Not Found in Target(R)");
					row++;
					count++;
					continue;
				}
				try {
					map1 = tes.resulttoList(srcTableNames.getString(count), sourceData.getSchema(), sourceData.getUrl(),
							sourceData.getUser(), sourceData.getPassword(), sourceData.getDriver(),sourceData.getDbName());
					map2 = tes.resulttoList(tgtTableNames.getString(count), targetData.getSchema(), targetData.getUrl(),
							targetData.getUser(), targetData.getPassword(), targetData.getDriver(),targetData.getDbName());
				} catch (ClassNotFoundException e) {
					logger.error(e);
				} catch (SQLException e) {
					logger.error(e);
				}
				map3 = res.resulttoList(srcTableNames.getString(count), sourceData.getSchema(), sourceData.getUrl(),
						sourceData.getUser(), sourceData.getPassword(), sourceData.getDriver());
				map4 = res.resulttoList(tgtTableNames.getString(count), targetData.getSchema(), targetData.getUrl(),
						targetData.getUser(), targetData.getPassword(), targetData.getDriver());

				columnStructureCompare(map1, map2, row, object);
				columnConstraintCompare(map3, map4, row, object);
				row++;
				count++;
				jsonOutput.put(object);
			} while (count < srcTableNames.length() && count < tgtTableNames.length());
		}

		return jsonOutput;
	}

	public void columnStructureCompare(Map<String, String> map1, Map<String, String> map2,int row, JSONObject object)
			throws EncryptedDocumentException, InvalidFormatException, IOException {

		if (map1.size() == 0 || map2.size() == 0) {

			if (map1.size() == 0 && map2.size() == 0) {
				object.put("Column Structure Compare", "No Columns Found in Source(L) and Target(R)");
				tblsnasrc++;
				tblsnatgt++;

			} else {
				if (map1.size() == 0) {
					object.put("Column Structure Compare", "No Columns Found in Source(L)");
					tblsnasrc++;
				}

				else {
					object.put("Column Structure Compare", "No Columns Found in Target(R)");
					tblsnatgt++;
				}
			}

			row = row + 1;
		} else {
			tblsComparedColStr++;
			MapDifference<String, String> diff = Maps.difference(map1, map2);
			if (diff.toString().equalsIgnoreCase("equal")) {
				coluequal++;
			}
			object.put("Column Structure Compare", replaceWords(diff.toString()));
			row = row + 1;
		}

	}

	public String replaceWords(String original) {
		if (original.contains("only on left")) {
			original = original.replaceAll("only on left", "only on source");
		}
		if (original.contains("only on right")) {
			original = original.replaceAll("only on right", "only on target");
		}
		return original;
	}

	public void columnConstraintCompare(Map<String, String> map3, Map<String, String> map4,int row, JSONObject object)
			throws EncryptedDocumentException, InvalidFormatException, IOException {
		if (map3.size() == 0 || map4.size() == 0) {

			if (map3.size() == 0 && map4.size() == 0) {
				object.put("Constraints Compare", "No Constraints Found in Source(L) and Target(R)");

			} else {
				if (map3.size() == 0) {
					object.put("Constraints Compare", "No Constraints Found in Source(L)");
				}

				else {
					object.put("Constraints Compare", "No Constraints Found in Target(R)");
				}
			}

		} else {
			tblsComparedCons++;
			MapDifference<String, String> diff = Maps.difference(map3, map4);
			if (diff.toString().equalsIgnoreCase("equal")) {
				consequal++;
			}
			object.put("Constraints Compare",replaceWords(diff.toString()));
		}

	}
}

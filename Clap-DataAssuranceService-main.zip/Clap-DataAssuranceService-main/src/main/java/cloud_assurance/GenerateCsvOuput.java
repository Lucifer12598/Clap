package cloud_assurance;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.log4j.Logger;

import data.DbData;
import dataCompare.CompareTest;
import dataCompare.ConnectionDetails;

public class GenerateCsvOuput {
	private static final Logger logger = Logger.getLogger(GenerateCsvOuput.class);
	
	public File compareDbData(Map<String, ArrayList<String>> map, Map<String, ArrayList<String>> mapTarget, DbData srcCon,
			DbData tgtCon, Map<String, ArrayList<String>> mapkeys,
			Map<String, ArrayList<String>> mapTgtkeys, String executionId) {

		List<String> SummaryPaths = new ArrayList<String>();
		List<String> Detailed1Paths = new ArrayList<String>();
		List<String> Detailed2Paths = new ArrayList<String>();
		List<String> ConNames = new ArrayList<String>();
		List<int[]> records = new ArrayList<int[]>();

		Iterator<Map.Entry<String, ArrayList<String>>> srcItr = map.entrySet().iterator();
		Iterator<Map.Entry<String, ArrayList<String>>> tgtItr = mapTarget.entrySet().iterator();
		String connectionName;
		String sourceUrl = srcCon.getUrl();
		String sourceDriver = srcCon.getDriver();
		String sourceSchema = srcCon.getSchema();
		String sourceUname = srcCon.getUser();
		String sourcePwd = srcCon.getPassword();
		String targetUrl = tgtCon.getUrl();
		String targetDriver = tgtCon.getDriver();
		String targetSchema = tgtCon.getSchema();
		String targetUname = tgtCon.getUser();
		String targetPwd = tgtCon.getPassword();

		while (srcItr.hasNext() && tgtItr.hasNext()) {
			Map.Entry<String, ArrayList<String>> srctable = srcItr.next();
			Map.Entry<String, ArrayList<String>> tgttable = tgtItr.next();
			connectionName = srctable.getKey() + "," + tgttable.getKey();
			ConnectionDetails cd = new ConnectionDetails(connectionName, sourceUrl, sourceDriver, sourceSchema,
					srctable.getKey(), sourceUname, sourcePwd, targetUrl, targetDriver, targetSchema, tgttable.getKey(),
					targetUname, targetPwd);
			try {
				CompareTest ct = new CompareTest(cd);
				Connection sCon = ct.getConManager().getSrcConnection();
				
				PreparedStatement srcStatement = sCon.prepareStatement("SELECT ? FROM ?.?");
				srcStatement.setString(1, ListToString(srctable.getValue()));
				srcStatement.setString(2, sourceSchema);
				srcStatement.setString(3, srctable.getKey());
				PreparedStatement tgtStatement = sCon.prepareStatement("SELECT ? FROM ?.?");
				tgtStatement.setString(1, ListToString(tgttable.getValue()));
				tgtStatement.setString(2, targetSchema);
				tgtStatement.setString(3, tgttable.getKey());
				
				ResultSet srcRs = srcStatement.executeQuery();

				String srcCompKey = "";
				String tgtCompKey = "";
				try {
					srcCompKey = ListToString(mapkeys.get(srctable.getKey()));
					tgtCompKey = ListToString(mapTgtkeys.get(tgttable.getKey()));
				} catch (Exception e) {
					logger.error(e);
				}
				ct.setSrcCompositeKey(srcCompKey);
				ct.setTgtCompisteKey(tgtCompKey);

				ct.collectSrcPrimaryKey(srcRs);
				String srcPrimary_key = ct.getSrcPrimary_key();

				ct.setSrcRows(ct.ResultSetToMap(srcRs, srcPrimary_key));
				sCon.close();
				Connection tCon = ct.getConManager().getTgtConnection();
				ResultSet tgtRs = tgtStatement.executeQuery();
				ct.collectTgtPrimaryKey(tgtRs);

				String tgtPrimary_key = ct.getTgtPrimary_key();
				ct.setTgtRows(ct.ResultSetToMap(tgtRs, tgtPrimary_key));
				tCon.close();

				int[] maprecords = ct.getSummaryReport();
				File report1 = ct.generateDetailedReport1();
				File report2 = ct.getDetailedReport2();
				String[] reportPaths = ct.getReportPaths();
				SummaryPaths.add(reportPaths[0]);
				Detailed1Paths.add(reportPaths[1]);
				Detailed2Paths.add(reportPaths[2]);
				ConNames.add(connectionName);
				records.add(maprecords);
				
				File zipFile = convertToZip(executionId, report1, report2);
				return zipFile;
			} catch (ClassNotFoundException | SQLException e) {
				logger.error(e);
			} catch (IOException e) {
				logger.error(e);
			} catch (NullPointerException e) {
				logger.error(e);
			}
		}
		return null;
	}
	
	private File convertToZip(String executionId, File report1, File report2) throws IOException {
		String tempFolder = new File(System.getProperty("java.io.tmpdir")).getCanonicalPath();
		File zipFile = new File(tempFolder + "/" + executionId +".zip");
		FileOutputStream fos = new FileOutputStream(zipFile);
        ZipOutputStream zipOut = new ZipOutputStream(fos);
        FileInputStream fis = null;
        
        ZipEntry zipEntry = new ZipEntry(report1.getName());
        zipOut.putNextEntry(zipEntry);
        fis = new FileInputStream(report1);
        byte[] bytes = new byte[1024];
        int length;
        while((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
        fis.close();
        
        fis = new FileInputStream(report2);
        zipEntry = new ZipEntry(report2.getName());
        zipOut.putNextEntry(zipEntry);
        bytes = new byte[1024];
        while((length = fis.read(bytes)) >= 0) {
            zipOut.write(bytes, 0, length);
        }
        zipOut.close();
        fis.close();
        fos.close();
        
        return zipFile;
	}

	public String ListToString(List<String> list) {
		StringBuffer string = new StringBuffer();
		for (String s : list) {
			string.append(s).append(",");
		}
		string.deleteCharAt(string.length() - 1);
		return string.toString();
	}
}

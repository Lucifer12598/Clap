package node;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import org.apache.http.HttpEntity;
import org.apache.http.client.CookieStore;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.json.JSONObject;

public class NodeSubmission {
	
	private String jwtToken;
	private HttpContext httpContext;
	private String executionId;
	private static final String SERVER_URL_PREFIX = "http://ec2-65-1-251-42.ap-south-1.compute.amazonaws.com:5010";
	Properties properties;
	
	public NodeSubmission(String executionId) {
		this.executionId = executionId;
		generateJwtToken();
		
		try {
			properties = new Properties();
			InputStream input = getClass().getResourceAsStream("/config.properties");
			properties.load(input);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void generateJwtToken() {
		JSONObject jsonTokenObj = null;
		try {

			String urlString = SERVER_URL_PREFIX + "/login/login";

			HttpPost httpPost = new HttpPost(urlString);
			JSONObject jsonObj = new JSONObject();
			jsonObj.put("email", properties.getProperty("nodeUser"));
			jsonObj.put("password", properties.getProperty("nodeKey"));
			StringEntity entity = new StringEntity(jsonObj.toString());
			httpPost.setEntity(entity);
			httpPost.setHeader("Accept", "application/json");
			httpPost.setHeader("Content-type", "application/json");

			CookieStore cookieStore = new BasicCookieStore();
			this.httpContext = new BasicHttpContext();
			this.httpContext.setAttribute(HttpClientContext.COOKIE_STORE, cookieStore);

			CloseableHttpClient httpclient = null;
			httpclient = HttpClients.custom().build();

			CloseableHttpResponse httpResponse = httpclient.execute(httpPost, this.httpContext);

			BufferedReader reader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));

			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = reader.readLine()) != null) {
				response.append(inputLine);
			}
			reader.close();
			httpclient.close();
			jsonTokenObj = new JSONObject(response.toString());
			JSONObject data = (JSONObject) jsonTokenObj.get("data");
			this.jwtToken = data.getString("token");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public void postDataReport(File zipFile) {
		System.out.println("Posting Report");
		try {
			String urlString = SERVER_URL_PREFIX + "/dataanalytics/receivecsv";
			HttpPost httpPost = new HttpPost(urlString);
			MultipartEntityBuilder builder = MultipartEntityBuilder.create();
			builder.addTextBody("ExecutionId", executionId,ContentType.TEXT_PLAIN);
	        builder.addBinaryBody("file", zipFile, ContentType.APPLICATION_OCTET_STREAM, "fileName");
	        HttpEntity multipart = builder.build();
			httpPost.setEntity(multipart);
			httpPost.setHeader("Authorization", "Bearer " + this.jwtToken);

			CloseableHttpClient httpclient = HttpClients.createDefault();
			httpclient.execute(httpPost, this.httpContext);
			httpclient.close();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
}
